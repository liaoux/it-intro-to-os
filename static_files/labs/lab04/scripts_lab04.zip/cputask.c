#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/* cputask.c — générateur de charge CPU-bound (durée contrôlée).
   Boucle de calcul pur (aucune entrée/sortie) : le processus consomme le CPU
   sans jamais attendre, donc `time` affiche un temps `user` presque égal à
   `real`. La DURÉE est donnée en secondes (et non en nombre d'itérations) pour
   que la fenêtre d'observation soit prévisible sur toute machine (Ubuntu, WSL,
   macOS). Usage : ./cputask [secondes]   (défaut 15 s).                       */
int main(int argc, char **argv) {
    int seconds = 15;
    if (argc > 1) seconds = atoi(argv[1]);
    if (seconds <= 0) seconds = 15;

    time_t start = time(NULL);
    volatile long s = 0;
    long i = 0;
    while (time(NULL) - start < seconds) {
        s += i;
        i++;
    }
    printf("cputask done (%d s): %ld\n", seconds, s);
    return 0;
}
