#!/usr/bin/env bash
# =============================================================================
# lab04_ex3.sh — Objectif 3 : Créer des processus et observer l'ordonnancement
# =============================================================================
. "$(dirname "${BASH_SOURCE[0]}")/lab04_lib.sh"

BANNER="Rappel : l'annexe du PDF (prototypes C + commandes processus) + man 2 fork, man 2 wait, man 2 exec, man cc, man kill, man renice. Fonction oubliée : man -k mot-clé."

begin "report_lab04_ex3.txt" 15 "Objectif 3 — Créer des processus et observer l'ordonnancement" "TP04" 5 "$BANNER"

title "Objectif 3 — fork/exec/wait, zombie, ordonnancement et signaux"

# ----------------------------------------------------- Partie A : comprendre
step "Consulte \`man 2 fork\` et lis la description."

q_choice \
  "Que fait \`fork()\` ?" \
  "remplace le programme du processus|crée un processus fils en dupliquant le processus courant|termine le processus|envoie un signal" \
  2 \
  "Après \`fork\`, il y a deux processus identiques (parent et fils)." \
  "C'est la seule façon de créer un processus sous Unix." \
  "Consulte \`man 2 fork\`."

step "Consulte \`man 2 wait\` (et \`man 2 exec\` pour la suite) et lis la description."

q_choice \
  "Que fait \`wait()\` ?" \
  "attend la fin d'un processus fils (et récupère son statut)|endort le processus|change la priorité|crée un processus" \
  1 \
  "Le parent se met en attente jusqu'à la fin du fils." \
  "C'est ce qui permet au parent de « récolter » le fils." \
  "Consulte \`man 2 wait\` : il attend la terminaison d'un enfant."

step "Ouvre \`forkdemo.c\` avec \`less -N\` et lis la branche du fils (le bloc \`if (pid == 0)\`)."

q_choice \
  "Que retourne \`fork()\` dans le processus Fils ?" \
  "le PID du fils|-1|0|le PID du parent" \
  3 \
  "Le fils reconnaît qu'il est le fils grâce à cette valeur." \
  "Une valeur nulle indique « je suis le fils »." \
  "Relis le slide « fork() : créer un processus » (valeur de retour)."

step "Lis maintenant la branche du parent (après le \`if\`) dans \`forkdemo.c\`."

q_choice \
  "Que retourne \`fork()\` dans le processus Parent ?" \
  "0|une valeur aléatoire|le PID du grand-parent|le PID de son fils" \
  4 \
  "Le parent a besoin de connaître l'identité de son enfant." \
  "C'est cette valeur qu'on passe ensuite à \`wait\`." \
  "Relis le slide « fork() en action » (pid > 0)."

step "Dans \`forkdemo.c\`, repère le mode déclenché par l'argument \`z\` et lis ce que font le fils et le parent dans ce mode."

q_choice \
  "Un fils qui s'est terminé mais dont le parent n'a pas encore appelé \`wait\` devient…" \
  "un orphelin|un processus stoppé|un zombie|un démon" \
  3 \
  "Il est mort, mais son entrée dans la table des processus subsiste." \
  "Il apparaît en état Z dans la colonne STAT de \`ps\`." \
  "Relis le slide « Processus — Zombies et orphelins »."

# ------------------------------------------ Partie B : compiler et observer
step "Compile le programme : \`cc -Wall -Wextra -o forkdemo forkdemo.c\` (depuis \`~/oslabs/lab04\`)."

q_fs "le binaire forkdemo existe et est exécutable" \
  '[ -x "$HOME/oslabs/lab04/forkdemo" ]' \
  "Tu dois être dans \`~/oslabs/lab04\` (où se trouve \`forkdemo.c\`)." \
  "\`cc -o nom sort.c\` choisit le nom du fichier de sortie." \
  "Vérifie avec \`ls -l\` que le fichier \`forkdemo\` est bien créé." \
  "cd ~/oslabs/lab04 && cc -Wall -Wextra -o forkdemo forkdemo.c"

step "Dans le terminal d'exécution, lance \`./forkdemo &\`. Dans le terminal d'observation, tape \`ps -u \$USER -o pid,ppid,stat,comm | grep forkdemo\` (ou \`pstree -p\`)."

q_choice \
  "Combien de processus \`forkdemo\` sont actifs pendant que le fils dort ?" \
  "1|3|aucun|2" \
  4 \
  "Le parent et le fils sont deux processus distincts." \
  "\`grep forkdemo\` ne doit pas compter la ligne de \`grep\` elle-même." \
  "Le fils dort 30 s : tu as le temps d'observer."

step "Dans le terminal d'exécution, lance \`./forkdemo zombie &\`. Dans le terminal d'observation, tape \`ps -u \$USER -o pid,ppid,stat,comm | grep forkdemo\` et observe l'état du fils."

q_choice \
  "Quel état (colonne STAT) affiche le fils zombie ?" \
  "R|Z|S|T" \
  2 \
  "Le fils est mort mais encore présent dans la table des processus." \
  "Le parent dort (S) pendant que le fils est en Z." \
  "Après ~30 s, le parent appelle \`wait\` et le zombie disparaît."

# ----------------------------------------------- Partie C : ordonnancement
step "Ouvre \`cputask.c\` : c'est une boucle de calcul pur (sans E/S) qui tourne une durée donnée en secondes. Compile-le : \`cc -Wall -Wextra -o cputask cputask.c\`."

q_fs "le binaire cputask existe et est exécutable" \
  '[ -x "$HOME/oslabs/lab04/cputask" ]' \
  "Même principe que pour \`forkdemo\`." \
  "\`cputask.c\` est une boucle de calcul purement CPU (durée en secondes)." \
  "Vérifie avec \`ls -l\` que le fichier \`cputask\` est bien créé." \
  "cd ~/oslabs/lab04 && cc -Wall -Wextra -o cputask cputask.c"

step "Consulte \`help time\` (commande interne du shell), relis le slide « I/O-bound vs CPU-bound » du cours, puis tape \`time ./cputask 5\` et observe \`real\`, \`user\` et \`sys\`."

q_choice \
  "Pour ce programme sans E/S, pourquoi \`real\` est-il presque égal à \`user\` ?" \
  "parce qu'il attend le disque|parce qu'il passe presque tout son temps à calculer (CPU-bound)|parce qu'il est en veille|parce qu'il est bloqué sur le réseau" \
  2 \
  "\`user\` = temps CPU passé dans le code du programme." \
  "Un programme I/O-bound passerait surtout son temps à attendre." \
  "Relis le slide « I/O-bound vs CPU-bound »."

step "Tape \`nice -n 19 ./cputask 15 &\` (dans le terminal d'exécution) et observe."

q_choice \
  "Que signifie une valeur \`nice\` élevée (ex. +19) ?" \
  "une priorité plus basse (le processus « est gentil »)|une priorité plus haute|plus de mémoire|un temps CPU garanti" \
  1 \
  "La valeur nice va de -20 (priorité haute) à +19 (priorité basse)." \
  "« nice » = gentil : le processus laisse la place aux autres." \
  "Relis le slide « Priorités : nice et renice »."

step "Lance deux tâches : \`./cputask 15 &\` puis \`nice -n 19 ./cputask 15 &\`. Dans le terminal d'observation, tape \`ps -u \$USER -o pid,ni,pcpu,comm | grep cputask\`."

q_choice \
  "Dans la colonne NI de \`ps\`, quelle valeur correspond à la priorité la plus HAUTE ?" \
  "+19|0|-20|NI n'indique pas la priorité" \
  3 \
  "La valeur nice la plus basse (-20) donne la priorité la plus haute." \
  "0 est la valeur par défaut ; -20 est le maximum de priorité." \
  "Relis le slide « Priorités : nice et renice »."

step "Tape \`renice 10 -p <PID>\` en remplaçant <PID> par celui d'une tâche \`cputask\` en cours."

q_choice \
  "Que fait la commande \`renice\` ?" \
  "renomme un fichier|relance un processus|tue un processus|change la priorité (nice) d'un processus déjà en cours" \
  4 \
  "Contrairement à \`nice\`, elle agit sur un processus qui tourne déjà." \
  "Elle prend le PID du processus à modifier." \
  "Consulte \`man renice\` : elle modifie la priorité d'un processus existant."

# ----------------------------------------------- Partie D : signaux avancés
step "Lance \`./cputask 30 &\`, récupère son PID (\`pgrep -u \$USER -x cputask\`), puis suspends-le avec \`kill -STOP <PID>\`. Observe l'état avec \`ps -o pid,stat,comm -p <PID>\`."

q_choice \
  "Que fait le signal SIGSTOP ?" \
  "il suspend le processus (état T)|il le termine|il est ignoré|il le redémarre" \
  1 \
  "Le processus ne meurt pas : il passe à l'état T (stopped)." \
  "Puis \`kill -CONT <PID>\` le fait reprendre." \
  "Consulte \`kill -l\` ou le tableau des signaux de l'annexe."

# ------------------------------------------------------- Partie E : synthèse
step "Termine les tâches restantes (\`pkill -x cputask\`), puis réfléchis à l'ordonnancement."

q_choice \
  "Pour un ensemble de tâches CPU-bound de durées différentes, quel algorithme minimise le temps d'attente moyen ?" \
  "SJF (le plus court d'abord)|FCFS|Round Robin|LIFO" \
  1 \
  "Exécuter les courtes tâches d'abord évite qu'elles attendent derrière les longues." \
  "FCFS subit l'effet de convoi (convoy effect)." \
  "Relis le slide sur les algorithmes d'ordonnancement (SJF)."

finalize
