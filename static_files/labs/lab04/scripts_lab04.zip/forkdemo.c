#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

/* forkdemo.c — démonstration fork()/wait() + mode zombie.
   Usage :
     ./forkdemo          -> le parent crée un fils ; le fils dort 30 s ; le parent
                            l'attend (wait()). Observer 2 processus à la fois.
     ./forkdemo zombie   -> le fils meurt immédiatement (_exit) pendant que le
                            parent dort 30 s SANS appeler wait() : le fils reste
                            alors en état Z (zombie) dans la table des processus.

   Rappel (slide « fork() : créer un processus ») : fork() renvoie 0 dans le FILS,
   le PID du fils dans le PARENT, et une valeur < 0 en cas d'erreur.            */
int main(int argc, char **argv) {
    int zombie = 0;
    if (argc > 1 && argv[1][0] == 'z') zombie = 1;

    pid_t pid = fork();          /* 0 -> fils, PID du fils -> parent, <0 -> erreur */
    if (pid < 0) { perror("fork"); return 1; }

    if (pid == 0) {
        /* --- FILS --- */
        printf("child : pid=%d ppid=%d\n", getpid(), getppid());
        if (zombie) _exit(0);    /* le fils meurt tout de suite -> devient zombie */
        sleep(30);
        printf("child : bye\n");
        return 0;
    }

    /* --- PARENT --- */
    printf("parent: pid=%d child=%d\n", getpid(), pid);
    if (zombie) sleep(30);       /* le parent dort sans wait -> le fils reste Z  */
    wait(NULL);                  /* récolte le fils (fait disparaître le zombie) */
    printf("parent: child %d terminated\n", pid);
    return 0;
}
