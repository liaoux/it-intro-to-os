#!/usr/bin/env bash
# =============================================================================
# lab04_ex1.sh — Objectif 1 : Observer les processus
# =============================================================================
. "$(dirname "${BASH_SOURCE[0]}")/lab04_lib.sh"

BANNER="Rappel : l'annexe du PDF (aide-mémoire des commandes processus) + man ps, man pgrep, man pstree, man top. Commande oubliée : man -k mot-clé."

begin "report_lab04_ex1.txt" 10 "Objectif 1 — Observer les processus" "TP04" 5 "$BANNER"

title "Objectif 1 — Lister et observer les processus"

step "Consulte \`man ps\` (ou \`ps --help\`) et lis la description."

q_choice \
  "À quoi sert la commande \`ps\` ?" \
  "créer un processus|afficher l'état des processus|tuer un processus|changer la priorité d'un processus" \
  2 \
  "Son nom vient de « process status »." \
  "Elle lit l'information dans le noyau, via /proc." \
  "Lis la section NAME de \`man ps\`."

step "Tape \`ps aux\` puis \`ps -ef\` et observe."

q_choice \
  "Que montrent \`ps aux\` et \`ps -ef\` ?" \
  "uniquement tes propres processus|uniquement les processus du noyau|tous les processus du système|les fichiers ouverts" \
  3 \
  "Sans option, \`ps\` ne montre que les processus de ton terminal." \
  "Ces variantes ajoutent les processus de tous les utilisateurs." \
  "Compare la sortie de \`ps\` et de \`ps aux\`."

step "Tape \`ps -o pid,ppid,stat,comm\` et observe la colonne STAT."

q_choice \
  "Que représente la colonne STAT dans la sortie de \`ps\` ?" \
  "l'état du processus (ex. R, S, Z, T)|la mémoire utilisée|le temps CPU consommé|le propriétaire du processus" \
  1 \
  "Les valeurs typiques sont R, S, Z, T." \
  "R = en exécution, S = en attente, Z = zombie." \
  "Consulte \`man ps\`, section « PROCESS STATE CODES »."

step "Tape \`echo \$\$ \$PPID\`. Ces deux variables concernent le shell et son parent."

q_choice \
  "Quelle variable contient le PID du shell courant ?" \
  "\$PPID|\$@|\$\$|\$?" \
  3 \
  "L'une désigne le shell lui-même, l'autre son parent." \
  "\$PPID est le PID du parent." \
  "Relis la sortie : le premier nombre est le PID du shell."

step "Tape \`ps -p \$PPID -o pid,ppid,comm\` et observe."

q_choice \
  "Que représente le PPID d'un processus ?" \
  "le PID du processus lui-même|le PID de son processus parent|la priorité du processus|le numéro du terminal" \
  2 \
  "PPID = « parent process ID »." \
  "C'est le processus qui a créé (fork) celui-ci." \
  "Consulte \`man ps\` : la colonne PPID est le PID du parent."

step "Consulte \`man pgrep\` (ou \`pgrep --help\`) et lis la description."

q_choice \
  "À quoi sert la commande \`pgrep\` ?" \
  "tuer un processus|afficher l'arbre des processus|chercher des PID à partir d'un nom ou d'un motif|changer la priorité d'un processus" \
  3 \
  "Elle évite le \`ps | grep\` en filtrant directement par nom." \
  "Le « p » vient de « process »." \
  "Consulte \`man pgrep\`, section NAME."

step "Tape \`pstree -p\` (ou, à défaut, \`ps -o pid,ppid,comm\`) et observe."

q_choice \
  "Que montre la commande \`pstree\` ?" \
  "l'arbre (hiérarchie parent-enfant) des processus|la liste des fichiers ouverts|les signaux disponibles|la charge moyenne du système" \
  1 \
  "Observe la disposition de la sortie." \
  "Chaque processus y figure sous celui qui l'a créé." \
  "Consulte \`man pstree\`."

step "Tape \`top\` et observe."

q_choice \
  "Que montre la commande \`top\` ?" \
  "une liste statique des processus|une vue dynamique des processus, mise à jour en continu|un arbre des processus|la table des signaux" \
  2 \
  "Elle se met à jour toutes les quelques secondes." \
  "La première ligne affiche l'heure et la charge moyenne (load average)." \
  "Consulte \`man top\` ou le slide « top et htop »."

step "Dans \`top\`, appuie sur \`h\` pour afficher l'aide des touches, teste quelques touches, puis quitte avec \`q\`."

q_choice \
  "Quelle touche permet de quitter \`top\` ?" \
  "M|k|r|q" \
  4 \
  "Regarde l'aide interactive de \`top\` (touche h)." \
  "Les autres touches trient (M = mémoire) ou tuent (k)." \
  "Consulte \`man top\` ou le slide « top et htop »."

step "Si \`htop\` est installé (voir Exercice 0), lance-le, appuie sur \`h\` pour l'aide des touches, teste-les, puis quitte."

q_choice \
  "Qu'est-ce que \`htop\` par rapport à \`top\` ?" \
  "une variante plus riche et colorée de \`top\`|un tueur de processus|un afficheur d'arbre|un outil de traçage" \
  1 \
  "C'est un remplaçant plus ergonomique de \`top\`." \
  "Si absent : \`sudo apt install htop\` (Linux) ou \`brew install htop\` (macOS)." \
  "Consulte \`man htop\`."

finalize
