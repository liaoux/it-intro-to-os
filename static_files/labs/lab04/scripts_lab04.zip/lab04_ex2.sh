#!/usr/bin/env bash
# =============================================================================
# lab04_ex2.sh — Objectif 2 : Piloter les processus (jobs et signaux)
# =============================================================================
. "$(dirname "${BASH_SOURCE[0]}")/lab04_lib.sh"

BANNER="Rappel : l'annexe du PDF (aide-mémoire des commandes processus) + man kill, man bash (job control), help jobs/bg/fg. Commande oubliée : man -k mot-clé."

begin "report_lab04_ex2.txt" 10 "Objectif 2 — Piloter les processus (jobs et signaux)" "TP04" 5 "$BANNER"

title "Objectif 2 — Lancer, suspendre, reprendre et terminer"

step "Consulte \`man kill\` (ou \`kill -l\`) et lis ce qu'est un signal."

q_choice \
  "Qu'est-ce qu'un signal sous Unix ?" \
  "une interruption logicielle qui notifie un événement à un processus|une commande de tri|un fichier système|un appel de fonction C" \
  1 \
  "Un signal peut être synchrone (SIGSEGV) ou asynchrone (SIGINT)." \
  "\`kill\` n'est qu'un moyen d'en envoyer un." \
  "Consulte le slide « Les signaux » du cours."

step "Lance une tâche en arrière-plan : \`sleep 300 &\`."

q_fs "ton processus \`sleep 300\` tourne en arrière-plan" \
  'pgrep -u "$(id -u)" -f "^sleep 300$" >/dev/null 2>&1' \
  "N'oublie pas le \`&\` à la fin pour lancer en arrière-plan." \
  "\`sleep 300\` doit être en cours ; il t'appartient, pas à root." \
  "Vérifie qu'un \`sleep\` t'appartient : \`pgrep -u \$USER -x sleep\`." \
  "sleep 300 &"

step "Tape \`jobs\` et observe."

q_choice \
  "Que fait la commande \`jobs\` ?" \
  "elle termine les tâches en arrière-plan|elle lance une tâche en arrière-plan|elle liste les tâches (jobs) du shell avec leur numéro|elle envoie un signal" \
  3 \
  "Elle affiche des numéros comme [1]." \
  "Regarde la sortie : un job par ligne." \
  "Consulte \`help jobs\`."

step "Consulte \`help fg\` (ou \`man bash\`), puis tape \`fg %1\` et appuie sur Ctrl+Z."

q_choice \
  "Que fait la combinaison Ctrl+Z ?" \
  "elle termine le processus|elle l'envoie en arrière-plan|elle redémarre le shell|elle suspend (met en pause) le processus en avant-plan" \
  4 \
  "Le processus ne meurt pas." \
  "Après Ctrl+Z, \`jobs\` montre le job « stopped »." \
  "C'est le signal SIGTSTP."

step "Consulte \`help bg\`, puis tape \`bg %1\` et observe avec \`jobs\`."

q_choice \
  "Que fait la commande \`bg\` ?" \
  "elle liste les jobs|elle reprend un job suspendu en arrière-plan|elle termine le job|elle change la priorité" \
  2 \
  "C'est le pendant de \`fg\`." \
  "Le job suspendu reprend son exécution." \
  "Consulte \`help bg\`."

step "Tape \`kill %1\` puis \`jobs\` pour vérifier."

q_choice \
  "Quel signal \`kill\` envoie-t-il par défaut ?" \
  "SIGKILL|SIGINT|SIGSTOP|SIGTERM" \
  4 \
  "Ce signal demande une terminaison propre." \
  "SIGKILL (9) est plus brutal et non interceptable." \
  "Consulte \`man kill\` : le signal par défaut est le 15."

step "Vérifie que la tâche a bien disparu : \`jobs\` (ou \`pgrep -u \$USER -x sleep\`)."

q_fs "plus aucun processus \`sleep 300\` à toi" \
  '! pgrep -u "$(id -u)" -f "^sleep 300$"' \
  "\`kill %1\` envoie SIGTERM au job numéro 1." \
  "Le \`sleep\` doit avoir disparu." \
  "Vérifie avec \`pgrep -u \$USER -x sleep\` (plus rien)." \
  "kill %1"

step "Relance \`sleep 300 &\`, récupère son PID avec \`pgrep -u \$USER -x sleep\` (voir le cours), puis termine-le avec \`kill -9\`."

q_choice \
  "Pourquoi faut-il préférer SIGTERM (15) à SIGKILL (9) ?" \
  "SIGKILL est plus rapide|SIGTERM laisse le processus nettoyer (fermer fichiers, libérer mémoire) ; SIGKILL ne peut être ni intercepté ni ignoré|SIGKILL est plus propre|les deux sont équivalents" \
  2 \
  "SIGKILL tue immédiatement sans laisser le processus se préparer." \
  "SIGKILL (9) ne peut pas être capturé par le programme." \
  "Relis le slide « kill » : SIGTERM = arrêt propre, SIGKILL = dernier recours."

step "Tape \`kill -l\` pour lister les signaux et leurs numéros, puis consulte leurs significations (tableau des signaux de l'annexe ou cours) avant de les utiliser."

q_choice \
  "Quel signal correspond à Ctrl+C ?" \
  "SIGINT|SIGKILL|SIGSTOP|SIGTERM" \
  1 \
  "C'est un signal d'interruption envoyé au processus en avant-plan." \
  "Le nom évoque une interruption (« interrupt »)." \
  "Consulte \`kill -l\` ou le tableau des signaux de l'annexe."

step "Réfléchis : un signal envoyé par l'utilisateur (ex. Ctrl+C) arrive à tout moment."

q_choice \
  "Ctrl+C (SIGINT) est un signal de quel type ?" \
  "synchrone|asynchrone|les deux|ni l'un ni l'autre" \
  2 \
  "Un signal synchrone survient au moment précis d'une faute (ex. SIGSEGV)." \
  "Un signal asynchrone peut arriver à n'importe quel instant." \
  "Relis le slide « Les signaux » : l'utilisateur envoie un signal asynchrone."

finalize
