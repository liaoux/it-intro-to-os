#!/usr/bin/env bash
# =============================================================================
# lab03_ex2.sh — Objectif 2 : Du code source à la commande installée
# =============================================================================
. "$(dirname "${BASH_SOURCE[0]}")/lab03_lib.sh"

BANNER="Rappel : l'annexe du PDF (prototypes POSIX) + man 2 (appels système), man 3 (fonctions de bibliothèque), man gcc, strace --help. Fonction oubliée : man -k mot-clé."

begin "report_lab03_ex2.txt" 18 "Objectif 2 — Du code source à la commande installée" "TP03" 8 "$BANNER"

title "Objectif 2 — Comprendre le code, puis le compiler, l'installer et le tracer"

# ------------------------------------------------- Partie D : comprendre ----
step "Ouvre \`myls.c\` avec \`less -N\`. Tape \`/int main\` puis Entrée, et lis la fonction \`main\`."

q_choice \
  "Que fait \`main()\` ?" \
  "analyser les options et le répertoire, puis appeler \`lister()\`|compiler le programme|afficher l'aide et quitter|lire le répertoire directement" \
  1 \
  "Lis la boucle \`for\` de \`main\` : elle examine chaque argument de la ligne de commande." \
  "La dernière ligne de \`main\` fait un \`return\` d'une fonction : laquelle ?" \
  "Relis le code : après avoir analysé les arguments, qui s'occupe du répertoire ?"

step "Tape \`/typedef struct\` dans \`less -N myls.c\` pour localiser les structures en haut du fichier, et lis-les."

q_choice \
  "À quoi servent \`Entree\` et \`Options\` ?" \
  "mémoriser le nom de l'utilisateur|stocker les lignes du fichier source|mémoriser une entrée (nom, attributs, type) et les options de la ligne de commande|définir les couleurs d'affichage" \
  3 \
  "\`Entree\` contient un \`nom\`, une \`struct stat\` et un \`type\`." \
  "\`Options\` contient trois drapeaux (\`tout\`, \`tri_taille\`, \`tri_date\`)." \
  "À quoi servent ces champs dans un liste-répertoire ?"

step "Relis la fonction \`lister\` de haut en bas, et note l'ordre des grandes étapes."

q_choice \
  "Quel est l'ordre des opérations de \`lister()\` ?" \
  "trier → ouvrir → lire → afficher|afficher → ouvrir → lire → fermer|ouvrir → afficher → trier → lire|ouvrir → lire les entrées → fermer → trier → afficher + pied de page" \
  4 \
  "La fonction commence par \`opendir\` et finit par le pied de page." \
  "Le \`closedir\` vient après la boucle de lecture, avant le tri." \
  "Relis les commentaires « Étape 1 » à « Étape 5 » dans le code."

step "Dans la boucle de lecture, observe la construction du chemin complet avant \`stat\`."

q_choice \
  "Pourquoi construit-on \`chemin/nom\` avant d'appeler \`stat()\` ?" \
  "pour accélérer le programme|parce que \`readdir\` ne retourne que le nom, pas le chemin|pour trier les entrées|pour éviter d'appeler \`stat\`" \
  2 \
  "\`readdir\` retourne une entrée : que contient-elle exactement ?" \
  "\`stat\` a besoin du chemin complet du fichier pour lire ses attributs." \
  "Regarde ce que fait la ligne \`snprintf(chemin_complet, ...)\` : elle assemble quoi ?"

step "Observe \`qsort\` et les fonctions \`cmp_nom\`, \`cmp_taille\`, \`cmp_date\`."

q_choice \
  "À quoi sert \`qsort\` dans \`lister()\` ?" \
  "allouer la mémoire|ouvrir le répertoire|trier les entrées selon l'option choisie|afficher les entrées" \
  3 \
  "\`qsort\` reçoit un comparateur : \`cmp_nom\`, \`cmp_taille\` ou \`cmp_date\`." \
  "Le comparateur est choisi selon \`opts->tri_taille\` ou \`opts->tri_date\`." \
  "Consulte \`man 3 qsort\` : que fait cette fonction ?"

# --------------------------------------------------- Partie A : compiler ----
step "Avant de compiler, découvre l'outil : tape \`man gcc\` (ou \`gcc -{}-help\`) et lis l'introduction."

q_choice \
  "Qu'est-ce que \`gcc\` et que fait-il ?" \
  "un éditeur de texte|un compilateur : il transforme le code source C en programme exécutable|un interpréteur qui exécute le code ligne par ligne|un outil de traçage des appels système" \
  2 \
  "Son nom signifie « GNU Compiler Collection »." \
  "Il lit un fichier \`.c\` et produit un fichier exécutable." \
  "Dans \`man gcc\`, la DESCRIPTION commence par « gcc --- C and C++ compilers »."

step "Dans \`~/oslabs/lab03\`, tape \`gcc -Wall -Wextra -o myls myls.c\`. Cette commande transforme le code source en programme exécutable."

q_fs "le binaire ./myls existe et est exécutable" \
  '[ -x "$HOME/oslabs/lab03/myls" ]' \
  "Tu dois être dans le dossier où se trouve \`myls.c\`." \
  "\`gcc -o nom\` choisit le nom du fichier de sortie." \
  "Vérifie avec \`ls -l\` que le fichier \`myls\` est bien créé et marqué \`x\`." \
  "cd ~/oslabs/lab03 && gcc -Wall -Wextra -o myls myls.c"

step "Tape \`file myls\`. Cette commande identifie le type du fichier que \`gcc\` vient de produire."

q_choice \
  "Quel type de fichier est \`myls\` maintenant ?" \
  "un fichier texte (code source)|un exécutable ELF|un fichier objet relocalisable|une archive compressée" \
  2 \
  "\`file\` affiche une description du format du fichier." \
  "Avant \`gcc\`, \`myls.c\` était un « C source, ASCII text »." \
  "Un exécutable Linux porte le format décrit par \`file\` (trois lettres)."

step "Tape \`./myls\` puis \`./myls -a\`. Observe ce que fait ta commande."

q_choice \
  "Que fait la commande \`myls\` ?" \
  "elle compile un programme|elle copie des fichiers|elle affiche l'aide|elle liste le contenu d'un répertoire avec un format personnalisé" \
  4 \
  "Regarde la sortie : des \`[DIR]\` et des \`[FILE]\` avec des tailles." \
  "L'option \`-a\` affiche aussi les fichiers cachés." \
  "C'est l'équivalent d'une commande que tu connais déjà."

# ------------------------------------------------- Partie B : installer -----
step "Crée ton dossier de commandes personnelles puis installe la commande : \`mkdir -p ~/bin && cp myls ~/bin/\`."

q_fs "~/bin/myls existe et est exécutable" \
  '[ -x "$HOME/bin/myls" ]' \
  "\`mkdir -p\` crée le dossier \`bin\` dans ton répertoire personnel." \
  "\`cp\` copie le binaire vers \`~/bin\`." \
  "Vérifie avec \`ls -l ~/bin\` que \`myls\` y est bien présent." \
  "mkdir -p ~/bin && cp myls ~/bin/"

step "Ajoute \`~/bin\` au \`PATH\` : tape \`export PATH=\"\$HOME/bin:\$PATH\"\` (ou ajoute cette ligne à \`~/.bashrc\` puis \`source ~/.bashrc\`)."

q_choice \
  "Pourquoi faut-il ajouter \`~/bin\` au \`PATH\` ?" \
  "pour que le shell puisse retrouver \`myls\` par son nom|pour compiler plus vite|pour économiser de la mémoire|pour changer le répertoire courant" \
  1 \
  "Rappelle-toi l'Objectif 1 : à quoi sert le \`PATH\` ?" \
  "Le shell ne cherche les commandes que dans les dossiers du \`PATH\`." \
  "Sans ça, taper \`myls\` échouerait avec « commande introuvable »."

step "Déplace-toi ailleurs : \`cd ~\`. Puis tape \`myls\` (sans \`./\`). Vérifie avec \`which myls\`."

q_choice \
  "Pourquoi \`myls\` fonctionne-t-il maintenant sans \`./\` ?" \
  "parce que le programme est plus rapide|parce qu'il est dans le répertoire courant|parce que \`~/bin\` est dans le \`PATH\`|parce que \`gcc\` l'a rendu global" \
  3 \
  "\`which myls\` montre le chemin vers \`~/bin/myls\`." \
  "Le \`./\` force l'exécution depuis le répertoire courant ; sans lui, le shell cherche dans le \`PATH\`." \
  "Quel dossier de ton \`PATH\` contient \`myls\` ?"

# --------------------------------------------------- Partie C : tracer -----
step "Avant de tracer, découvre l'outil : tape \`man strace\` (ou \`strace -{}-help\`) et lis l'introduction."

q_choice \
  "Qu'est-ce que \`strace\` et que fait-il ?" \
  "un compilateur C|un éditeur de texte|un traceur : il affiche les appels système exécutés par un programme|un outil qui liste les fichiers d'un dossier" \
  3 \
  "Il exécute un programme et affiche chaque appel système avec ses paramètres et son retour." \
  "Son nom vient de « system call trace »." \
  "Dans \`man strace\`, la DESCRIPTION commence par « strace --- trace system calls and signals »."

step "Retourne dans ton dossier de travail : \`cd ~/oslabs/lab03\`. Puis tape \`strace -o trace.txt ./myls .\`. Le fichier \`trace.txt\` contiendra tous les appels système de ton programme."

q_fs "le fichier trace.txt existe et n'est pas vide" \
  '[ -s "$HOME/oslabs/lab03/trace.txt" ]' \
  "\`strace -o fichier\` écrit la trace dans un fichier." \
  "Reviens dans \`~/oslabs/lab03\` (où se trouve \`myls\`) avec \`cd\`." \
  "Vérifie avec \`ls -l trace.txt\` qu'il a été créé." \
  "cd ~/oslabs/lab03 && strace -o trace.txt ./myls ."

step "Tape \`strace -c ./myls .\` : c'est le résumé statistique des appels système."

q_choice \
  "Que montre \`strace -c\` ?" \
  "le contenu du répertoire|un résumé statistique (nombre d'appels par appel système)|le code source de myls|les erreurs de compilation" \
  2 \
  "Regarde la sortie : un tableau avec des noms d'appels et des compteurs." \
  "Chaque ligne correspond à un appel système et son nombre d'invocations." \
  "Consulte \`man strace\`, option \`-c\`."

step "Tape \`strace -e openat ./myls .\` : on ne garde que les appels \`openat\`."

q_choice \
  "Quel appel système se cache derrière \`opendir()\` ?" \
  "getdents64|close|openat|newfstatat" \
  3 \
  "Dans la trace filtrée, chaque \`opendir\` de ton code produit un appel \`openat\`." \
  "\`opendir\` est une fonction de bibliothèque (man 3) qui appelle un syscall d'ouverture." \
  "Consulte \`man 3 opendir\` puis \`man 2 openat\` pour faire le lien."

step "Compare \`man 3 readdir\` et \`man 2 getdents64\`. Observe la différence de section."

q_choice \
  "Pourquoi \`readdir\` est en section 3 alors que \`getdents64\` est en section 2 ?" \
  "readdir est plus rapide|readdir est un appel système, getdents64 une fonction|ce sont deux appels système identiques|readdir est une fonction de bibliothèque (libc) qui enveloppe l'appel système getdents64" \
  4 \
  "La section 2 documente les appels système, la section 3 les fonctions de bibliothèque." \
  "Quand ton code appelle \`readdir\`, c'est la libc qui déclenche \`getdents64\`." \
  "Relis l'Objectif 1 : \`readdir\` est dans quelle section ? Et \`getdents64\` ?"

step "Lis \`man 3 closedir\` puis \`man 2 close\`, et observe la trace. Chaque fonction de bibliothèque invoque un appel système précis : quel appel \`closedir()\` invoque-t-il ?"

q_choice \
  "Quel appel système est invoqué par \`closedir()\` ?" \
  "openat|getdents64|close|newfstatat" \
  3 \
  "\`closedir\` libère le descripteur de répertoire ouvert par \`opendir\`." \
  "Fermer un descripteur est le rôle d'un appel système précis." \
  "Dans \`man 2 close\`, l'en-tête de la DESCRIPTION dit « close --- close a file descriptor »."

finalize
