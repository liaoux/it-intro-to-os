#!/usr/bin/env bash
# =============================================================================
# lab03_lib.sh — moteur de mission TP (portable : bash 3.2+, outils POSIX)
#
# Moteur de référence (évolué), dérivé de lab02_lib.sh, avec :
#   1. résistance à Ctrl+C (confirme avant de quitter, puis sauvegarde) ;
#   2. feedback explicite « Incorrect » (rouge), en symétrie du « Correct » ;
#   3. primitives q_man (recherche doc) et q_choice (QCM) ;
#   4. reprise : la mission reprend où elle s'était arrêtée (fichier d'état).
#
# Fonctionne sur WSL / Kali / Ubuntu / macOS. Aucune dépendance GNU-only.
# =============================================================================

# --- chemins ---------------------------------------------------------------
LIB_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# --- couleurs (uniquement si stdout est un terminal) -----------------------
if [ -t 1 ]; then
    c_blue=$(printf '\033[1;34m');  c_green=$(printf '\033[1;32m')
    c_red=$(printf '\033[1;31m');   c_yellow=$(printf '\033[1;33m')
    c_reset=$(printf '\033[0m')
else
    c_blue=''; c_green=''; c_red=''; c_yellow=''; c_reset=''
fi

# --- état global (réinitialisé par chaque script d'exercice) ---------------
SCORE=0        # étapes réussies
TOTAL=0        # étapes totales
HINTS_USED=0   # indices consommés
REVEALED=0     # réponses révélées (après épuisement des indices)
STEP_NO=0      # numéro d'étape courant
MAX_STEPS=0    # nombre total d'étapes (fixé par l'exercice)
REPORT=""      # chemin du rapport (fixé par l'exercice)
POINTS=5       # barème cible de l'objectif (fixé par l'exercice)
SKIP=0         # 1 si l'étape courante est déjà faite (reprise)
RESUME_STEP=0  # nombre d'étapes déjà terminées lors d'une reprise
STATE_FILE=""  # chemin du fichier d'état de la progression

# --- sortie élémentaire ----------------------------------------------------
say()     { printf '%s\n' "$*"; }
title()   { printf '\n%s\n' "${c_blue}== $* ==${c_reset}"; }
correct() { SCORE=$((SCORE+1)); say "${c_green}  [OK] Correct.${c_reset}"; }
wrong()   { say "${c_red}  [KO] ${1:-Incorrect.}${c_reset}"; }
hint()    { HINTS_USED=$((HINTS_USED+1)); say "${c_yellow}  Indice : $*${c_reset}"; }
reveal()  { REVEALED=$((REVEALED+1)); say "${c_yellow}  Réponse : $*${c_reset}"; }

record()  { printf '%s\n' "$*" >> "$REPORT"; }

# --- résistance à Ctrl+C + sortie contrôlée ---------------------------------
# Un Ctrl+C ne tue jamais la mission : il pose un drapeau, et read_or_quit
# propose « Quitter ? (o/n) ». « o » sauvegarde la progression et quitte ;
# sinon, on re-prompt SANS consommer d'indice ni compter de tentative.
INT_FLAG=0
on_int() { INT_FLAG=1; }
trap on_int INT

# --- sauvegarde / reprise de la progression ---------------------------------
# Un fichier d'état par objectif ($REPORT.state) mémorise l'étape en cours et
# les compteurs. Au relancement, begin le détecte et saute les étapes déjà
# faites (en conservant le score). finalize efface l'état.
save_state() {
    [ -n "$REPORT" ] || return 0
    STATE_FILE="$REPORT.state"
    {
        printf 'STEP_NO=%s\n' "$STEP_NO"
        printf 'SCORE=%s\n' "$SCORE"
        printf 'HINTS_USED=%s\n' "$HINTS_USED"
        printf 'REVEALED=%s\n' "$REVEALED"
    } > "$STATE_FILE"
}

load_state() {
    STATE_FILE="$REPORT.state"
    [ -f "$STATE_FILE" ] || return 1
    local saved_step=0 saved_score=0 saved_hints=0 saved_revealed=0
    while IFS='=' read -r _k _v; do
        case "$_k" in
            STEP_NO) saved_step=$_v ;;
            SCORE) saved_score=$_v ;;
            HINTS_USED) saved_hints=$_v ;;
            REVEALED) saved_revealed=$_v ;;
        esac
    done < "$STATE_FILE"
    SCORE=$saved_score
    HINTS_USED=$saved_hints
    REVEALED=$saved_revealed
    RESUME_STEP=$((saved_step - 1))
    [ "$RESUME_STEP" -lt 0 ] && RESUME_STEP=0
    STEP_NO=0
    return 0
}

confirm_quit() {
    printf 'Quitter la mission ? (o/n) '
    if ! read -r _q; then
        return 0   # EOF : on quitte par défaut
    fi
    case "$_q" in
        o|O|oui|y|Y|yes) return 0 ;;
        *) return 1 ;;
    esac
}

do_quit() {
    save_state
    if [ -n "$REPORT" ] && [ -f "$REPORT" ]; then
        record ""
        record "Progression : $SCORE/$MAX_STEPS étapes (mission interrompue)"
    fi
    say "${c_yellow}Progression sauvegardée. Relance le script pour reprendre.${c_reset}"
    exit 130
}

# --- lecture d'une réponse avec sortie contrôlée ----------------------------
# read_or_quit <variable> : lit dans $1 ; en cas de Ctrl+C, propose de quitter.
# retourne 0 si une valeur a été lue, 1 sinon (l'appelant re-prompte).
read_or_quit() {
    local _v="$1" _rc
    while true; do
        read -r "$_v"
        _rc=$?
        if [ "$_rc" -eq 0 ]; then
            INT_FLAG=0
            return 0
        fi
        if [ "$INT_FLAG" = "1" ]; then
            INT_FLAG=0
            say "${c_yellow}  (interrompu par Ctrl+C)${c_reset}"
        fi
        if confirm_quit; then
            do_quit
        fi
        return 1
    done
}

# --- demander le nom de l'étudiant (capture + question) --------------------
ask_name() {
    # capture système (toujours)
    SYS_USER=$(whoami 2>/dev/null || printf '%s' "$USER")
    SYS_HOST=$(hostname 2>/dev/null || printf 'inconnu')

    NAME_FILE="$LIB_DIR/.mission_name"
    if [ -s "$NAME_FILE" ]; then
        NAME=$(cat "$NAME_FILE")
    else
        printf 'Ton nom et prénom : '
        read -r NAME || NAME=''
        if [ -n "$NAME" ]; then
            printf '%s' "$NAME" > "$NAME_FILE" 2>/dev/null || true
        fi
    fi
    [ -n "$NAME" ] || NAME='(non renseigné)'
}

# --- init : en-tête du rapport ---------------------------------------------
begin() {
    # $1 = nom du rapport ; $2 = nombre d'étapes ; $3 = titre ;
    # $4 = libellé (ex TP03) ; $5 = points (défaut 5) ; $6 = bandeau (optionnel)
    REPORT="$LIB_DIR/$1"
    MAX_STEPS="$2"
    LABEL="${4:-TP}"
    POINTS="${5:-5}"
    STATE_FILE="$REPORT.state"
    RESUME_STEP=0
    SKIP=0

    if [ -n "${6:-}" ]; then
        say "${c_red}$6${c_reset}"
    else
        say "${c_red}Rappel : l'annexe du PDF (aide-mémoire) liste les commandes du TP.${c_reset}"
        say "${c_red}En cas de doute : \`man commande\`. Commande oubliée : \`man -k mot-clé\`.${c_reset}"
    fi

    ask_name

    if load_state; then
        say "${c_yellow}Reprise de la mission : tu reprends à l'étape $((RESUME_STEP+1))/$MAX_STEPS.${c_reset}"
        record ""
        record "--- Reprise ($(date '+%Y-%m-%d %H:%M:%S')) — étape $((RESUME_STEP+1)) ---"
    else
        rm -f "$REPORT"
        : > "$REPORT"
        record "================================================================"
        record "RAPPORT DE MISSION — $LABEL"
        record "$3"
        record "================================================================"
        record "Étudiant    : $NAME"
        record "Machine     : $SYS_USER@$SYS_HOST"
        record "Date        : $(date '+%Y-%m-%d %H:%M:%S')"
        record "================================================================"
        record ""
        record "--- Déroulé ---"
    fi
}

# --- signature : cksum (POSIX, portable) du corps du rapport ---------------
finalize() {
    record ""
    record "--- Score ---"
    record "Étapes réussies : $SCORE/$MAX_STEPS"

    # équivalent sur POINTS, arrondi entier
    if [ "$MAX_STEPS" -gt 0 ]; then
        EQ=$(( (SCORE * POINTS + MAX_STEPS / 2) / MAX_STEPS ))
    else
        EQ=0
    fi
    record "Équivalent /$POINTS : $EQ"
    record "Indices utilisés: $HINTS_USED"
    record "Réponses révélées: $REVEALED"
    record ""

    # signature du corps produit jusqu'ici (détecte une édition manuelle)
    SIG=$(cksum < "$REPORT")
    record "--- Signature ---"
    record "cksum: $SIG"
    record "================================================================"

    chmod 444 "$REPORT" 2>/dev/null || true
    rm -f "$STATE_FILE" 2>/dev/null || true

    title "Objectif terminé — score $SCORE/$MAX_STEPS (≈ $EQ/$POINTS)"
    say "${c_red}Rapport verrouillé en lecture seule — toute modification invalide la signature cksum.${c_reset}"
    say "Ton rapport est dans : $REPORT"
}

# --- une étape : énoncé + « fais-le dans ton terminal » --------------------
step() {
    STEP_NO=$((STEP_NO+1))
    if [ "$STEP_NO" -le "$RESUME_STEP" ]; then
        SKIP=1
        return 0
    fi
    SKIP=0
    TOTAL=$((TOTAL+1))
    printf '\n%s\n' "${c_yellow}Étape ${STEP_NO}/${MAX_STEPS}${c_reset}"
    say "$1"
    say "Fais-le dans TON terminal, puis reviens ici et appuie sur Entrée."
    read_or_quit _
    save_state
}

# --- question à réponse fixe (variantes acceptées, normalisées) ------------
# usage : q_fixed "question" "variante1|variante2" "indice1" "indice2" "indice3"
q_fixed() {
    local question="$1" expected="$2"; shift 2
    local hints=("$@") attempt=0 ans norm ok e IFS old_IFS="$IFS" revealed

    if [ "$SKIP" = "1" ]; then SKIP=0; return 0; fi

    while true; do
        say "$question"
        printf '> '
        if ! read_or_quit ans; then continue; fi
        record "Q${STEP_NO}. $question"
        record "   → réponse : « $ans »"

        norm=$(printf '%s' "$ans" | tr '[:upper:]' '[:lower:]' | sed 's/^[[:space:]]*//; s/[[:space:]]*$//' | tr -s ' ')

        ok=0
        IFS='|'
        for e in $expected; do
            [ "$norm" = "$e" ] && { ok=1; break; }
        done
        IFS="$old_IFS"

        if [ "$ok" = "1" ]; then
            correct
            return 0
        fi

        wrong
        if [ "$attempt" -lt "${#hints[@]}" ]; then
            record "   → indice  : ${hints[$attempt]}"
            hint "${hints[$attempt]}"
            attempt=$((attempt+1))
        else
            revealed=$(printf '%s' "$expected" | cut -d'|' -f1)
            record "   → réponse révélée : $revealed"
            reveal "$revealed"
            while true; do
                say "Répète la réponse pour continuer (l'étape reste notée 0) :"
                printf '> '
                if ! read_or_quit ans; then continue; fi
                norm=$(printf '%s' "$ans" | tr '[:upper:]' '[:lower:]' | sed 's/^[[:space:]]*//; s/[[:space:]]*$//' | tr -s ' ')
                ok=0
                IFS='|'
                for e in $expected; do
                    [ "$norm" = "$e" ] && { ok=1; break; }
                done
                IFS="$old_IFS"
                [ "$ok" = "1" ] && break
            done
            record "   → complété (révélé)"
            return 1
        fi
    done
}

# --- question « consultes le manuel » (recherche documentaire forcée) ------
# usage : q_man "doc à consulter" "question factuelle" "réponse|variantes" "i1" "i2" "i3"
q_man() {
    local doc="$1"; shift
    if [ "$SKIP" = "1" ]; then SKIP=0; return 0; fi
    record "Q${STEP_NO}. Doc : $doc"
    say "${c_blue}  Consulte : $doc${c_reset}"
    q_fixed "$@"
}

# --- question à choix multiples (QCM) --------------------------------------
# usage : q_choice "question" "choix1|choix2|choix3|choix4" N "i1" "i2" "i3"
# N = indice (1-based) du bon choix ; accepte le numéro (ex. "1", "1)") ou le texte.
q_choice() {
    # usage : q_choice "question" "choix1|choix2|choix3|choix4" N "i1" "i2" "i3"
    # N = numéro (1-based) du bon choix ; réponse par numéro uniquement.
    local question="$1" choices="$2" correct_idx="$3"; shift 3
    local hints=("$@") i=1 choice correct_text="" ans norm
    local old_IFS="$IFS" attempt=0

    if [ "$SKIP" = "1" ]; then SKIP=0; return 0; fi

    IFS='|'
    for choice in $choices; do
        [ "$i" = "$correct_idx" ] && correct_text="$choice"
        i=$((i+1))
    done
    IFS="$old_IFS"

    while true; do
        say "$question"
        i=1
        IFS='|'
        for choice in $choices; do
            say "  ${i}) $choice"
            i=$((i+1))
        done
        IFS="$old_IFS"
        printf '> '
        if ! read_or_quit ans; then continue; fi
        record "Q${STEP_NO}. $question"
        record "   → réponse : « $ans »"

        # ne garder que le numéro (tolère « 1) », « 1. », « 1: », espaces)
        norm=$(printf '%s' "$ans" | sed 's/^[[:space:]]*//; s/[[:space:]]*$//; s/[).:]$//')

        if [ "$norm" = "$correct_idx" ]; then
            correct
            return 0
        fi

        wrong
        if [ "$attempt" -lt "${#hints[@]}" ]; then
            record "   → indice  : ${hints[$attempt]}"
            hint "${hints[$attempt]}"
            attempt=$((attempt+1))
        else
            record "   → réponse révélée : ${correct_idx}) $correct_text"
            reveal "${correct_idx}) $correct_text"
            while true; do
                say "Répète le numéro pour continuer (l'étape reste notée 0) :"
                printf '> '
                if ! read_or_quit ans; then continue; fi
                norm=$(printf '%s' "$ans" | sed 's/^[[:space:]]*//; s/[[:space:]]*$//; s/[).:]$//')
                [ "$norm" = "$correct_idx" ] && break
            done
            record "   → complété (révélé)"
            return 1
        fi
    done
}

# --- question numérique (la vérité est calculée EN DIRECT, portable) -------
# usage : q_number "question" <valeur-attendue> "indice1" "indice2" "indice3"
q_number() {
    local question="$1" truth="$2"; shift 2
    local hints=("$@") attempt=0 ans

    if [ "$SKIP" = "1" ]; then SKIP=0; return 0; fi

    # normaliser la vérité (BSD wc padde le nombre, ex. "      42")
    truth=$(printf '%s' "$truth" | sed 's/^[[:space:]]*//; s/[[:space:]]*$//')

    while true; do
        say "$question"
        printf '> '
        if ! read_or_quit ans; then continue; fi
        record "Q${STEP_NO}. $question"
        record "   → réponse : « $ans »"

        ans=$(printf '%s' "$ans" | sed 's/^[[:space:]]*//; s/[[:space:]]*$//')

        if [ "$ans" = "$truth" ]; then
            correct
            return 0
        fi

        wrong
        if [ "$attempt" -lt "${#hints[@]}" ]; then
            record "   → indice  : ${hints[$attempt]}"
            hint "${hints[$attempt]}"
            attempt=$((attempt+1))
        else
            record "   → réponse révélée : $truth"
            reveal "$truth"
            while true; do
                say "Répète la réponse pour continuer (l'étape reste notée 0) :"
                printf '> '
                if ! read_or_quit ans; then continue; fi
                ans=$(printf '%s' "$ans" | sed 's/^[[:space:]]*//; s/[[:space:]]*$//')
                [ "$ans" = "$truth" ] && break
            done
            record "   → complété (révélé)"
            return 1
        fi
    done
}

# --- vérification de l'état réel du filesystem (aucune saisie) -------------
# usage : q_fs "description" 'test ...' "indice1" "indice2" "indice3" "réponse"
q_fs() {
    local desc="$1" testcmd="$2" h1="$3" h2="$4" h3="$5" answer="$6"
    local attempt=0

    if [ "$SKIP" = "1" ]; then SKIP=0; return 0; fi

    while true; do
        say "Je vérifie : $desc"
        record "Q${STEP_NO}. $desc"
        if eval "$testcmd"; then
            record "   → [OK] état vérifié"
            correct
            return 0
        fi
        record "   → état non conforme"
        wrong "État non conforme."
        if [ "$attempt" -eq 0 ]; then
            record "   → indice  : $h1"; hint "$h1"
        elif [ "$attempt" -eq 1 ]; then
            record "   → indice  : $h2"; hint "$h2"
        elif [ "$attempt" -eq 2 ]; then
            record "   → indice  : $h3"; hint "$h3"
        else
            record "   → réponse révélée : $answer"
            reveal "$answer"
            while ! eval "$testcmd"; do
                say "Corrige dans ton terminal (la commande est ci-dessus), puis reviens ici et appuie sur Entrée."
                read_or_quit _ || true
            done
            record "   → complété (révélé)"
            return 1
        fi
        attempt=$((attempt+1))
        say "Corrige dans ton terminal, puis reviens ici et appuie sur Entrée."
        read_or_quit _ || true
    done
}
