#!/usr/bin/env bash
# =============================================================================
# lab03_ex1.sh — Objectif 1 : De la commande au code source
# =============================================================================
. "$(dirname "${BASH_SOURCE[0]}")/lab03_lib.sh"

BANNER="Rappel : l'annexe du PDF (prototypes POSIX) + man 2 (appels système), man 3 (fonctions de bibliothèque), man gcc, strace --help. Fonction oubliée : man -k mot-clé."

begin "report_lab03_ex1.txt" 14 "Objectif 1 — De la commande au code source" "TP03" 7 "$BANNER"

title "Objectif 1 — Comprendre ce qu'est une commande"

# ---------------------------------------------------------------- Partie A --
step "Tape \`type cd\`. Pour comprendre ce que \`type\` t'affiche, consulte \`help type\` (ou l'annexe du TP)."

q_choice \
  "Que t'a dit \`type\` à propos de \`cd\` ?" \
  "que \`cd\` est un programme sur disque|que \`cd\` est intégré au shell (commande interne)|que \`cd\` n'existe pas|que \`cd\` est un fichier de données" \
  2 \
  "\`type cd\` ne t'a pas montré un chemin de fichier." \
  "\`cd\` fait partie du shell lui-même, pas un programme séparé." \
  "Relis la sortie de \`help type\` : que dit-il pour une commande intégrée ?"

step "Tape \`type ls\`. Pour comprendre ce que \`type\` t'affiche, consulte \`help type\` (ou l'annexe du TP)."

q_choice \
  "Que t'a dit \`type\` à propos de \`ls\` ?" \
  "que \`ls\` est intégré au shell|que \`ls\` n'existe pas|que \`ls\` est une variable d'environnement|que \`ls\` est un programme sur disque (commande externe)" \
  4 \
  "\`type ls\` t'a montré un chemin vers un fichier sur le disque." \
  "Contrairement à \`cd\`, \`ls\` est un vrai programme (fichier exécutable)." \
  "Relis la sortie de \`help type\` : que dit-il pour une commande qui est un programme ?"

step "Tape \`which ls\`. Pour comprendre son rôle, consulte \`man which\` (ou l'annexe du TP)."

q_choice \
  "À quoi sert la commande \`which\` ?" \
  "afficher le contenu d'un fichier|lister le contenu d'un répertoire|localiser (trouver le chemin d') une commande|afficher la date et l'heure" \
  3 \
  "\`which ls\` a affiché un chemin complet." \
  "Elle répond à la question : « où se trouve cette commande ? »." \
  "Consulte \`man which\`, section DESCRIPTION."

step "Tape \`echo \$PATH\`. Pour comprendre son rôle, consulte \`man bash\` et cherche la section \`PATH\` (ou l'annexe du TP)."

q_choice \
  "À quoi sert la variable \`PATH\` ?" \
  "indiquer au shell où chercher les commandes|afficher le répertoire courant|mémoriser le mot de passe de l'utilisateur|définir l'éditeur de texte par défaut" \
  1 \
  "Quand tu tapes \`ls\`, le shell parcourt cette liste pour le trouver." \
  "C'est grâce à elle qu'on tape \`ls\` sans son chemin complet." \
  "Dans \`man bash\`, cherche \`/PATH\` : sans elle, il faudrait le chemin complet."

# ---------------------------------------------------------------- Partie B --
step "Dans \`~/oslabs/lab03\`, tape \`wc -l myls.c\`. Ce fichier est le code source : pas encore un programme exécutable."

q_number \
  "Combien de lignes contient \`myls.c\` ? (un nombre)" \
  "$(wc -l < "$HOME/oslabs/lab03/myls.c" 2>/dev/null)" \
  "\`wc -l\` compte les lignes ; chaque ligne = une ligne de code ou de commentaire." \
  "\`myls.c\` est le code source complet de ta future commande." \
  "Le nombre est de l'ordre de la centaine (un peu plus de 180)."

step "Tape \`head -n 30 myls.c\` : observe les lignes \`#include\` en haut du fichier. Leur rôle est expliqué dans l'annexe du TP (tableau « Lire, compiler et installer »)."

q_choice \
  "À quoi servent les lignes \`#include\` ?" \
  "commenter le code pour le rendre lisible|importer des déclarations (donner accès à des fonctions)|compiler le programme|exécuter le programme" \
  2 \
  "Elles concernent des fichiers comme \`<stdio.h>\` ou \`<dirent.h>\`." \
  "Sans elles, le compilateur ne connaîtrait pas \`printf\` ou \`opendir\`." \
  "Relis la ligne \`#include\` dans l'annexe : elles relient ton code à des fonctions définies ailleurs."

step "Repère les \`#include\` : lequel te donne accès aux fonctions qui manipulent les répertoires ? Pour trouver sa description, consulte \`man 3 opendir\`."

q_choice \
  "Quel en-tête concerne les répertoires ?" \
  "<stdio.h>|<dirent.h>|<sys/stat.h>|<unistd.h>" \
  2 \
  "C'est l'un des \`#include\` en haut de \`myls.c\`." \
  "Son nom évoque les répertoires (« directory » en anglais)." \
  "Dans \`man 3 opendir\`, le SYNOPSIS montre l'en-tête requis, et la DESCRIPTION décrit les fonctions qu'il déclare."

step "Repère maintenant l'en-tête qui donne accès aux attributs des fichiers (taille, dates, permissions). Pour trouver sa description, consulte \`man 2 stat\`."

q_choice \
  "Quel en-tête concerne les attributs de fichiers ?" \
  "<dirent.h>|<string.h>|<sys/stat.h>|<errno.h>" \
  3 \
  "Il définit la structure \`stat\` (taille, dates, permissions)." \
  "Il se trouve dans un sous-dossier (\`sys/\`)." \
  "Dans \`man 2 stat\`, le SYNOPSIS liste le \`#include\` requis, et la DESCRIPTION décrit \`struct stat\`."

step "Tape \`man man\` : cette page explique que le manuel est découpé en sections. Repère la section 2 et la section 3."

q_choice \
  "Quelle est la différence entre la section 2 et la section 3 du manuel ?" \
  "la section 2 documente les appels système, la section 3 les fonctions de bibliothèque|la section 2 documente les commandes, la section 3 les fichiers de configuration|les deux documentent des appels système|la section 2 est pour Linux, la section 3 pour macOS" \
  1 \
  "Une section décrit ce que le noyau exécute ; l'autre, ce que la libc fournit." \
  "\`man 2 ...\` = appels système ; \`man 3 ...\` = fonctions de la bibliothèque C." \
  "Relis la rubrique « SECTIONS » de \`man man\`."

# ---------------------------------------------------------------- Partie C --
step "Ouvre \`myls.c\` avec \`less -N\`. Tape \`/opendir\` puis Entrée pour localiser l'appel (note son numéro de ligne), et \`n\`/\`N\` pour naviguer. Puis consulte \`man 3 opendir\`."

q_choice \
  "Que fait \`opendir()\` ?" \
  "read a directory entry|close the directory|open a directory|get file attributes" \
  3 \
  "Relis l'appel dans \`myls.c\` : que faut-il obtenir en premier pour lire un répertoire ?" \
  "Avant de lire des entrées, il faut d'abord obtenir un « pointeur » sur le répertoire." \
  "Consulte \`man 3 opendir\`, section DESCRIPTION : la première phrase donne le rôle."

step "Tape \`/readdir\` dans \`less -N myls.c\` pour localiser \`readdir\` (note la ligne), et \`n\`/\`N\` pour naviguer. Puis consulte \`man 3 readdir\`."

q_choice \
  "Que fait \`readdir()\` ?" \
  "open a directory|close the directory|create a directory|read a directory entry" \
  4 \
  "Dans \`myls.c\`, cette fonction est appelée en boucle pour obtenir chaque fichier un par un." \
  "Elle retourne un pointeur sur une entrée, ou \`NULL\` quand il n'y en a plus." \
  "Consulte \`man 3 readdir\`, section DESCRIPTION."

step "Tape \`/closedir\` dans \`less -N myls.c\` pour localiser \`closedir\` (note la ligne), et \`n\`/\`N\` pour naviguer. Puis consulte \`man 3 closedir\`."

q_choice \
  "Que fait \`closedir()\` ?" \
  "read a directory entry|close the directory|open a directory|get file attributes" \
  2 \
  "C'est le symétrique d'\`opendir\` : on libère ce qu'on avait ouvert." \
  "Une fois la lecture terminée, il faut rendre le descripteur de répertoire." \
  "Consulte \`man 3 closedir\`, section DESCRIPTION."

step "Tape \`/stat\` dans \`less -N myls.c\` pour localiser \`stat\` (note la ligne), et \`n\`/\`N\` pour naviguer. Puis consulte \`man 2 stat\` (cette fonction est documentée en section 2 : c'est un appel système)."

q_choice \
  "Que fait \`stat()\` ?" \
  "open a directory|read a directory entry|close the directory|get file attributes" \
  4 \
  "Dans \`myls.c\`, on l'utilise pour connaître la taille ou le type (dossier/fichier) d'une entrée." \
  "Il remplit une structure nommée \`struct stat\`." \
  "Consulte \`man 2 stat\`, section DESCRIPTION."

step "Tape \`/malloc\` dans \`less -N myls.c\` pour localiser l'allocation mémoire, et repère aussi le \`free\` correspondant plus bas."

q_choice \
  "À quoi sert \`malloc()\` dans \`myls.c\` ?" \
  "libérer de la mémoire|réserver (allouer) de la mémoire|compiler le programme|ouvrir un fichier" \
  2 \
  "La ligne \`Entree *entrees = malloc(sizeof(Entree) * 1000);\` prépare de la place en mémoire." \
  "Un appel à \`free()\` libère plus loin ce que \`malloc\` a réservé." \
  "Consulte \`man 3 malloc\` (section 3 : fonction de bibliothèque)."

finalize
