/*
 * TP3 (mission) -- Creer sa propre commande : myls
 *
 * Ce fichier est FOURNI COMPLET : vous n'avez rien a ecrire.
 * Votre mission est de comprendre le pipeline complet :
 *   code source -> compilation (gcc) -> installation (~/bin + PATH)
 *   -> execution -> observation (strace).
 *
 * Compilation :
 *     gcc -Wall -Wextra -o myls myls.c
 * Utilisation :
 *     ./myls [options] [repertoire]
 * Options : -a (fichiers caches), --size (tri par taille),
 *           --time (tri par date), --help
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <errno.h>

#define COLOR_RESET "\033[0m"
#define COLOR_BLUE  "\033[1;34m"
#define COLOR_GREEN "\033[1;32m"

/* Une entree du repertoire (nom + attributs + type). */
typedef struct {
    char nom[256];
    struct stat info;   /* attributs remplis par stat() */
    char type;          /* 'd' = dossier, 'f' = fichier */
} Entree;

/* Options de la ligne de commande. */
typedef struct {
    int tout;        /* -a     : afficher aussi les fichiers caches */
    int tri_taille;  /* --size : trier par taille (decroissant)    */
    int tri_date;    /* --time : trier par date (decroissant)      */
} Options;

/* ------------------------------------------------------------------ */
/*  Comparateurs pour qsort (fournis)                                  */
/* ------------------------------------------------------------------ */
static int cmp_nom(const void *a, const void *b) {
    return strcmp(((const Entree *)a)->nom, ((const Entree *)b)->nom);
}

static int cmp_taille(const void *a, const void *b) {
    return ((const Entree *)b)->info.st_size - ((const Entree *)a)->info.st_size;
}

static int cmp_date(const void *a, const void *b) {
    return ((const Entree *)b)->info.st_mtime - ((const Entree *)a)->info.st_mtime;
}

/* ------------------------------------------------------------------ */
/*  Affichage d'une entree (fourni)                                    */
/* ------------------------------------------------------------------ */
static void afficher(const Entree *e) {
    if (e->type == 'd') {
        printf("%s[DIR]  %s/%s\n", COLOR_BLUE, e->nom, COLOR_RESET);
    } else {
        printf("%s[FILE] %s%s (%ld octets)\n", COLOR_GREEN,
               e->nom, COLOR_RESET, (long)e->info.st_size);
    }
}

/* ------------------------------------------------------------------ */
/*  Aide (fournie)                                                     */
/* ------------------------------------------------------------------ */
static void aide(void) {
    printf("myls -- liste un repertoire avec un format personnalise\n\n");
    printf("Usage : myls [options] [repertoire]\n\n");
    printf("Options :\n");
    printf("  -a        afficher aussi les fichiers caches\n");
    printf("  --size    trier par taille (decroissant)\n");
    printf("  --time    trier par date de modification (decroissant)\n");
    printf("  --help    afficher cette aide\n");
}

/* ------------------------------------------------------------------ */
/*  Lister un repertoire (code complet)                                */
/* ------------------------------------------------------------------ */
static int lister(const char *chemin, Options *opts) {
    /* --- Etape 1 : ouvrir le repertoire ---------------------------- */
    /* opendir() est une fonction de bibliotheque (man 3) : dans le
       noyau, elle declenche l'appel systeme openat(). */
    DIR *dir = opendir(chemin);
    if (dir == NULL) {
        perror("opendir");
        return 1;
    }

    Entree *entrees = malloc(sizeof(Entree) * 1000);
    if (entrees == NULL) {
        perror("malloc");
        closedir(dir);
        return 1;
    }

    int nb = 0;
    struct dirent *e;

    /* --- Etape 2 : lire les entrees une a une ---------------------- */
    /* readdir() (man 3) depile les entrees d'un tampon rempli par
       l'appel systeme getdents64() : on ne voit donc PAS getdents64
       a chaque entree. */
    while ((e = readdir(dir)) != NULL) {
        /* ignorer les fichiers caches (sauf option -a) */
        if (e->d_name[0] == '.' && !opts->tout) {
            continue;
        }

        /* readdir ne donne que le NOM : on reconstruit le chemin
           complet avant d'appeler stat(). */
        char chemin_complet[1024];
        snprintf(chemin_complet, sizeof(chemin_complet), "%s/%s", chemin, e->d_name);

        /* stat() (man 2) remplit une struct stat avec les attributs
           (taille, dates, permissions). */
        struct stat info;
        if (stat(chemin_complet, &info) == -1) {
            perror("stat");
            continue;
        }

        strncpy(entrees[nb].nom, e->d_name, sizeof(entrees[nb].nom) - 1);
        entrees[nb].nom[sizeof(entrees[nb].nom) - 1] = '\0';
        entrees[nb].info = info;
        entrees[nb].type = S_ISDIR(info.st_mode) ? 'd' : 'f';
        nb++;
    }

    /* --- Etape 3 : fermer le repertoire ---------------------------- */
    /* closedir() (man 3) -> close() dans le noyau. */
    closedir(dir);

    /* --- Etape 4 : trier selon l'option ---------------------------- */
    if (opts->tri_taille) {
        qsort(entrees, nb, sizeof(Entree), cmp_taille);
    } else if (opts->tri_date) {
        qsort(entrees, nb, sizeof(Entree), cmp_date);
    } else {
        qsort(entrees, nb, sizeof(Entree), cmp_nom);
    }

    /* --- Affichage (fourni) --------------------------------------- */
    for (int i = 0; i < nb; i++) {
        afficher(&entrees[i]);
    }

    /* --- Etape 5 : pied de page ----------------------------------- */
    int dossiers = 0, fichiers = 0;
    long taille_totale = 0;
    for (int i = 0; i < nb; i++) {
        if (entrees[i].type == 'd') {
            dossiers++;
        } else {
            fichiers++;
            taille_totale += (long)entrees[i].info.st_size;
        }
    }
    printf("%d dossier(s), %d fichier(s), taille totale : %ld octets\n",
           dossiers, fichiers, taille_totale);

    free(entrees);
    return 0;
}

/* ------------------------------------------------------------------ */
/*  main (fourni)                                                      */
/* ------------------------------------------------------------------ */
int main(int argc, char *argv[]) {
    Options opts = {0, 0, 0};
    const char *chemin = ".";

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-a") == 0) {
            opts.tout = 1;
        } else if (strcmp(argv[i], "--size") == 0) {
            opts.tri_taille = 1;
        } else if (strcmp(argv[i], "--time") == 0) {
            opts.tri_date = 1;
        } else if (strcmp(argv[i], "--help") == 0) {
            aide();
            return 0;
        } else if (argv[i][0] != '-') {
            chemin = argv[i];
        } else {
            fprintf(stderr, "Option inconnue : %s\n", argv[i]);
            aide();
            return 1;
        }
    }

    return lister(chemin, &opts);
}
