#!/usr/bin/env bash
# =============================================================================
# lab06_ex3.sh — Objectif 3 : Débogage (BOSS)
# =============================================================================
. "$(dirname "${BASH_SOURCE[0]}")/lab06_lib.sh"

BANNER="Rappel : l'annexe du PDF (aide-mémoire) + bash --help (option -x), man bash. Éditeur : micro (micro -help)."

begin "report_lab06_ex3.txt" 12 "Objectif 3 — Débogage" "TP06" 5 "$BANNER"

title "Objectif 3 (BOSS) — Déboguer un script"

step "Consulte \`bash --help\` (ou \`man bash\`) et repère l'option \`-x\` : c'est l'outil de débogage du TP."

q_choice \
  "Que fait \`bash -x\` ?" \
  "il exécute sans afficher|il affiche chaque commande après expansion (trace)|il compile le script|il vérifie la syntaxe seulement" \
  2 \
  "Chaque ligne s'affiche précédée d'un \`+\` avant d'être exécutée." \
  "Elle montre la valeur réelle des variables après expansion." \
  "Le slide « bash -x et set -x »."

step "Dans \`~/oslabs/lab06/outils\`, crée deux fichiers de test \`data1.dat\` et \`data2.dat\`, puis copie le script à corriger : \`cp ~/oslabs/lab06/script_debug.sh .\`"

q_fs "data1.dat, data2.dat et script_debug.sh sont dans outils" \
  '[ -f "$HOME/oslabs/lab06/outils/data1.dat" ] && [ -f "$HOME/oslabs/lab06/outils/data2.dat" ] && [ -f "$HOME/oslabs/lab06/outils/script_debug.sh" ]' \
  "touch crée les fichiers de test." \
  "cp copie script_debug.sh depuis la racine de lab06." \
  "Vérifie avec \`ls ~/oslabs/lab06/outils\`." \
  "cd ~/oslabs/lab06/outils && touch data1.dat data2.dat && cp ~/oslabs/lab06/script_debug.sh ."

step "Lance \`bash -x script_debug.sh dat\`. Observe la première erreur."

q_choice \
  "Quelle erreur de syntaxe apparaît d'abord ?" \
  "un then manquant|un guillemet manquant|une variable non définie|un point-virgule manquant" \
  1 \
  "L'erreur mentionne un mot-clé attendu après une condition." \
  "Chaque \`if\` doit être suivi d'un \`then\`." \
  "Lis le message d'erreur : bash attend \`then\`."

step "Corrige ce premier bug, puis vérifie la syntaxe sans exécuter."

q_choice \
  "Quelle commande vérifie la syntaxe d'un script sans l'exécuter ?" \
  "bash -x|bash -n|bash -v|bash -e" \
  2 \
  "\`-n\` = no execution, analyse seulement." \
  "Si la syntaxe est correcte, bash -n n'affiche rien et retourne 0." \
  "bash --help liste les options."

step "Relance \`bash -x script_debug.sh dat\`. Une nouvelle erreur apparaît à l'exécution (un message « commande introuvable »)."

q_choice \
  "Quelle est la bonne affectation arithmétique ?" \
  "count = count + 1|count=\$((count+1))|count+1|count++" \
  2 \
  "Les espaces autour de \`=\` cassent l'affectation." \
  "La double parenthèse \$(()) fait de l'arithmétique." \
  "Le slide « Variables et traitement des données »."

step "Corrige l'affectation. Observe ce que provoquait la ligne fautive."

q_choice \
  "Que provoque \`count = count + 1\` (avec des espaces) ?" \
  "bash tente d'exécuter une commande nommée count|une erreur de syntaxe|rien|une boucle infinie" \
  1 \
  "Sans espaces, c'est une affectation ; avec, c'est une commande." \
  "Le message « count: command not found » l'indique." \
  "Rappel : en bash, pas d'espace autour de \`=\` pour affecter."

step "Dans la boucle, repère le test \`[ -f \$fichier ]\` et corrige la citation de la variable."

q_choice \
  "Pourquoi écrire \`[ -f \"\$fichier\" ]\` avec des guillemets ?" \
  "un nom de fichier contenant un espace casserait le test|c'est obligatoire en bash|pour aller plus vite|pour afficher le fichier" \
  1 \
  "Sans guillemets, un nom avec espace est découpé en plusieurs mots." \
  "C'est la règle « citez toujours vos variables »." \
  "Le slide « until et le piège des guillemets »."

step "Relance \`bash -x script_debug.sh dat\`. Cette fois, le script semble ne plus s'arrêter : il boucle indéfiniment."

q_choice \
  "Pourquoi la boucle \`while\` ne se termine-t-elle jamais ?" \
  "la condition ne change jamais (aucun incrément)|elle est trop rapide|le fichier est trop grand|il manque un done" \
  1 \
  "La condition teste \`\$count\`, mais rien ne modifie \$count dans la boucle." \
  "Si tu as dû interrompre, c'était avec Ctrl+C." \
  "Regarde : la boucle sert-elle à quelque chose ? On peut la supprimer."

step "Supprime cette boucle \`while\` inutile (c'est le bug 4)."

q_fs "la boucle while a été supprimée du script" \
  '! grep -q "while" "$HOME/oslabs/lab06/outils/script_debug.sh"' \
  "Cette boucle n'apporte rien au script : supprime-la entièrement." \
  "Ouvre le fichier avec micro et efface les trois lignes de la boucle." \
  "Après suppression, relance bash -x : le script doit se terminer seul." \
  'Supprimer ces 3 lignes : while [ $count -lt 10 ]; do / echo "en attente..." / done'

step "Relance \`bash script_debug.sh dat\` et observe la dernière ligne du résultat."

q_fixed \
  "Que vaut une variable non définie (ici \`\$coun\`) ?" \
  "vide|valeur vide|empty|rien" \
  "Regarde la ligne « Total :  fichier(s) » : le nombre est absent." \
  "Une faute de frappe (\$coun au lieu de \$count) crée une variable vide." \
  "bash remplace une variable non définie par la chaîne vide."

step "Corrige la faute de frappe (remplace \`\$coun\` par \`\$count\`), puis relance \`bash script_debug.sh dat\`."

q_fs "la ligne finale affiche le bon total" \
  'cd "$HOME/oslabs/lab06/outils"; n=0; for f in *.dat; do [ -e "$f" ] && n=$((n+1)); done; out=$(bash "$HOME/oslabs/lab06/outils/script_debug.sh" dat 2>/dev/null | tail -n 1); [ "$out" = "Total : $n fichier(s) .dat" ]' \
  "Le total doit être « Total : N fichier(s) .dat »." \
  "N est le nombre de fichiers .dat présents dans outils." \
  "Si ça boucle encore, revois l'étape de la boucle while." \
  'Remplacer $coun par $count : echo "Total : $count fichier(s) .$ext"'

step "Relis tes scripts avec un voisin et note une amélioration possible dans chacun."

q_fixed \
  "Quelle option de bash a servi, tout au long de cet objectif, à tracer l'exécution ?" \
  "bash -x|-x|x" \
  "C'est l'option qui affiche chaque commande avant son exécution." \
  "Elle s'écrit en un trait d'union et une lettre." \
  "C'est la première chose consultée dans cet objectif."

finalize
