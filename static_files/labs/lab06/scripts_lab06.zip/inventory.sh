#!/bin/bash
# inventory.sh — inventaire du parc de serveurs (squelette à compléter)
# Usage : ./inventory.sh [-v] <liste|compte|aide>

MACHINES="$HOME/oslabs/lab06/outils/machines.txt"

# TODO 1 : avant de lire les machines, vérifier que le fichier des machines
#          existe ; sinon afficher un message d'erreur et sortir.

# TODO 2 : écrire la fonction qui affiche le mode d'emploi du script.

# TODO 3 : écrire la fonction qui raccourcit un nom de machine
#          (elle reçoit un nom complet et affiche le nom court).

# TODO 4 : analyser l'option -v (mode verbeux) puis décaler les paramètres ;
#          en mode verbeux, afficher une ligne d'information au début.

# TODO 5 : écrire le menu qui aiguille selon l'action demandée :
#          afficher les machines (en noms courts), les compter, ou l'aide.
