#!/bin/bash
# script_debug.sh — compte les fichiers d'une extension donnee
# VOLONTAIREMENT BOQUE : 5 bugs a corriger au TP6.

if [ "$1" = "" ]
    echo "Usage: $0 <extension>"
    exit 1
fi

ext="$1"
count=0

echo "Recherche des fichiers *.$ext ..."

for fichier in *.$ext
do
    if [ -f $fichier ]; then
        echo "Trouvé : $fichier"
        count = count + 1
    fi
done

while [ $count -lt 10 ]; do
    echo "en attente..."
done

echo "Total : $coun fichier(s) .$ext"
