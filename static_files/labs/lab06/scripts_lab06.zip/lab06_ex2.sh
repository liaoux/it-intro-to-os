#!/usr/bin/env bash
# =============================================================================
# lab06_ex2.sh — Objectif 2 : Conditions, boucles, fonctions et options
# =============================================================================
. "$(dirname "${BASH_SOURCE[0]}")/lab06_lib.sh"

BANNER="Rappel : l'annexe du PDF (aide-mémoire) + help test, help case, man bash (boucles, getopts, fonctions). Éditeur : micro (micro -help)."

begin "report_lab06_ex2.txt" 12 "Objectif 2 — Conditions, boucles, fonctions et options" "TP06" 5 "$BANNER"

title "Objectif 2 — Automatiser l'inventaire du parc (inventory.sh)"

step "Consulte \`help test\` (ou \`man test\`) : les tests de fichiers vont servir à valider tes scripts."

q_choice \
  "Que teste \`[ -f fichier ]\` ?" \
  "que fichier existe et est un fichier régulier|que fichier est exécutable|que fichier est vide|que fichier est un dossier" \
  1 \
  "-d teste un dossier, -x l'exécution." \
  "-f signifie « file », un fichier ordinaire." \
  "help test / le slide « Tests de fichiers -f -d -r… »."

step "Copie le squelette ET les données dans ton dossier de travail : \`cp ~/oslabs/lab06/inventory.sh ~/oslabs/lab06/machines.txt ~/oslabs/lab06/outils/\`."

q_fs "outils/inventory.sh et outils/machines.txt existent" \
  '[ -f "$HOME/oslabs/lab06/outils/inventory.sh" ] && [ -f "$HOME/oslabs/lab06/outils/machines.txt" ]' \
  "cp copie un ou plusieurs fichiers vers une cible." \
  "Le squelette inventory.sh et les données machines.txt sont à la racine de lab06." \
  "Vérifie avec \`ls ~/oslabs/lab06/outils\`." \
  "cp ~/oslabs/lab06/inventory.sh ~/oslabs/lab06/machines.txt ~/oslabs/lab06/outils/"

step "Ouvre \`outils/inventory.sh\` avec \`micro\`. Lis l'en-tête et repère les blocs \`TODO\` numérotés (1 à 5)."

q_choice \
  "À quoi sert le shebang ?" \
  "indiquer l'interpréteur qui exécute le script|commenter le script|compiler le script|changer le répertoire courant" \
  1 \
  "Il pointe vers /bin/bash." \
  "Sans lui, le noyau ne sait pas comment exécuter le fichier." \
  "C'est la première ligne du fichier."

step "Affiche le contenu de \`machines.txt\` : depuis \`~/oslabs/lab06/outils\`, tape \`head machines.txt\`. Observe le format d'une ligne."

q_choice \
  "Que contient chaque ligne de machines.txt ?" \
  "un nom de serveur complet avec un domaine (ex. web01.prod.example.com)|un numéro de port réseau|une adresse IP|un chemin de fichier" \
  1 \
  "Chaque ligne est un hôte : un nom suivi d'un domaine." \
  "Le point sépare le nom de la machine de son domaine." \
  "Relis \`head machines.txt\` : la première ligne est web01.prod.example.com."

step "Complète le TODO 1 : avant de lire les machines, un \`if\` qui vérifie que le fichier existe (\`-f\`), sinon affiche une erreur et \`exit 1\`."

q_fs "le script contient le test d'existence (if + -f)" \
  'grep -q "then" "$HOME/oslabs/lab06/outils/inventory.sh" && grep -q -- "-f" "$HOME/oslabs/lab06/outils/inventory.sh"' \
  "Le \`if\` s'écrit avec \`then\`, et le test de fichier avec \`-f\`." \
  "Le fichier à tester est \`\$MACHINES\` (déjà défini en haut du squelette)." \
  "Si le test échoue, affiche un message puis \`exit 1\`." \
  'if [ ! -f "$MACHINES" ]; then echo "Erreur : machines.txt introuvable"; exit 1; fi'

step "Complète le TODO 2 : la fonction \`usage()\`. Elle affiche le mode d'emploi : \`Usage : \$0 [-v] <liste|compte|aide>\`. Tu l'appelleras plus tard dans la branche \`aide\` (ou \`*\`) du menu."

q_fs "la fonction usage() est définie" \
  'grep -q "usage" "$HOME/oslabs/lab06/outils/inventory.sh"' \
  "La syntaxe d'une fonction est \`nom() { ... }\`." \
  "Elle affiche le mode d'emploi du script (avec \`echo\`)." \
  "Relis le slide « Définir et appeler une fonction »." \
  'usage() { echo "Usage : $0 [-v] <liste|compte|aide>"; }'

step "Complète le TODO 3 : la fonction \`nom_court()\`. Elle reçoit en premier paramètre (\`\$1\`) un nom complet comme \`web01.prod.example.com\`, et affiche le nom court \`web01\` grâce à \`\${1%%.*}\`. Tu l'appelleras plus tard, dans la branche \`liste\` du menu, une fois par ligne."

q_fs "la fonction nom_court() est définie (avec l'expansion %%)" \
  'grep -q "nom_court" "$HOME/oslabs/lab06/outils/inventory.sh" && grep -q -- "%%" "$HOME/oslabs/lab06/outils/inventory.sh"' \
  "La syntaxe d'une fonction est \`nom() { ... }\`." \
  "\${1%%.*} retire tout ce qui suit le premier point (le domaine)." \
  "Relis le slide « Suppression de préfixe et de suffixe »." \
  'nom_court() { echo "${1%%.*}"; }'

step "Complète le TODO 4 : l'option \`-v\` avec \`getopts\` (drapeau VERBEUX), puis \`shift\`, et en mode verbeux une ligne \`[INFO] mode verbeux\`. Consulte \`help getopts\`."

q_fs "le script analyse l'option -v (getopts)" \
  'grep -q "getopts" "$HOME/oslabs/lab06/outils/inventory.sh"' \
  "La boucle \`getopts \"v\" opt\` parcourt l'option \`-v\`." \
  "Après, \`shift \$((OPTIND-1))\` laisse les arguments restants." \
  "En mode verbeux, affiche \`[INFO] mode verbeux\` au début." \
  'VERBEUX=0; while getopts "v" opt; do case "$opt" in v) VERBEUX=1 ;; esac; done; shift $((OPTIND-1)); [ "$VERBEUX" -eq 1 ] && echo "[INFO] mode verbeux"'

step "Complète le TODO 5 : le menu (\`case\` sur \`\$1\`). Branche \`liste\` → une boucle \`while read\` qui appelle \`nom_court\` sur chaque ligne ; branche \`compte\` → \`wc -l < \"\$MACHINES\"\` ; branche \`aide\` (ou \`*\`) → \`usage\`."

q_fs "le menu (case) est écrit" \
  'grep -Fq "liste)" "$HOME/oslabs/lab06/outils/inventory.sh"' \
  "Un \`case\` aiguille selon \`\$1\` ; chaque branche se termine par \`;;\`." \
  "Dans \`liste\`, appelle \`nom_court\` ; dans \`aide\` (ou \`*\`), appelle \`usage\`." \
  "La branche \`compte\` n'a besoin que de \`wc -l\`." \
  'case "$1" in liste) while read -r ligne; do nom_court "$ligne"; done < "$MACHINES" ;; compte) wc -l < "$MACHINES" ;; aide|*) usage ;; esac'

step "Lance \`./inventory.sh compte\` et lis le nombre affiché."

q_number \
  "Combien de serveurs affiche ./inventory.sh compte ? (un nombre)" \
  "$(wc -l < "$HOME/oslabs/lab06/outils/machines.txt" 2>/dev/null)" \
  "La branche compte affiche le nombre de lignes de machines.txt." \
  "Chaque ligne du fichier est un serveur." \
  "Ce nombre est le nombre de lignes de machines.txt."

step "Lance \`./inventory.sh liste\` et regarde la première ligne."

q_fs "la première ligne de « liste » est le nom court web01" \
  '[ "$(bash "$HOME/oslabs/lab06/outils/inventory.sh" liste 2>/dev/null | head -n1)" = "web01" ]' \
  "Dans la branche liste, appelle \`nom_court\` sur chaque ligne lue." \
  "web01.prod.example.com doit devenir web01." \
  "Si tu vois encore le domaine, vérifie que liste appelle bien nom_court." \
  'while read -r ligne; do nom_court "$ligne"; done < "$MACHINES"'

step "Teste le mode verbeux : lance \`./inventory.sh -v compte\`."

q_fs "l'option -v affiche le mode verbeux" \
  'out=$(bash "$HOME/oslabs/lab06/outils/inventory.sh" -v compte 2>/dev/null); printf "%s\n" "$out" | grep -q "verbeux"' \
  "Quand VERBEUX vaut 1, le script doit afficher [INFO] mode verbeux." \
  "Le test du drapeau doit venir APRÈS getopts et le shift." \
  "Vérifie que getopts met bien VERBEUX à 1 avant le shift." \
  'VERBEUX=0; while getopts "v" opt; do case "$opt" in v) VERBEUX=1 ;; esac; done; shift $((OPTIND-1)); [ "$VERBEUX" -eq 1 ] && echo "[INFO] mode verbeux"'

finalize
