#!/usr/bin/env bash
# =============================================================================
# lab06_ex1.sh — Objectif 1 : Écrire son premier script
# =============================================================================
. "$(dirname "${BASH_SOURCE[0]}")/lab06_lib.sh"

BANNER="Rappel : l'annexe du PDF (aide-mémoire) + man bash, help chmod, help test, help exit. Éditeur : micro (micro -help)."

begin "report_lab06_ex1.txt" 12 "Objectif 1 — Écrire son premier script" "TP06" 5 "$BANNER"

title "Objectif 1 — Écrire son premier script (hello.sh)"

step "Consulte \`bash --help\` (ou \`man bash\`). Un script shell est un fichier texte que le shell exécute ligne par ligne. Ce TP te fait écrire tes propres scripts avec l'éditeur \`micro\`."

q_choice \
  "Quelle ligne tout script bash doit-il avoir en tout premier ?" \
  "#!/bin/bash (le shebang)|# ceci est un commentaire|#!/usr/bin/python|exit 0" \
  1 \
  "Elle commence par \`#!\` suivi du chemin d'un interpréteur." \
  "Sans elle, le noyau ne sait pas quel programme doit interpréter le fichier." \
  "Le slide « Le shebang et les commentaires » décrit cette ligne."

step "Crée le dossier \`~/oslabs/lab06/outils\` avec \`mkdir -p\`, place-toi dedans (\`cd ~/oslabs/lab06/outils\`), puis crée le fichier \`hello.sh\` DANS ce dossier avec \`touch\`."

q_fs "~/oslabs/lab06/outils/hello.sh existe" \
  '[ -f "$HOME/oslabs/lab06/outils/hello.sh" ]' \
  "mkdir -p crée le dossier outils dans lab06." \
  "touch crée un fichier vide." \
  "Vérifie avec \`ls ~/oslabs/lab06/outils\` que hello.sh est présent." \
  "mkdir -p ~/oslabs/lab06/outils && touch ~/oslabs/lab06/outils/hello.sh"

step "Ouvre \`~/oslabs/lab06/outils/hello.sh\` avec \`micro\` (tape \`micro -help\` si tu ne connais pas les raccourcis). Écris exactement ces 3 lignes : la ligne shebang \`#!/bin/bash\`, une variable \`nom=\"Etudiant\"\`, puis \`echo \"Bonjour \$nom\"\`."

q_fs "hello.sh commence par le shebang" \
  'head -n 1 "$HOME/oslabs/lab06/outils/hello.sh" | grep -q "^#!"' \
  "La toute première ligne commence par #!." \
  "micro : Ctrl+S sauvegarde, Ctrl+Q quitte." \
  "Le shebang indique l'interpréteur (/bin/bash)." \
  'micro ~/oslabs/lab06/outils/hello.sh puis écrire : #!/bin/bash, nom="Etudiant", echo "Bonjour $nom"'

step "Rends \`hello.sh\` exécutable avec \`chmod\`. Consulte \`help chmod\` ou l'annexe."

q_fs "hello.sh est exécutable" \
  '[ -x "$HOME/oslabs/lab06/outils/hello.sh" ]' \
  "chmod +x ajoute le droit d'exécution." \
  "ls -l affiche les permissions (r, w, x)." \
  "help chmod / le slide « Rendre le script exécutable »." \
  "chmod +x ~/oslabs/lab06/outils/hello.sh"

step "Exécute \`./hello.sh\` (place-toi dans \`~/oslabs/lab06/outils\` si besoin)."

q_choice \
  "Pourquoi faut-il le préfixe \`./\` pour lancer ton script ?" \
  "parce que le script est lent|parce que le répertoire courant n'est pas cherché par défaut (PATH)|parce que le script est un fichier caché|pour éviter une erreur de syntaxe" \
  2 \
  "Le shell ne cherche les commandes que dans les dossiers listés dans PATH." \
  "Sans ./, il répondrait « commande introuvable »." \
  "PATH ne contient jamais le répertoire courant par défaut (sécurité)."

step "Lance aussi \`bash hello.sh\` puis \`source hello.sh\`. Consulte \`help source\`."

q_choice \
  "Quelle différence entre \`./hello.sh\` et \`source hello.sh\` ?" \
  "source exécute dans le shell courant (les changements persistent)|les deux sont identiques|./hello.sh est plus rapide|source recompile le script" \
  1 \
  "L'un crée un sous-processus, l'autre non." \
  "help source l'explique explicitement." \
  "Avec source, une variable définie reste visible après l'exécution."

step "Modifie \`hello.sh\` (avec \`micro\`) : remplace la ligne \`echo\` par \`echo \"Bonjour \$1\"\` pour afficher « Bonjour » suivi du premier argument (tu peux supprimer la ligne \`nom=...\`). Lance \`./hello.sh Etudiant\`."

q_fs "hello.sh Etudiant affiche « Bonjour Etudiant »" \
  '[ "$(bash "$HOME/oslabs/lab06/outils/hello.sh" Etudiant 2>/dev/null)" = "Bonjour Etudiant" ]' \
  "\$1 est le premier argument de la ligne de commande." \
  "echo \"Bonjour \$1\" (guillemets doubles pour l'expansion)." \
  "Relance ./hello.sh Etudiant après avoir sauvegardé (Ctrl+S, Ctrl+Q)." \
  'echo "Bonjour $1"   (dans hello.sh)   puis   ./hello.sh Etudiant'

step "Ajoute une variable qui mémorise le résultat d'une commande : la date. Consulte \`man date\`."

q_choice \
  "Qu'est-ce que \`\$(commande)\` ?" \
  "une erreur de syntaxe|la substitution de commande (remplacée par la sortie de la commande)|une variable d'environnement|un commentaire" \
  2 \
  "Elle capture la sortie standard de la commande." \
  "Le résultat peut être rangé dans une variable." \
  "man bash, section « Command Substitution »."

step "Fais échouer une commande : \`ls fichier_inexistant\`, puis affiche le code de retour avec \`echo \$?\`."

q_choice \
  "Que vaut \`\$?\` après une commande qui échoue ?" \
  "toujours 0|un code non nul (différent de 0)|toujours 255|rien du tout" \
  2 \
  "0 signifie succès." \
  "Un échec renvoie un code strictement positif." \
  "man bash : \$? contient le statut de la dernière commande."

step "Ajoute une validation : si aucun argument n'est fourni (\`\$#\` vaut 0), affiche \`Usage: hello.sh <nom>\` puis sors avec \`exit 1\`. Consulte \`help test\` pour \`[ ]\`."

q_fs "hello.sh sans argument affiche l'aide et retourne 1" \
  'out=$(bash "$HOME/oslabs/lab06/outils/hello.sh" 2>/dev/null); rc=$?; [ "$rc" -eq 1 ] && [ -n "$out" ]' \
  "\$# compte le nombre d'arguments." \
  "if [ \$# -eq 0 ]; then ...; exit 1; fi" \
  "help test documente les comparaisons numériques -eq / -ne." \
  'if [ $# -eq 0 ]; then echo "Usage: hello.sh <nom>"; exit 1; fi'

step "Vérifie que \`./hello.sh Etudiant\` fonctionne toujours avec l'argument."

q_fs "hello.sh Etudiant affiche encore « Bonjour Etudiant »" \
  '[ "$(bash "$HOME/oslabs/lab06/outils/hello.sh" Etudiant 2>/dev/null)" = "Bonjour Etudiant" ]' \
  "La validation ne doit s'exécuter que lorsqu'il n'y a aucun argument." \
  "Relance ./hello.sh Etudiant." \
  "Vérifie que le bloc if ne capture pas le cas où \$# vaut 1." \
  "echo \"Bonjour \$1\" (le if ne se déclenche que si \$# -eq 0)"

step "Relis ton script et note la différence entre \`exit 0\` et \`exit 1\`. Consulte \`help exit\`."

q_fixed \
  "Quel code de sortie signifie « succès » par convention ?" \
  "0" \
  "0 = succès, tout autre code = échec." \
  "C'est le code que lit \$?." \
  "help exit / le slide « Le statut de sortie et exit »."

finalize
