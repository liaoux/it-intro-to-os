#!/usr/bin/env bash
# =============================================================================
# lab07_ex3.sh — Objectif 3 : espace disque avec df et du
# =============================================================================
. "$(dirname "${BASH_SOURCE[0]}")/lab07_lib.sh"

if [ "$PWD" != "$HOME/oslabs/lab07" ]; then
    printf '%s\n' "Ce script doit etre lance depuis ~/oslabs/lab07."
    printf '%s\n' "Tape : cd ~/oslabs/lab07 && bash $(basename "$0")"
    exit 1
fi

BANNER="Rappel : l'annexe du PDF (inodes, allocation, superbloc) + \`man df\`, \`man du\`. Ces deux commandes sont découvertes en séance via leur page de manuel. Recherche dans un manuel : \`man commande | grep -e '-option'\` (motif commençant par un tiret)."

begin "report_lab07_ex3.txt" 13 "Objectif 3 — Espace disque : df et du" "TP07" 5 "$BANNER"

title "Objectif 3 — Surveiller le disque avant l'expédition"

# ---------------------------------------- garde-fou : répertoire du TP -------
step "Place-toi dans le dossier du TP (\`~/oslabs/lab07\`) et vérifie avec \`pwd\`."

q_fs "tu es bien dans ~/oslabs/lab07" \
  '[ "$PWD" = "$HOME/oslabs/lab07" ]' \
  "Tape \`pwd\` : le chemin affiché doit être celui du dossier du TP." \
  "Le dossier du TP est ~/oslabs/lab07." \
  "Si nécessaire, utilise \`cd\` avec un chemin absolu avant de continuer." \
  "cd ~/oslabs/lab07 && pwd"

# ------------------------------------------------ man df --------------------
step "Consulte \`man df\` (rubrique DESCRIPTION)."

q_choice \
  "Que montre \`df\` ?" \
  "la taille de chaque fichier|espace total, utilisé et libre par système de fichiers|le contenu des répertoires|la liste des inodes" \
  2 \
  "L'abréviation vient de « disk free »." \
  "La sortie a des colonnes du genre Size, Used, Avail." \
  "Dans \`man df\`, lis la première phrase de la DESCRIPTION."

# ------------------------------------------------ df -k ---------------------
step "Affiche l'espace des systèmes de fichiers en blocs de 1 Ko."

q_fixed \
  "Recopie la commande exacte que tu as tapée (ne la colle pas)." \
  "df -k|df -k .|df -k /|df -k ~" \
  "\`man df\` liste l'option qui affiche des blocs de 1 Ko." \
  "L'option est une lettre unique." \
  "C'est \`df\` suivi d'une option."

# ------------------------------------------------ man du --------------------
step "Consulte \`man du\` (rubrique DESCRIPTION)."

q_choice \
  "Que mesure \`du\` ?" \
  "l'espace disque occupé par des fichiers et des répertoires|le temps d'utilisation du processeur|les permissions d'un fichier|le nombre d'inodes libres" \
  1 \
  "L'abréviation vient de « disk usage »." \
  "Sans option, il descend récursivement dans les répertoires." \
  "Dans \`man du\`, lis la première phrase de la DESCRIPTION."

# ------------------------------------------------ du dossier ----------------
step "Mesure l'espace occupé par \`dossier/\` en Ko, en n'affichant que le total."

q_number \
  "Combien de Ko ? (un nombre)" \
  "$(du -k -s "$HOME/oslabs/lab07/dossier" 2>/dev/null | awk '{print $1}')" \
  "L'option de résumé évite la liste détaillée." \
  "L'unité se choisit avec une option de \`du\`." \
  "\`man du\` : cherche « summarize » et les unités."

# ------------------------------------------------ taille vs blocs ----------
step "Compare \`ls -l dossier/test.txt\` (octets) et \`du -k dossier/test.txt\` (Ko)."

q_choice \
  "Pourquoi les deux valeurs diffèrent-elles ?" \
  "du est bogué|le système alloue des blocs entiers : l'espace occupé est arrondi au bloc|ls arrondit les tailles|du compte les inodes" \
  2 \
  "Un fichier occupe au minimum un bloc." \
  "Le bloc fait souvent 4 Ko." \
  "Cours sur l'allocation : l'unité d'allocation est le bloc, pas l'octet."

# ------------------------------------------------ superbloc ----------------
step "Relis tes notes sur la structure d'un système de fichiers (bloc d'amorçage, superbloc, table d'inodes, blocs de données)."

q_choice \
  "Quelle structure décrit globalement le système de fichiers et son espace ?" \
  "l'inode|le superbloc|le répertoire|le bloc d'amorçage" \
  2 \
  "Ce n'est pas une structure par fichier." \
  "Elle contient la taille des blocs et le nombre d'inodes." \
  "Cours « Le superbloc »."

# ------------------------------------------------ allocation --------------
step "Rappelle le tableau « Comparaison des méthodes d'allocation »."

q_choice \
  "Quelle méthode d'allocation souffre de fragmentation externe ?" \
  "chaînée|indexée|contiguë|extents" \
  3 \
  "Les blocs d'un fichier y sont forcément consécutifs." \
  "Les trous entre fichiers deviennent inutilisables." \
  "Cours « Allocation contiguë »."

# ------------------------------------------------ allocation indexée ------
step "Toujours dans ce tableau : quelle méthode concilie accès direct et absence de fragmentation ?"

q_choice \
  "Quelle méthode ?" \
  "contiguë|chaînée|indexée (principe de l'inode)|aucune" \
  3 \
  "Les pointeurs sont regroupés dans un ou des blocs d'index." \
  "L'inode Unix en est l'exemple." \
  "Cours « Allocation indexée »."

# ------------------------------------------------ relevé -------------------
step "Enregistre le relevé de l'espace disque dans \`dossier/usage.txt\`."

q_fs "dossier/usage.txt existe et n'est pas vide" \
  '[ -s "$HOME/oslabs/lab07/dossier/usage.txt" ]' \
  "La redirection \`>\` écrit la sortie dans un fichier." \
  "Le relevé vient de \`df\`." \
  "Tu dois écrire dans ~/oslabs/lab07/dossier/usage.txt." \
  "cd ~/oslabs/lab07/dossier && df -k > usage.txt"

# ------------------------------------------------ du dossier du TP --------
step "Mesure l'espace occupé par tout le dossier du TP, total seul."

q_number \
  "Combien de Ko ? (un nombre)" \
  "$(du -k -s "$HOME/oslabs/lab07" 2>/dev/null | awk '{print $1}')" \
  "Le dossier du TP est le parent du dossier \`dossier/\`." \
  "Même option de résumé que tout à l'heure." \
  "Vérifie le chemin avec \`pwd\`."

# ------------------------------------------------ df vs du ----------------
step "Réfléchis à ce que tu viens d'exécuter avec les deux commandes."

q_choice \
  "Quelle est la différence essentielle entre \`df\` et \`du\` ?" \
  "aucune|df interroge les métadonnées globales du système de fichiers ; du parcourt les répertoires et additionne|du interroge le superbloc ; df parcourt les fichiers|df et du mesurent la même chose, en unités différentes" \
  2 \
  "L'un lit une information globale." \
  "L'autre doit visiter chaque fichier." \
  "Cours « Le superbloc » + \`man du\` (traverse les répertoires)."

# ------------------------------------------------ transcription -----------
step "De mémoire, sans relire ton historique, reconstruis la commande qui a donné le total du dossier \`dossier/\`."

q_fixed \
  "Quelle commande ? (recopie-la sans la coller)" \
  "du -k -s dossier|du -ks dossier|du -sk dossier|du -s -k dossier|du -k -s dossier/|du -ks dossier/|du -sk dossier/|du -s -k dossier/" \
  "Commande et trois éléments : une option d'unité, une option de résumé, un chemin." \
  "L'unité est le Ko ; le résumé tient en une lettre." \
  "C'est \`du\` suivi des options puis du répertoire."

finalize
