#!/usr/bin/env bash
# =============================================================================
# lab07_ex2.sh — Objectif 2 : copie, lien physique et lien symbolique
# =============================================================================
. "$(dirname "${BASH_SOURCE[0]}")/lab07_lib.sh"

if [ "$PWD" != "$HOME/oslabs/lab07" ]; then
    printf '%s\n' "Ce script doit etre lance depuis ~/oslabs/lab07."
    printf '%s\n' "Tape : cd ~/oslabs/lab07 && bash $(basename "$0")"
    exit 1
fi

BANNER="Rappel : l'annexe du PDF (liens physiques/symboliques) + \`man ln\`, \`man ls\`, \`man test\`. Slides du cours : 69-74 (lien physique, lien symbolique, comparaison, exemple ln/ln -s). On travaille dans \`dossier/\` sur la copie \`cible.txt\` créée à l'Objectif 1. Recherche dans un manuel : \`man commande | grep -e '-option'\` (motif commençant par un tiret)."

begin "report_lab07_ex2.txt" 14 "Objectif 2 — Copie, lien physique et lien symbolique" "TP07" 5 "$BANNER"

title "Objectif 2 — Recopier ou lier : la question de l'analyse"

# ---------------------------------------- garde-fou : répertoire du TP -------
step "Place-toi dans le dossier du TP (\`~/oslabs/lab07\`) et vérifie avec \`pwd\`."

q_fs "tu es bien dans ~/oslabs/lab07" \
  '[ "$PWD" = "$HOME/oslabs/lab07" ]' \
  "Tape \`pwd\` : le chemin affiché doit être celui du dossier du TP." \
  "Le dossier du TP est ~/oslabs/lab07." \
  "Si nécessaire, remonte ou redescends dans l'arborescence avant de continuer." \
  "cd ~/oslabs/lab07 && pwd"

# ------------------------------------------------ man ln --------------------
step "Consulte \`man ln\` (rubrique DESCRIPTION)."

q_choice \
  "Que fait la commande \`ln\`, sans option ?" \
  "elle copie le fichier|elle crée un nouveau nom (lien physique) pour un fichier existant|elle déplace le fichier|elle supprime un lien" \
  2 \
  "Un lien n'est pas une copie." \
  "Les deux noms désignent le même inode." \
  "Dans \`man ln\`, cherche l'expression « hard link »."

# ------------------------------------------------ la copie de l'objectif 1 ---
step "Entre dans \`dossier/\` (\`cd ~/oslabs/lab07/dossier\`), puis vérifie que la copie \`cible.txt\` existe (créée à l'Objectif 1 à partir de \`evidence.txt\`)."

q_fs "cible.txt existe dans dossier/ (copie créée à l'Objectif 1)" \
  '[ -f "$HOME/oslabs/lab07/dossier/cible.txt" ]' \
  "Cette copie a été créée à l'Objectif 1 (copie de evidence.txt)." \
  "Si elle manque, crée-la : \`cp ../evidence.txt cible.txt\`." \
  "Vérifie avec \`ls -l\`." \
  "mkdir -p ~/oslabs/lab07/dossier && cd ~/oslabs/lab07/dossier && cp ../evidence.txt cible.txt"

# ------------------------------------------------ lire avant modification ---
step "Lis le contenu de \`cible.txt\` avec \`cat cible.txt\`, pour voir le fichier avant de le modifier."

q_choice \
  "Que contient \`cible.txt\` ?" \
  "une copie du rapport d'expertise (evidence.txt)|un script shell|une liste d'identifiants de badges|un fichier vide" \
  1 \
  "Ce fichier a été copié depuis evidence.txt à l'Objectif 1." \
  "\`cat\` affiche le contenu d'un fichier." \
  "Cours slide 7 : les attributs et le contenu d'un fichier."

# ------------------------------------------------ lien physique -------------
step "Crée un lien physique nommé \`lien_dur.txt\` vers \`cible.txt\`."

q_fs "lien_dur.txt et cible.txt désignent le même inode" \
  '[ "$HOME/oslabs/lab07/dossier/lien_dur.txt" -ef "$HOME/oslabs/lab07/dossier/cible.txt" ]' \
  "\`ln\` prend la cible puis le nouveau nom." \
  "Un lien physique se crée sans option." \
  "\`ls -li\` te montrera un inode commun après la commande." \
  "cd ~/oslabs/lab07/dossier && ln cible.txt lien_dur.txt"

# ------------------------------------------------ même inode ----------------
step "Vérifie avec \`ls -li cible.txt lien_dur.txt\` que les deux noms se ressemblent."

q_choice \
  "Que montrent les deux lignes ?" \
  "deux inodes différents et un compteur de liens à 1|le même inode et un compteur de liens à 2|l'inode de lien_dur.txt est vide|deux inodes identiques mais deux contenus différents" \
  2 \
  "La première colonne est le numéro d'inode." \
  "La deuxième colonne est le compteur de liens (slide 70)." \
  "Un lien physique ajoute un nom au même fichier : combien de noms au total ?"

# ------------------------------------------------ modifier via le lien ------
step "Ajoute cette ligne en passant par le lien \`lien_dur.txt\` : \`echo 'indice 2 : badge non trouve' >> lien_dur.txt\`. Puis vérifie qu'elle apparaît aussi dans \`cible.txt\`."

q_fs "cible.txt contient la ligne ajoutée via le lien physique (contenu partagé)" \
  'grep -q "indice 2 : badge non trouve" "$HOME/oslabs/lab07/dossier/cible.txt"' \
  "\`>>\` ajoute à la fin d'un fichier." \
  "Les deux noms désignent le même contenu sur le disque." \
  "cd ~/oslabs/lab07/dossier && echo 'indice 2 : badge non trouve' >> lien_dur.txt"

# ------------------------------------------------ comparer les contenus -----
step "Lis le contenu de \`cible.txt\` (\`cat cible.txt\`) puis celui de \`lien_dur.txt\` (\`cat lien_dur.txt\`), et compare les deux."

q_choice \
  "Que constates-tu sur le contenu des deux fichiers ?" \
  "les deux affichent exactement le même contenu, y compris la ligne « indice 2 : badge non trouve »|cible.txt contient la nouvelle ligne mais pas lien_dur.txt|lien_dur.txt contient la nouvelle ligne mais pas cible.txt|les deux fichiers sont maintenant vides" \
  1 \
  "Les deux noms désignent le même inode, donc le même contenu." \
  "Regarde les dernières lignes affichées par \`cat\`." \
  "Cours slide 70 : un lien physique est un second nom du même fichier."

# ------------------------------------------------ option symbolique --------
step "Consulte \`man ln\` pour l'option qui crée un lien symbolique."

q_fixed \
  "Quelle option de \`ln\` crée un lien symbolique ?" \
  "-s|--symbolic|s|symbolic" \
  "C'est une option courte." \
  "\`ln --help\` liste toutes les options." \
  "Dans \`man ln\`, cherche le mot « symbolic »."

# ------------------------------------------------ lien symbolique ----------
step "Crée un lien symbolique nommé \`lien_sym.txt\` vers \`cible.txt\`."

q_fs "lien_sym.txt est un lien symbolique" \
  '[ -L "$HOME/oslabs/lab07/dossier/lien_sym.txt" ]' \
  "L'option symbolique se place avant la cible." \
  "Le nom du lien vient en dernier argument." \
  "Vérifie le type affiché par \`ls -l\` (type l)." \
  "cd ~/oslabs/lab07/dossier && ln -s cible.txt lien_sym.txt"

# ------------------------------------------------ comparaison ---------------
step "Compare \`ls -li cible.txt lien_dur.txt lien_sym.txt\`."

q_choice \
  "Qu'observes-tu ?" \
  "cible.txt et lien_dur.txt partagent le même inode (compteur 2) ; lien_sym.txt a un inode propre et le type l|les trois partagent le même inode|les trois ont des inodes différents et le même type|lien_sym.txt n'a pas d'inode" \
  1 \
  "Un lien physique ajoute un nom au même inode (slide 70)." \
  "Un lien symbolique est un fichier à part, de type l (slide 71)." \
  "Compare le premier nombre et le premier caractère de chaque ligne."

# ------------------------------------------------ supprimer la copie --------
step "Supprime maintenant le nom \`cible.txt\` (mais garde les deux liens)."

q_fs "cible.txt a disparu, lien_dur.txt est présent, lien_sym.txt est cassé" \
  '[ ! -e "$HOME/oslabs/lab07/dossier/cible.txt" ] && [ -f "$HOME/oslabs/lab07/dossier/lien_dur.txt" ] && [ -L "$HOME/oslabs/lab07/dossier/lien_sym.txt" ] && [ ! -e "$HOME/oslabs/lab07/dossier/lien_sym.txt" ]' \
  "\`rm\` retire un nom du répertoire." \
  "Le lien physique reste un nom du même inode." \
  "Le lien symbolique pointe vers le chemin \`cible.txt\`, désormais absent." \
  "cd ~/oslabs/lab07/dossier && rm cible.txt"

# ------------------------------------------------ lire après suppression ---
step "Lis le contenu de \`lien_dur.txt\` (\`cat lien_dur.txt\`), puis tente de lire \`lien_sym.txt\` (\`cat lien_sym.txt\`)."

q_choice \
  "Que constates-tu après la suppression de cible.txt ?" \
  "lien_dur.txt affiche encore tout le contenu ; lien_sym.txt est cassé (cat échoue, la cible a disparu)|les deux liens affichent le même contenu|les deux liens sont cassés|lien_dur.txt est cassé mais lien_sym.txt affiche le contenu" \
  1 \
  "Le lien physique garde l'inode : les données survivent." \
  "Le lien symbolique ne stocke qu'un chemin, désormais inexistant." \
  "Cours slide 70 (le lien physique survit) + slide 71 (lien cassé)."

# ------------------------------------------------ limites ------------------
step "Relis \`man ln\` à propos des liens sur les répertoires et entre systèmes de fichiers."

q_choice \
  "Quelles limites a le lien physique ?" \
  "aucune limite|il est interdit sur les répertoires et impossible entre systèmes de fichiers|il exige les droits root|il ne fonctionne que sur les fichiers vides" \
  2 \
  "Un inode n'a de sens que dans son propre système de fichiers." \
  "Autoriser des liens de répertoire créerait des cycles." \
  "Cours slide 73 : comparaison lien physique vs lien symbolique."

finalize
