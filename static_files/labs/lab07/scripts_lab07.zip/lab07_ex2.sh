#!/usr/bin/env bash
# =============================================================================
# lab07_ex2.sh — Objectif 2 : copie, lien physique et lien symbolique
# =============================================================================
. "$(dirname "${BASH_SOURCE[0]}")/lab07_lib.sh"

if [ "$PWD" != "$HOME/oslabs/lab07" ]; then
    printf '%s\n' "Ce script doit etre lance depuis ~/oslabs/lab07."
    printf '%s\n' "Tape : cd ~/oslabs/lab07 && bash $(basename "$0")"
    exit 1
fi

BANNER="Rappel : l'annexe du PDF (liens physiques/symboliques) + \`man ln\`, \`man ls\`, \`man test\`. Fichier de mission : evidence.txt. Recherche dans un manuel : \`man commande | grep -e '-option'\` (motif commençant par un tiret)."

begin "report_lab07_ex2.txt" 14 "Objectif 2 — Copie, lien physique et lien symbolique" "TP07" 5 "$BANNER"

title "Objectif 2 — Recopier ou lier : la question de l'analyse"

# ---------------------------------------- garde-fou : répertoire du TP -------
step "Place-toi dans le dossier du TP (\`~/oslabs/lab07\`) et vérifie avec \`pwd\`."

q_fs "tu es bien dans ~/oslabs/lab07" \
  '[ "$PWD" = "$HOME/oslabs/lab07" ]' \
  "Tape \`pwd\` : le chemin affiché doit être celui du dossier du TP." \
  "Le dossier du TP est ~/oslabs/lab07." \
  "Si nécessaire, remonte ou redescends dans l'arborescence avant de continuer." \
  "cd ~/oslabs/lab07 && pwd"

# ------------------------------------------------ man ln --------------------
step "Consulte \`man ln\` (rubrique DESCRIPTION)."

q_choice \
  "Que fait la commande \`ln\`, sans option ?" \
  "elle copie le fichier|elle crée un nouveau nom (lien physique) pour un fichier existant|elle déplace le fichier|elle supprime un lien" \
  2 \
  "Un lien n'est pas une copie." \
  "Les deux noms désignent le même inode." \
  "Dans \`man ln\`, cherche l'expression « hard link »."

# ------------------------------------------------ notes.txt -----------------
step "Dans \`dossier/\`, crée \`notes.txt\` contenant une ligne de notes d'enquête (par exemple \`indice 1 : badge retrouve\`)."

q_fs "dossier/notes.txt existe et n'est pas vide" \
  '[ -s "$HOME/oslabs/lab07/dossier/notes.txt" ]' \
  "\`echo\` suivi de \`>\` écrit une ligne dans un fichier." \
  "La redirection \`>\` crée le fichier s'il n'existe pas." \
  "Tu dois écrire dans ~/oslabs/lab07/dossier/notes.txt." \
  "cd ~/oslabs/lab07/dossier && echo 'indice 1 : badge retrouve' > notes.txt"

# ------------------------------------------------ lien physique -------------
step "Crée un lien physique nommé \`mirror.txt\` vers \`notes.txt\`."

q_fs "dossier/mirror.txt et dossier/notes.txt désignent le même inode" \
  '[ "$HOME/oslabs/lab07/dossier/mirror.txt" -ef "$HOME/oslabs/lab07/dossier/notes.txt" ]' \
  "\`ln\` prend la cible puis le nouveau nom." \
  "Un lien physique se crée sans option." \
  "\`ls -li\` te montrera un inode commun après la commande." \
  "cd ~/oslabs/lab07/dossier && ln notes.txt mirror.txt"

# ------------------------------------------------ même inode ----------------
step "Vérifie avec \`ls -li\` que les deux noms se ressemblent."

q_choice \
  "Que montrent les deux lignes ?" \
  "deux inodes différents et un compteur de liens à 1|le même inode et un compteur de liens à 2|l'inode de mirror.txt est vide|deux inodes identiques mais deux contenus différents" \
  2 \
  "La première colonne est le numéro d'inode." \
  "La deuxième colonne est le compteur de liens." \
  "Un lien physique ajoute un nom au même fichier : combien de noms au total ?"

# ------------------------------------------------ modifier via le lien ------
step "Ajoute une deuxième ligne en passant par \`mirror.txt\`, puis compte les lignes de \`notes.txt\`."

q_number \
  "Combien de lignes contient \`notes.txt\` maintenant ? (un nombre)" \
  "$(wc -l < "$HOME/oslabs/lab07/dossier/notes.txt" 2>/dev/null | tr -d ' ')" \
  "\`>>\` ajoute à la fin d'un fichier." \
  "Les deux noms désignent le même contenu sur le disque." \
  "\`wc -l\` compte les lignes du fichier."

# ------------------------------------------------ supprimer l'original ------
step "Supprime le nom \`notes.txt\`."

q_fs "notes.txt a disparu mais mirror.txt est toujours là" \
  '[ ! -e "$HOME/oslabs/lab07/dossier/notes.txt" ] && [ -f "$HOME/oslabs/lab07/dossier/mirror.txt" ]' \
  "\`rm\` retire un nom du répertoire." \
  "Le second nom doit rester." \
  "Vérifie ensuite avec \`ls -l dossier/\`." \
  "cd ~/oslabs/lab07/dossier && rm notes.txt"

# ------------------------------------------------ le fichier survit --------
step "Après cette suppression, affiche le contenu de \`mirror.txt\`."

q_choice \
  "Le fichier a-t-il réellement disparu du disque ?" \
  "oui, tout a été effacé|non : l'inode et les données survivent sous mirror.txt|non, mais le contenu est devenu vide|oui, car le compteur de liens était à 2" \
  2 \
  "Regarde le compteur de liens affiché par \`ls -l\`." \
  "Le fichier n'est réellement libéré qu'au dernier nom retiré." \
  "Cours « Le lien physique » : suppression quand le compteur tombe à zéro."

# ------------------------------------------------ option symbolique --------
step "Consulte \`man ln\` pour l'option qui crée un lien symbolique."

q_fixed \
  "Quelle option de \`ln\` crée un lien symbolique ?" \
  "-s|--symbolic|s|symbolic" \
  "C'est une option courte." \
  "\`ln --help\` liste toutes les options." \
  "Dans \`man ln\`, cherche le mot « symbolic »."

# ------------------------------------------------ lien symbolique ----------
step "Crée un lien symbolique \`pivot.txt\` vers \`evidence.txt\` (le fichier de mission est dans le dossier parent)."

q_fs "dossier/pivot.txt est un lien symbolique" \
  '[ -L "$HOME/oslabs/lab07/dossier/pivot.txt" ]' \
  "La cible peut être un chemin relatif : \`../evidence.txt\`." \
  "L'option symbolique se place avant la cible." \
  "Vérifie le type affiché par \`ls -l\`." \
  "cd ~/oslabs/lab07/dossier && ln -s ../evidence.txt pivot.txt"

# ------------------------------------------------ inode distinct -----------
step "Compare les inodes de \`pivot.txt\` et \`../evidence.txt\` avec \`ls -li\`."

q_choice \
  "Qu'observes-tu ?" \
  "même inode|inodes différents et type « l » pour pivot.txt|pivot.txt n'a pas d'inode|inodes différents mais contenus identiques" \
  2 \
  "Un lien symbolique est un fichier à part entière." \
  "Il contient un chemin, pas les données de la cible." \
  "Cours « Le lien symbolique »."

# ------------------------------------------------ lien cassé ---------------
step "Crée \`secret.txt\` (une ligne), un lien symbolique \`clue.txt\` vers \`secret.txt\`, puis supprime \`secret.txt\`."

q_fs "dossier/clue.txt est un lien symbolique dont la cible n'existe plus" \
  '[ -L "$HOME/oslabs/lab07/dossier/clue.txt" ] && [ ! -e "$HOME/oslabs/lab07/dossier/clue.txt" ]' \
  "Supprime la cible, pas le lien." \
  "\`test -L\` vérifie qu'un nom est un lien symbolique ; \`test -e\` vérifie qu'une cible existe." \
  "Après \`rm secret.txt\`, \`clue.txt\` reste mais pointe dans le vide." \
  "cd ~/oslabs/lab07/dossier && echo 'secret' > secret.txt && ln -s secret.txt clue.txt && rm secret.txt"

# ------------------------------------------------ lien cassé : concept -----
step "Essaie d'afficher \`clue.txt\`."

q_choice \
  "Qu'est devenu ce lien symbolique ?" \
  "il a disparu avec sa cible|il est cassé (dangling) et pointe vers un chemin inexistant|il a recréé la cible|il est devenu un lien physique" \
  2 \
  "Regarde \`ls -l clue.txt\` : la cible est affichée mais absente." \
  "Le lien contient un chemin, rien de plus." \
  "Cours « Le lien symbolique » : notion de lien cassé."

# ------------------------------------------------ limites ------------------
step "Relis \`man ln\` à propos des liens sur les répertoires et entre systèmes de fichiers."

q_choice \
  "Quelles limites a le lien physique ?" \
  "aucune limite|il est interdit sur les répertoires et impossible entre systèmes de fichiers|il exige les droits root|il ne fonctionne que sur les fichiers vides" \
  2 \
  "Un inode n'a de sens que dans son propre système de fichiers." \
  "Autoriser des liens de répertoire créerait des cycles." \
  "Cours « Comparaison : lien physique vs lien symbolique »."

finalize
