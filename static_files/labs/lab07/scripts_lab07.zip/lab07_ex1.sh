#!/usr/bin/env bash
# =============================================================================
# lab07_ex1.sh — Objectif 1 : métadonnées et accès direct
# =============================================================================
. "$(dirname "${BASH_SOURCE[0]}")/lab07_lib.sh"

if [ "$PWD" != "$HOME/oslabs/lab07" ]; then
    printf '%s\n' "Ce script doit etre lance depuis ~/oslabs/lab07."
    printf '%s\n' "Tape : cd ~/oslabs/lab07 && bash $(basename "$0")"
    exit 1
fi

BANNER="Rappel : l'annexe du PDF (concept de fichier, inode, accès direct) + \`man ls\`, \`man cp\`, \`man dd\`, \`help printf\`. Slides du cours : 7-8 (métadonnées, horodatages), 37 et 63 (nom vs inode), 18, 27, 34-35 (dd et accès direct). Fichier de mission : evidence.txt. Recherche dans un manuel : \`man commande | grep -e '-option'\` (motif commençant par un tiret)."

begin "report_lab07_ex1.txt" 16 "Objectif 1 — Métadonnées et accès direct" "TP07" 5 "$BANNER"

title "Objectif 1 — Dissecter un fichier de preuve"

# ---------------------------------------- garde-fou : répertoire du TP -------
step "Place-toi dans le dossier du TP (\`~/oslabs/lab07\`) et vérifie avec \`pwd\`."

q_fs "tu es bien dans ~/oslabs/lab07" \
  '[ "$PWD" = "$HOME/oslabs/lab07" ]' \
  "Tape \`pwd\` : le chemin affiché doit être celui du dossier du TP." \
  "Le dossier du TP est ~/oslabs/lab07." \
  "Si nécessaire, remonte ou redescends dans l'arborescence avant de continuer." \
  "cd ~/oslabs/lab07 && pwd"

# ------------------------------------------------ observer ls -l ------------
step "Consulte \`man ls\` (rubrique DESCRIPTION) pour retrouver ce que détaille l'option \`-l\`."

q_choice \
  "Qu'affiche \`ls -l\` pour chaque entrée ?" \
  "uniquement les noms, un par ligne|le détail : type, permissions, liens, propriétaire, taille et date|seulement les fichiers cachés|seulement les numéros d'inode" \
  2 \
  "La sortie est organisée en colonnes." \
  "La première colonne commence par un caractère de type (-, d, l...)." \
  "Dans \`man ls\`, cherche la description de l'option longue « long format »."

# ------------------------------------------------ dossier de travail --------
step "Crée le répertoire \`dossier\` dans le dossier du TP."

q_fs "le répertoire ~/oslabs/lab07/dossier existe" \
  '[ -d "$HOME/oslabs/lab07/dossier" ]' \
  "Une seule commande crée un répertoire." \
  "\`man mkdir\` : le nom du répertoire est un argument." \
  "Tu dois le créer dans ~/oslabs/lab07 (vérifie avec \`pwd\`)." \
  "cd ~/oslabs/lab07 && mkdir dossier"

# ------------------------------------------------ copie explicite -----------
step "Copie \`evidence.txt\` dans \`dossier/\` sous le nom explicite \`cible.txt\`."

q_fs "dossier/cible.txt existe et son contenu est identique à evidence.txt" \
  '[ -f "$HOME/oslabs/lab07/dossier/cible.txt" ] && cmp -s "$HOME/oslabs/lab07/evidence.txt" "$HOME/oslabs/lab07/dossier/cible.txt"' \
  "\`cp source cible\` prend deux arguments." \
  "La cible doit être un nom de fichier complet dans \`dossier/\`." \
  "\`man cp\` décrit la forme \`cp fichier dossier/nouveau_nom\`." \
  "cd ~/oslabs/lab07 && cp evidence.txt dossier/cible.txt"

# ------------------------------------------------ destination répertoire ----
step "Copie encore \`evidence.txt\` dans le répertoire \`dossier/\` en ne donnant que le répertoire comme destination (slash final, sans nouveau nom)."

q_choice \
  "Après cette commande, quel fichier apparaît dans \`dossier/\` ?" \
  "dossier/evidence.txt (le nom d'origine est conservé)|dossier/cible.txt (le dernier nom utilisé)|erreur : une destination répertoire est interdite|aucun fichier : la commande échoue" \
  1 \
  "Quand la destination est un répertoire, le fichier garde son nom de base." \
  "Le slash final indique que la cible est un répertoire." \
  "Regarde \`ls dossier/\` après la commande : quel nom est apparu ?"

# ------------------------------------------------ numéro d'inode ------------
step "Sur une sortie \`ls -li\` (par exemple \`ls -li evidence.txt dossier/cible.txt\`), repère le premier nombre de chaque ligne : il précède les permissions. C'est le numéro d'inode."

q_choice \
  "Que représente ce premier nombre ?" \
  "la taille du fichier en octets|le numéro d'inode du fichier|le nombre de blocs occupés|le compteur de liens" \
  2 \
  "Il reste identique quand tu renommes le fichier." \
  "\`man ls\` décrit l'option \`-i\` (inode)." \
  "Cours slides 37 et 63 : le répertoire associe un nom à un numéro d'inode."

# ------------------------------------------------ inode après cp ------------
step "Maintenant que tu sais lire le numéro d'inode, compare celui de \`evidence.txt\` et celui de \`dossier/cible.txt\` sur la sortie \`ls -li\`."

q_choice \
  "Qu'observes-tu ?" \
  "les deux noms partagent le même inode|le second fichier n'a pas d'inode|les deux fichiers ont des inodes différents|les inodes changent à chaque affichage" \
  3 \
  "\`ls -li\` affiche le numéro d'inode en première colonne." \
  "\`cp\` produit un fichier indépendant." \
  "Les deux nombres en tête de ligne sont-ils identiques ?"

# ------------------------------------------------ horodatages ---------------
step "Ajoute cette ligne à la fin de \`dossier/cible.txt\` : \`echo 'note 2 : analyse des liens a poursuivre' >> dossier/cible.txt\`"

q_fs "dossier/cible.txt contient bien la ligne ajoutée" \
  'grep -q "note 2 : analyse des liens a poursuivre" "$HOME/oslabs/lab07/dossier/cible.txt"' \
  "Utilise l'opérateur \`>>\` pour ajouter sans écraser." \
  "Vérifie ensuite avec \`wc -l dossier/cible.txt\` ou \`tail dossier/cible.txt\`." \
  "cd ~/oslabs/lab07 && echo 'note 2 : analyse des liens a poursuivre' >> dossier/cible.txt"

step "Compare \`ls -l dossier/cible.txt\` (affiche mtime) et \`ls -lc dossier/cible.txt\` (affiche ctime)."

q_choice \
  "Le contenu vient d'être modifié : quels horodatages ont changé ?" \
  "seulement atime|mtime et ctime|seulement ctime|aucun des trois" \
  2 \
  "mtime date la dernière modification du contenu." \
  "ctime date le dernier changement de métadonnées ; la taille change aussi." \
  "Cours slide 8 : modifier le contenu touche mtime et ctime."

# ------------------------------------------------ nom vs inode --------------
step "Observe la sortie de \`ls -li\` : le numéro d'inode est en début de ligne, le nom en fin de ligne."

q_choice \
  "Où le nom du fichier est-il réellement stocké ?" \
  "dans l'inode|dans le répertoire (entrée nom → inode)|dans le superbloc|dans les blocs de données" \
  2 \
  "Renommer un fichier ne change pas son inode." \
  "Le répertoire n'est qu'une table de correspondances." \
  "Cours slides 37 et 63 : nom et métadonnées sont séparés."

# ------------------------------------------------ créer test.txt ------------
step "Crée \`dossier/test.txt\` : cinq identifiants de badges d'accès, un par ligne, de largeur fixe 7 caractères — \`BDG-017\`, \`BDG-028\`, \`BDG-031\`, \`BDG-044\`, \`BDG-057\` — avec une seule commande \`printf\` (comme dans l'exemple du cours)."

q_fs "dossier/test.txt contient bien les cinq enregistrements (4e ligne = BDG-044)" \
  '[ -f "$HOME/oslabs/lab07/dossier/test.txt" ] && [ "$(head -n 4 "$HOME/oslabs/lab07/dossier/test.txt" | tail -n 1 | tr -d "\r")" = "BDG-044" ]' \
  "\`help printf\` : le format s'applique à chaque argument." \
  "Un format comme \`%s\\n\` écrit chaque argument sur sa propre ligne." \
  "Le dernier argument du printf peut être redirigé vers \`dossier/test.txt\`." \
  "cd ~/oslabs/lab07/dossier && printf '%s\n' BDG-017 BDG-028 BDG-031 BDG-044 BDG-057 > test.txt"

# ------------------------------------------------ taille en octets ----------
step "Prévois la taille en octets de \`dossier/test.txt\` (compte à la main), puis vérifie avec \`wc -c\`."

q_number \
  "Combien d'octets contient le fichier ? (un nombre)" \
  "$(wc -c < "$HOME/oslabs/lab07/dossier/test.txt" 2>/dev/null | tr -d ' ')" \
  "Chaque identifiant fait 7 caractères." \
  "Chaque ligne se termine par un retour à la ligne : +1 octet." \
  "Cinq lignes de 8 octets : effectue la multiplication."

# ------------------------------------------------ man dd --------------------
step "Consulte \`man dd\` (rubrique OPERANDS : \`bs\`, \`skip\`, \`count\`, \`seek\`). Syntaxe : slide 34 ; exemple : slide 35."

q_choice \
  "En quoi \`dd\` diffère-t-il de \`cp\` ?" \
  "il copie le fichier entier comme cp|il copie et convertit des données par blocs de taille choisie|il affiche le contenu sans rien écrire|il renomme les fichiers" \
  2 \
  "L'opérande \`bs=\` fixe la taille d'un bloc." \
  "\`skip=\` et \`count=\` choisissent des blocs précis." \
  "C'est l'outil de l'exemple du cours sur l'accès direct."

# ------------------------------------------------ lire un bloc --------------
step "Lis uniquement le 4e enregistrement (indice de bloc 3), sans parcourir les précédents. (notion d'accès direct : voir slide 35 du cours)"

q_fixed \
  "Quel identifiant s'affiche ?" \
  "BDG-044|bdg-044" \
  "Le premier bloc a l'indice 0." \
  "Une ligne complète fait 7 caractères + le retour à la ligne, soit 8 octets : la taille de bloc doit couvrir la ligne entière." \
  "Dans \`man dd\`, \`skip\` saute des blocs d'entrée ; \`count\` en lit un. Voir slide 35."

# ------------------------------------------------ lecture dans le désordre --
step "Avec \`dd\`, lis l'enregistrement d'indice 4 (\`bs=8 skip=4 count=1\`), puis d'indice 1 (\`skip=1\`), puis d'indice 2 (\`skip=2\`) — dans cet ordre. \`skip\` saute directement au bloc voulu et \`count=1\` n'en lit qu'un seul : tu ne relis donc jamais le fichier en entier."

q_choice \
  "Quelle méthode d'accès viens-tu d'illustrer ?" \
  "l'accès séquentiel|l'accès direct (positionnement sur un bloc précis)|l'accès indexé par clé|un accès par permissions" \
  2 \
  "Tu sautes directement au bloc voulu, sans lire les précédents." \
  "C'est exactement ce que fait \`lseek\` avec \`SEEK_SET\` au niveau des appels système." \
  "Cours slide 35 : dd en lecture (skip/count) = accès direct."

# ------------------------------------------------ écrire dans un bloc -------
step "Remplace l'enregistrement d'indice 2 par la valeur de contrôle \`XXXXXXX\` (7 X) en écrivant au bon endroit, et sans tronquer la suite du fichier. (voir slide 35 : dd en écriture, seek et conv=notrunc)"

q_fs "dossier/test.txt a XXXXXXX en 3e ligne et n'a pas été tronqué (5 lignes)" \
  '[ "$(head -n 3 "$HOME/oslabs/lab07/dossier/test.txt" | tail -n 1 | tr -d "\r")" = "XXXXXXX" ] && [ "$(wc -l < "$HOME/oslabs/lab07/dossier/test.txt" | tr -d " ")" = "5" ]' \
  "En écriture, \`dd\` positionne la sortie avec \`seek=\` (slide 35)." \
  "Sans protection, \`dd\` tronque le fichier à la position d'écriture : cherche dans \`man dd\` l'opérande qui l'en empêche." \
  "Le pipe \`printf ... | dd of=...\` permet d'envoyer la valeur ; il reste à choisir \`seek\` et l'opérande anti-troncature." \
  "cd ~/oslabs/lab07/dossier && printf 'XXXXXXX\n' | dd of=test.txt bs=8 seek=2 conv=notrunc"

finalize
