#!/usr/bin/env bash
# =============================================================================
# lab05_ex1.sh — Objectif 1 : grep — filtrer un journal
# =============================================================================
. "$(dirname "${BASH_SOURCE[0]}")/lab05_lib.sh"

BANNER="Rappel : l'annexe du PDF (regex + grep) + \`man grep\`, \`grep --help\`, \`man -k mot-clé\`. Fichier de travail : server.log."

begin "report_lab05_ex1.txt" 13 "Objectif 1 — grep : filtrer un journal" "TP05" 5 "$BANNER"

title "Objectif 1 — Filtrer le bruit avec grep"

# ------------------------------------------------------ découverte de grep ----
step "Consulte \`man grep\` (rubrique DESCRIPTION) pour comprendre le rôle de grep."

q_choice \
  "Que fait la commande \`grep\` ?" \
  "elle transforme du texte ligne par ligne|elle trie les lignes d'un fichier|elle imprime les lignes qui correspondent à un motif|elle compte les mots d'un fichier" \
  3 \
  "\`grep\` ne modifie pas les lignes : il en sélectionne certaines." \
  "Elle cherche un motif dans un fichier et n'affiche que les lignes qui le contiennent." \
  "Relis la DESCRIPTION de \`man grep\` : elle dit « print lines that match patterns »."

step "Depuis \`~/oslabs/lab05\`, tape \`grep ERROR server.log\` et observe les lignes affichées."

q_choice \
  "Qu'affiche \`grep ERROR server.log\` ?" \
  "uniquement les lignes qui contiennent la chaîne ERROR|tout le fichier|le nombre total de lignes|les lignes qui NE contiennent PAS ERROR" \
  1 \
  "Observe bien : toutes les lignes affichées partagent un mot en commun." \
  "\`grep\` filtre : seules les lignes contenant le motif sont imprimées." \
  "Compare avec \`cat server.log\` : grep en a retenu beaucoup moins."

step "Compte combien de lignes contiennent exactement la chaîne \`ERROR\` (en majuscules)."

q_number \
  "Combien de lignes contiennent la chaîne \`ERROR\` en majuscules ? (un nombre)" \
  "$(grep -c 'ERROR' "$HOME/oslabs/lab05/server.log" 2>/dev/null)" \
  "\`grep\` peut compter au lieu d'afficher, si tu lui passes la bonne option." \
  "L'option en question porte le nom anglais de « compter »." \
  "Dans \`man grep\`, la rubrique OPTIONS liste une option qui affiche un décompte au lieu des lignes."

step "Tape \`grep -c error server.log\` (minuscules) puis \`grep -c ERROR server.log\` (majuscules), et compare les deux nombres."

q_choice \
  "Pourquoi les deux commandes donnent-elles des résultats différents ?" \
  "parce que ERROR est un mot réservé|parce que le fichier change entre les deux commandes|parce que -c compte différemment|parce que grep distingue majuscules et minuscules (sensible à la casse)" \
  4 \
  "Regarde bien : les lignes du service \`db\` écrivent leur niveau en minuscules." \
  "\`grep\` traite \`error\` et \`ERROR\` comme deux motifs distincts." \
  "Le nombre de lignes \`error\` (minuscules) est plus petit que celui de \`ERROR\` (majuscules)."

step "Le service \`db\` écrit \`[error]\` en minuscules, les autres \`[ERROR]\` en majuscules. Trouve l'option qui permet de tout attraper d'un coup."

q_fixed \
  "Quelle option de grep rend la recherche insensible à la casse ?" \
  "-i|--ignore-case|i|ignore-case" \
  "Cette option traite \`ERROR\` et \`error\` comme équivalents." \
  "Tape \`grep --help\` et cherche le mot « ignore »." \
  "Dans \`man grep\`, cherche l'option dont la description contient « ignore case »."

step "Tape \`grep -ci error server.log\` pour compter toutes les lignes d'erreur, quelle que soit la casse."

q_number \
  "Combien de lignes contiennent \`error\` quelle que soit la casse ? (un nombre)" \
  "$(grep -ci 'error' "$HOME/oslabs/lab05/server.log" 2>/dev/null)" \
  "\`-i\` attrape à la fois les \`[ERROR]\` et les \`[error]\`." \
  "Ce nombre est la somme des lignes \`ERROR\` et \`error\`." \
  "Il est strictement supérieur au nombre de lignes \`ERROR\` trouvé plus tôt."

step "Liste les lignes qui ne concernent PAS les messages d'information (niveau \`INFO\`)."

q_fixed \
  "Quelle option de grep inverse la sélection (affiche ce qui NE correspond PAS) ?" \
  "-v|--invert-match|v|invert-match" \
  "Cette option affiche les lignes qui ne contiennent pas le motif." \
  "Tape \`grep --help\` et cherche le mot « invert »." \
  "Dans \`man grep\`, cherche l'option « invert match »."

step "Compte les lignes qui ne sont pas des \`INFO\` avec \`grep -v INFO server.log | wc -l\`."

q_number \
  "Combien de lignes ne contiennent PAS la chaîne \`INFO\` ? (un nombre)" \
  "$(grep -v 'INFO' "$HOME/oslabs/lab05/server.log" 2>/dev/null | wc -l | tr -d ' ')" \
  "\`grep -v\` garde tout sauf les lignes \`INFO\`." \
  "\`wc -l\` compte le nombre de lignes reçues." \
  "Ce nombre est le total de lignes du journal moins le nombre de lignes \`INFO\`."

step "Tape \`grep -E 'ERROR|FATAL' server.log\` : le \`|\` permet de chercher deux motifs à la fois."

q_choice \
  "Que faut-il pour utiliser l'alternance \`|\` avec grep ?" \
  "l'option -c|l'option -E (expressions régulières étendues)|l'option -v|aucune option, le | marche toujours en BRE" \
  2 \
  "En expressions régulières de base (BRE), le \`|\` n'est pas spécial sans échappement." \
  "\`-E\` active les expressions régulières étendues (ERE)." \
  "Dans \`man grep\`, cherche l'option qui active le mode « extended ». Compare \`grep 'ERROR\|FATAL'\` (BRE) et \`grep -E 'ERROR|FATAL'\` (ERE)."

step "Extrais toutes les adresses IP du journal avec \`grep -oE '[0-9]{1,3}(\\.[0-9]{1,3}){3}' server.log\`, puis compte les IP distinctes avec \`sort -u\`."

q_number \
  "Combien d'adresses IP distinctes apparaissent dans le journal ? (un nombre)" \
  "$(grep -oE '[0-9]{1,3}(\.[0-9]{1,3}){3}' "$HOME/oslabs/lab05/server.log" 2>/dev/null | sort -u | wc -l | tr -d ' ')" \
  "\`-o\` n'affiche que la partie qui correspond (pas la ligne entière)." \
  "La regex \`[0-9]{1,3}\` puis \`(\\.[0-9]{1,3}){3}\` décrit une IPv4." \
  "\`sort -u\` supprime les doublons ; \`wc -l\` compte ce qui reste."

step "Compare \`grep 'error' server.log\` et \`grep 'error\\+' server.log\`."

q_choice \
  "En expressions régulières de base (BRE), comment écrire un quantificateur comme \`+\` ?" \
  "tel quel : +|avec l'option -E uniquement|il n'existe pas en BRE|en l'échappant : \\+" \
  4 \
  "En BRE, les symboles \`+\`, \`(\`, \`)\`, \`{\`, \`}\`, \`|\` perdent leur sens spécial." \
  "Pour retrouver leur sens, il faut les faire précéder d'un antislash." \
  "Relis le tableau BRE/ERE de l'annexe : quels métacaractères demandent un \\ en BRE ?"

step "Tape \`grep -w error server.log\` puis compare avec \`grep error server.log\`."

q_choice \
  "À quoi sert l'option \`-w\` ?" \
  "compter les lignes|ignorer la casse|chercher un mot entier, isolé du reste|afficher les numéros de ligne" \
  3 \
  "Sans \`-w\`, grep trouve le motif même à l'intérieur d'un mot plus long." \
  "\`-w\` exige que le motif soit délimité par des espaces ou des ponctuations." \
  "Dans \`man grep\`, cherche l'option « word-regexp »."

step "Enregistre la liste des erreurs dans un fichier : depuis \`~/oslabs/lab05\`, tape \`grep -i error server.log > erreurs.log\`."

q_fs "le fichier erreurs.log existe et n'est pas vide" \
  '[ -s "$HOME/oslabs/lab05/erreurs.log" ]' \
  "Utilise \`grep -i error\` pour attraper les erreurs quelle que soit la casse." \
  "Le tableau « Redirections » de l'annexe rappelle comment écrire dans un fichier avec \`>\`." \
  "Vérifie avec \`ls -l erreurs.log\` qu'il a été créé." \
  "cd ~/oslabs/lab05 && grep -i error server.log > erreurs.log"

finalize
