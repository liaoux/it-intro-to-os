#!/usr/bin/env bash
# =============================================================================
# lab05_ex2.sh — Objectif 2 : sed — transformer un journal
# =============================================================================
. "$(dirname "${BASH_SOURCE[0]}")/lab05_lib.sh"

BANNER="Rappel : l'annexe du PDF (sed) + \`man sed\`, \`sed --help\`, \`man -k mot-clé\`. Fichier de travail : server.log."

begin "report_lab05_ex2.txt" 13 "Objectif 2 — sed : transformer un journal" "TP05" 5 "$BANNER"

title "Objectif 2 — Transformer le journal avec sed"

# ----------------------------------------------------- découverte de sed ----
step "Consulte \`man sed\` (rubrique DESCRIPTION) pour comprendre le rôle de sed."

q_choice \
  "Que fait la commande \`sed\` ?" \
  "elle édite un flux de texte ligne par ligne (non interactif)|elle filtre des lignes selon un motif|elle trie un fichier|elle compte les lignes" \
  1 \
  "Son nom vient de « stream editor »." \
  "\`sed\` lit une ligne, lui applique une commande, affiche le résultat, puis passe à la suivante." \
  "Relis la DESCRIPTION de \`man sed\` : elle dit « stream editor for filtering and transforming text »."

step "Tape \`echo 'Hello World' | sed 's/World/INF2132/'\`."

q_choice \
  "Que fait cette commande ?" \
  "elle affiche Hello World|elle supprime la ligne|elle compte les mots|elle remplace World par INF2132" \
  4 \
  "La commande \`s/motif/remplacement/\` est une substitution." \
  "Le texte entre les deux premiers \`/\` est remplacé par le texte entre les deux suivants." \
  "Observe la sortie : quel mot a disparu, remplacé par INF2132 ?"

step "Tape \`sed 's/error/ERREUR/' server.log\` et regarde les lignes du service \`db\` (elles contiennent deux \`error\`)."

q_choice \
  "Sans drapeau, combien d'occurrences par ligne la substitution remplace-t-elle ?" \
  "toutes les occurrences|uniquement la première occurrence de chaque ligne|aucune|les deux premières" \
  2 \
  "Sur la ligne \`[error] db: Query failed: error 1045...\`, regarde combien de \`error\` ont changé." \
  "Seul le premier \`error\` rencontré (celui de \`[error]\`) devient \`ERREUR\`." \
  "Le second \`error\` de la même ligne reste intact sans le drapeau approprié."

step "Trouve le drapeau de substitution qui remplace TOUTES les occurrences d'une ligne."

q_fixed \
  "Quel drapeau ajoute-t-on après \`s/motif/remplacement/\` pour une substitution globale ?" \
  "g|global|/g|g/" \
  "Ce drapeau signifie « global »." \
  "Il se place après le troisième \`/\` : \`s/motif/remplacement/<drapeau>\`." \
  "Consulte \`man sed\`, la partie sur la commande \`s\` et ses flags."

step "Normalise la casse des erreurs : remplace TOUTES les occurrences de \`error\` (minuscules) par \`ERROR\` dans une copie \`server_norm.log\`."

q_fs "le fichier server_norm.log existe et ne contient plus de [error] en minuscules" \
  '[ -s "$HOME/oslabs/lab05/server_norm.log" ] && ! grep -q "\[error\]" "$HOME/oslabs/lab05/server_norm.log"' \
  "Utilise \`sed 's/error/ERROR/g'\` avec le drapeau global." \
  "Écris le résultat dans \`server_norm.log\` avec \`>\`." \
  "Vérifie avec \`grep error server_norm.log\` qu'il ne reste plus de minuscules." \
  "cd ~/oslabs/lab05 && sed 's/error/ERROR/g' server.log > server_norm.log"

step "Tape \`sed -n '5,10p' server.log\`."

q_number \
  "Combien de lignes affiche \`sed -n '5,10p'\` ? (un nombre)" \
  "6" \
  "\`5,10\` est une plage d'adresses : de la ligne 5 à la ligne 10." \
  "La commande \`p\` imprime la ligne ; \`-n\` empêche l'affichage automatique des autres." \
  "Compte les lignes de 5 à 10 incluses."

step "Tape \`sed '/DEBUG/d' server.log\` et observe."

q_choice \
  "Que fait la commande \`/DEBUG/d\` ?" \
  "elle imprime les lignes DEBUG|elle compte les DEBUG|elle supprime les lignes contenant DEBUG|elle transforme DEBUG en INFO" \
  3 \
  "\`/DEBUG/\` est une adresse par motif (regex)." \
  "La commande \`d\` signifie « delete »." \
  "Compare avec \`grep DEBUG server.log\` : sed fait l'inverse en supprimant."

step "Crée \`server_no_debug.log\`, une copie du journal SANS les lignes de débogage (\`DEBUG\`)."

q_fs "le fichier server_no_debug.log existe et ne contient aucune ligne DEBUG" \
  '[ -s "$HOME/oslabs/lab05/server_no_debug.log" ] && ! grep -q "DEBUG" "$HOME/oslabs/lab05/server_no_debug.log"' \
  "Utilise \`sed '/DEBUG/d'\` pour supprimer les lignes concernées." \
  "Écris le résultat dans \`server_no_debug.log\` avec \`>\`." \
  "Vérifie avec \`grep -c DEBUG server_no_debug.log\` (doit valoir 0)." \
  "cd ~/oslabs/lab05 && sed '/DEBUG/d' server.log > server_no_debug.log"

step "Consulte \`man sed\` à propos de l'option \`-i\`."

q_choice \
  "À quoi sert l'option \`-i\` de sed ?" \
  "modifier le fichier directement (en place), sans redirection|compter les lignes|imprimer en couleur|inverser l'ordre des lignes" \
  1 \
  "Sans \`-i\`, sed écrit sur la sortie standard et le fichier d'origine reste intact." \
  "Avec \`-i\`, le fichier est modifié sur le disque (attention, pas de retour arrière)." \
  "Relis la rubrique OPTIONS de \`man sed\` : que dit-elle de l'option \`-i\` ?"

step "Tape \`sed -n '/ERROR/p' server.log\`."

q_choice \
  "Que fait \`sed -n '/ERROR/p'\` ?" \
  "supprime les lignes ERROR|compte les ERROR|transforme ERROR|n'imprime QUE les lignes contenant ERROR" \
  4 \
  "\`/ERROR/\` sélectionne les lignes correspondant au motif." \
  "\`p\` imprime ; \`-n\` empêche l'affichage des autres lignes." \
  "Le résultat ressemble à celui d'une commande de filtrage que tu as vue à l'Objectif 1."

step "Tape \`echo '2026-10-17 09:15:32' | sed 's/^[0-9-]* \\([0-9][0-9]\\):.*/\\1/'\`."

q_choice \
  "Que capture et réaffiche le \`\\1\` dans cette substitution ?" \
  "la date complète|le premier groupe capturé, c'est-à-dire l'heure 09|toute la ligne|les minutes et secondes" \
  2 \
  "\\( ... \\) délimite un groupe de capture ; \\1 le rappelle dans le remplacement." \
  "Le motif \`^[0-9-]* \` mange la date, puis \\([0-9][0-9]\\) capture les deux chiffres de l'heure." \
  "Remplace tout le reste par \\1 : il ne reste que ce qui a été capturé."

step "Extrais l'heure de chaque ligne du journal et écris le résultat dans \`heures.log\` (une heure par ligne)."

q_fs "le fichier heures.log existe et sa première ligne est 09" \
  '[ "$(head -n 1 "$HOME/oslabs/lab05/heures.log")" = "09" ]' \
  "Réutilise la substitution de l'étape précédente sur tout le fichier." \
  "Le motif capture les deux chiffres de l'heure après la date." \
  "Écris le résultat dans \`heures.log\` avec \`>\`." \
  "cd ~/oslabs/lab05 && sed 's/^[0-9-]* \\([0-9][0-9]\\):.*/\\1/' server.log > heures.log"

step "Récapitulons la complémentarité des deux outils."

q_choice \
  "Quelle phrase résume le mieux la différence entre grep et sed ?" \
  "grep transforme, sed filtre|ils font exactement la même chose|grep filtre des lignes, sed transforme du texte|grep est plus rapide que sed" \
  3 \
  "grep sélectionne des lignes entières selon un motif, sans les modifier." \
  "sed réécrit le contenu (substitution, suppression, insertion) ligne par ligne." \
  "Relis la slide « Choisir le bon outil : grep vs sed » du cours."

finalize
