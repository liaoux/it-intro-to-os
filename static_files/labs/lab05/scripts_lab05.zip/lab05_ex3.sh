#!/usr/bin/env bash
# =============================================================================
# lab05_ex3.sh — Objectif 3 : composer des pipelines
# =============================================================================
. "$(dirname "${BASH_SOURCE[0]}")/lab05_lib.sh"

BANNER="Rappel : l'annexe du PDF (pipes) + \`man sort\`, \`man uniq\`, \`man tee\`, \`man -k mot-clé\`. Fichier de travail : server.log."

begin "report_lab05_ex3.txt" 14 "Objectif 3 — composer des pipelines" "TP05" 5 "$BANNER"

title "Objectif 3 — Du bruit au rapport : le pipeline"

# ----------------------------------------------------- le pipe, brique 1 ----
step "Reviens sur le \`|\` : tape \`ls -l | head -n 5\`."

q_choice \
  "Que fait le symbole \`|\` entre deux commandes ?" \
  "il les exécute en parallèle|il affiche un message d'erreur|il relie la sortie de la première à l'entrée de la seconde|il supprime le résultat" \
  3 \
  "La sortie de \`ls -l\` n'est pas affichée à l'écran : elle est envoyée à \`head\`." \
  "Chaque commande lit l'entrée standard et écrit sur la sortie standard." \
  "Relis la slide « Pipes » du chapitre 2 : le pipe chaîne des commandes."

# ------------------------------------------------------- maillons simples ----
step "Consulte \`man sort\` (DESCRIPTION) pour comprendre son rôle."

q_choice \
  "Que fait \`sort\` ?" \
  "il trie les lignes de l'entrée|il filtre des lignes|il supprime les doublons|il compte les lignes" \
  1 \
  "Il réordonne les lignes reçues selon un critère (alphabétique par défaut)." \
  "On l'utilise souvent juste avant un traitement qui exige des données ordonnées." \
  "Relis la DESCRIPTION de \`man sort\` : « sort lines of text files »."

step "Consulte \`man uniq\` (DESCRIPTION) pour comprendre son rôle."

q_choice \
  "Que fait \`uniq\` ?" \
  "il trie les lignes|il transforme les lignes|il numérote les lignes|il supprime les lignes répétées adjacentes (et peut les compter)" \
  4 \
  "Il ne détecte que les répétitions consécutives : d'où la nécessité de trier avant." \
  "Avec \`-c\`, il préfixe chaque ligne par son nombre d'occurrences." \
  "Relis la DESCRIPTION de \`man uniq\` : « report or omit repeated lines »."

step "Consulte \`man tee\` (DESCRIPTION) pour comprendre son rôle."

q_choice \
  "Que fait \`tee\` ?" \
  "il trie le flux|il écrit le flux dans un fichier TOUT EN le laissant passer|il supprime le flux|il compte les lignes" \
  2 \
  "Son nom vient du raccord en « T » : le flux continue ET est copié dans un fichier." \
  "Idéal pour inspecter un maillon intermédiaire sans casser le pipeline." \
  "Relis la DESCRIPTION de \`man tee\` : « read from standard input and write to standard output and files »."

# ------------------------------------------------- construction incrémentale ----
step "Premier maillon : compte les lignes d'erreur. Tape \`grep -i error server.log | wc -l\`."

q_number \
  "Combien de lignes d'erreur ce premier maillon affiche-t-il ? (un nombre)" \
  "$(grep -i 'error' "$HOME/oslabs/lab05/server.log" 2>/dev/null | wc -l | tr -d ' ')" \
  "\`grep -i error\` sélectionne les erreurs ; \`wc -l\` compte les lignes reçues." \
  "C'est le même nombre que le comptage \`grep -ci error\` de l'Objectif 1." \
  "Le pipe transmet la sortie de grep à l'entrée de wc."

step "Deuxième maillon : réduis chaque ligne d'erreur à son heure. Tape \`grep -i error server.log | sed 's/^[0-9-]* \\([0-9][0-9]\\):.*/\\1/'\`."

q_choice \
  "Que produit ce pipeline à deux maillons ?" \
  "les lignes d'erreur complètes|le nombre total d'erreurs|une heure par ligne d'erreur|les adresses IP" \
  3 \
  "\`sed\` capture l'heure (\\([0-9][0-9]\\)) et réaffiche \\1." \
  "Chaque ligne de sortie est un simple nombre à deux chiffres." \
  "Compare avec \`heures.log\` de l'Objectif 2 : ce sont les mêmes heures, mais seulement pour les erreurs."

step "Troisième maillon : trie. Tape \`grep -i error server.log | sed 's/^[0-9-]* \\([0-9][0-9]\\):.*/\\1/' | sort\`."

q_choice \
  "Pourquoi faut-il \`sort\` juste avant \`uniq\` ?" \
  "parce que uniq ne supprime que les répétitions adjacentes|pour accélérer|pour colorer la sortie|ce n'est pas nécessaire" \
  1 \
  "Sans tri, les mêmes heures dispersées ne seraient pas adjacentes." \
  "\`uniq\` compare chaque ligne à la précédente uniquement." \
  "Regroupe d'abord les heures identiques côte à côte grâce au tri."

step "Quatrième maillon : compte les occurrences. Tape \`grep -i error server.log | sed 's/^[0-9-]* \\([0-9][0-9]\\):.*/\\1/' | sort | uniq -c\`."

q_number \
  "Combien de lignes (heures distinctes) affiche \`uniq -c\` ? (un nombre)" \
  "$(grep -i 'error' "$HOME/oslabs/lab05/server.log" 2>/dev/null | sed 's/^[0-9-]* \([0-9][0-9]\):.*/\1/' | sort -u | wc -l | tr -d ' ')" \
  "Chaque ligne de sortie correspond à une heure différente rencontrée." \
  "\`uniq -c\` regroupe les heures identiques en une ligne avec un compteur." \
  "C'est le nombre d'heures distinctes où il y a eu au moins une erreur."

step "Cinquième maillon : classe du plus fréquent au moins fréquent. Termine par \`| sort -rn\`."

q_choice \
  "Que font les options \`-r\` et \`-n\` de \`sort\` ?" \
  "supprimer les doublons|compter les lignes|ignorer la casse|trier en ordre inverse et numérique" \
  4 \
  "\`-n\` compare les valeurs comme des nombres (pas comme du texte)." \
  "\`-r\` inverse l'ordre : du plus grand au plus petit." \
  "Sans \`-n\`, \`10\` serait trié avant \`2\` (ordre lexicographique)."

# ------------------------------------------------------ rapport final ----
step "Assemble le pipeline complet et écris le résultat dans \`rapport_erreurs.txt\` : grep des erreurs → heure → tri → comptage → classement."

q_fs "le fichier rapport_erreurs.txt existe et sa première ligne correspond à l'heure 11" \
  '[ "$(head -n 1 "$HOME/oslabs/lab05/rapport_erreurs.txt" | sed "s/^ *[0-9]* //")" = "11" ]' \
  "Le pipeline est : \`grep -i error\` puis \`sed\` (heure) puis \`sort\` puis \`uniq -c\` puis \`sort -rn\`." \
  "Termine par \`> rapport_erreurs.txt\` pour écrire le résultat." \
  "La première ligne doit être l'heure qui a le plus d'erreurs (regarde ton \`uniq -c\`)." \
  "cd ~/oslabs/lab05 && grep -i error server.log | sed 's/^[0-9-]* \\([0-9][0-9]\\):.*/\\1/' | sort | uniq -c | sort -rn > rapport_erreurs.txt"

step "Lis \`rapport_erreurs.txt\` et repère l'heure en tête de classement."

q_number \
  "Quelle est l'heure qui a le plus d'erreurs ? (deux chiffres)" \
  "$(grep -i 'error' "$HOME/oslabs/lab05/server.log" 2>/dev/null | sed 's/^[0-9-]* \([0-9][0-9]\):.*/\1/' | sort | uniq -c | sort -rn | head -n 1 | sed 's/^ *[0-9]* //')" \
  "C'est la première ligne de \`rapport_erreurs.txt\` (compteur le plus élevé)." \
  "Lis le classement de haut en bas : la première heure domine." \
  "Le compteur de cette heure est le plus grand de tout le fichier."

step "Débogue le pipeline en y insérant \`tee\` : \`grep -i error server.log | tee etape1.log | sed 's/^[0-9-]* \\([0-9][0-9]\\):.*/\\1/'\`."

q_fs "le fichier etape1.log existe et n'est pas vide" \
  '[ -s "$HOME/oslabs/lab05/etape1.log" ]' \
  "Place \`tee etape1.log\` juste après le maillon à inspecter (ici grep)." \
  "\`tee\` copie le flux dans le fichier sans l'arrêter." \
  "Vérifie avec \`head etape1.log\` que le fichier contient bien les lignes d'erreur." \
  "cd ~/oslabs/lab05 && grep -i error server.log | tee etape1.log | sed 's/^[0-9-]* \\([0-9][0-9]\\):.*/\\1/'"

step "Récapitulons la méthode de conception d'un pipeline."

q_choice \
  "Quelle est la bonne méthode pour construire un pipeline de traitement de texte ?" \
  "tout écrire d'un coup sans tester|filtrer (grep) puis transformer (sed) puis agréger (sort/uniq), en testant chaque maillon|toujours utiliser un seul outil|commencer par l'agrégation" \
  2 \
  "On construit le pipeline maillon par maillon, en vérifiant chaque sortie intermédiaire." \
  "L'ordre logique : réduire les données (filtre), les reformater (transforme), puis les résumer (agrège)." \
  "Relis la slide « La méthode : filtrer → transformer → agréger » du cours."

step "Relis ton \`rapport_erreurs.txt\` : il répond à la question de la mission — à quelle heure le serveur a-t-il le plus souffert ?"

q_choice \
  "Que conclus-tu de ton rapport sur l'incident ?" \
  "les erreurs sont réparties uniformément, pas de pic|le pic est à 09 h|le serveur a connu son pic d'erreurs à 11 h, c'est là que l'incident a culminé|impossible de conclure avec ces données" \
  3 \
  "La première ligne de rapport_erreurs.txt est l'heure au plus grand compteur." \
  "Compare le premier compteur avec les suivants : une heure domine nettement." \
  "Le rapport est trié du plus fréquent au moins fréquent : la toute première ligne donne la réponse."

finalize
