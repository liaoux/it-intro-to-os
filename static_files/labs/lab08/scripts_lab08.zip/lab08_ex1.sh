#!/usr/bin/env bash
# =============================================================================
# lab08_ex1.sh — Objectif 1 : Comptes et groupes
# =============================================================================
. "$(dirname "${BASH_SOURCE[0]}")/lab08_lib.sh"

BANNER="Rappel : l'annexe du PDF (aide-mémoire) + man groupadd, man useradd, man usermod, man passwd, man chage. Comptes du TP : usr_ali, usr_sara ; groupe partagé : proj_web."

begin "report_lab08_ex1.txt" 15 "Objectif 1 — Comptes et groupes" "TP08" 5 "$BANNER"

title "Objectif 1 — Créer les comptes et observer /etc/passwd, /etc/group, /etc/shadow"

# --- helpers ---------------------------------------------------------------
group_ok()  { getent group "$1" >/dev/null 2>&1; }
user_ok()   { id "$1" >/dev/null 2>&1 && getent group "$1" >/dev/null 2>&1; }
in_group()  { case " $(id -Gn "$1" 2>/dev/null) " in *" $2 "*) return 0 ;; *) return 1 ;; esac; }

# ------------------------------------------------------------- garde -------
step "Place-toi dans le dossier du TP et vérifie avec \`pwd\`."

q_fs "tu es bien dans ~/oslabs/lab08" \
  '[ "$PWD" = "$HOME/oslabs/lab08" ]' \
  "Tape \`pwd\` : le chemin affiché doit être celui du dossier du TP." \
  "Le dossier du TP est ~/oslabs/lab08." \
  "Si nécessaire, utilise \`cd\` avec un chemin absolu avant de continuer." \
  "cd ~/oslabs/lab08 && pwd"

# -------------------------------------------------------- groupadd ---------
step "Consulte \`man groupadd\` (ou l'annexe du TP)."

q_choice \
  "À quoi sert \`groupadd\` ?" \
  "supprimer un groupe|ajouter un utilisateur à un groupe|créer un groupe|afficher les groupes d'un utilisateur" \
  3 \
  "La commande agit sur la base des groupes." \
  "Son nom contient « add »." \
  "\`groupdel\` fait l'action inverse."

step "Crée le groupe partagé : \`sudo groupadd proj_web\`."

q_fs "le groupe proj_web existe" \
  'group_ok proj_web' \
  "\`sudo groupadd nom\` crée un groupe." \
  "Vérifie avec \`getent group proj_web\`." \
  "S'il existe déjà, passe à la suite." \
  "sudo groupadd proj_web"

step "Vérifie la création : tape \`getent group proj_web\`."

q_choice \
  "Que montre la fiche de \`proj_web\` ?" \
  "nom:GID:permissions|nom:mot_de_passe:GID:liste_des_membres|login:UID:GID:home|hash:expiration" \
  2 \
  "La fiche d'un groupe a 4 champs séparés par \`:\`." \
  "Les membres peuvent être vides tant que personne n'a été ajouté." \
  "\`getent group\` lit la base des groupes."

# -------------------------------------------------------- useradd ----------
step "Consulte \`man useradd\` (ou l'annexe du TP)."

q_choice \
  "Que fait \`sudo useradd -m -U -s /bin/bash -c \"Ali\" usr_ali\` ?" \
  "crée le compte usr_ali avec son répertoire personnel, un groupe du même nom en principal, le shell bash et un commentaire|crée uniquement un groupe nommé usr_ali|supprime le compte usr_ali|change le mot de passe de usr_ali" \
  1 \
  "Chaque option joue un rôle précis." \
  "\`-m\` crée le répertoire personnel, \`-s\` fixe le shell." \
  "\`-U\` crée un groupe du même nom et le met en groupe principal."

step "Crée les deux comptes : \`sudo useradd -m -U -s /bin/bash -c \"Ali\" usr_ali\` puis \`sudo useradd -m -U -s /bin/bash -c \"Sara\" usr_sara\`."

q_fs "les comptes usr_ali et usr_sara (et leurs groupes) existent" \
  'user_ok usr_ali && user_ok usr_sara' \
  "\`useradd -m -U login\` crée le compte et un groupe du même nom." \
  "Vérifie avec \`id usr_ali\` et \`id usr_sara\`." \
  "Si « user already exists », le compte est déjà créé : continue." \
  'sudo useradd -m -U -s /bin/bash -c "Ali" usr_ali && sudo useradd -m -U -s /bin/bash -c "Sara" usr_sara'

# -------------------------------------------------------- usermod ----------
step "Consulte \`man usermod\` (ou l'annexe du TP)."

q_choice \
  "Que fait \`usermod -aG proj_web usr_ali\` ?" \
  "crée le groupe proj_web|supprime usr_ali de proj_web|remplace tous les groupes de usr_ali par proj_web|ajoute usr_ali à proj_web sans retirer ses autres groupes" \
  4 \
  "\`-G\` fixe la liste des groupes supplémentaires." \
  "\`-a\` signifie « append » (ajouter)." \
  "Sans \`-a\`, les groupes supplémentaires seraient remplacés."

step "Ajoute usr_ali au groupe partagé : \`sudo usermod -aG proj_web usr_ali\`."

q_fs "usr_ali est membre de proj_web" \
  'in_group usr_ali proj_web' \
  "\`usermod -aG proj_web usr_ali\` ajoute le groupe supplémentaire." \
  "Vérifie avec \`id -Gn usr_ali\` : tu dois voir proj_web." \
  "Le groupe principal reste usr_ali." \
  "sudo usermod -aG proj_web usr_ali"

step "Ajoute usr_sara au groupe partagé : \`sudo usermod -aG proj_web usr_sara\`."

q_fs "usr_sara est membre de proj_web" \
  'in_group usr_sara proj_web' \
  "Même commande que pour usr_ali." \
  "Vérifie avec \`id -Gn usr_sara\`." \
  "Le groupe principal reste usr_sara." \
  "sudo usermod -aG proj_web usr_sara"

# ------------------------------------------------- inspection fichiers ------
step "Affiche les comptes créés : \`grep '^usr_' /etc/passwd\`."

q_choice \
  "Que contient une ligne de \`/etc/passwd\` ?" \
  "login:home:shell|login:mot_de_passe:UID:GID:commentaire:home:shell|nom:GID:membres|login:hash:expiration" \
  2 \
  "Il y a 7 champs séparés par \`:\`." \
  "Le troisième champ est l'UID, le quatrième le GID." \
  "Le dernier champ est le shell de connexion."

step "Affiche les groupes créés : \`grep '^proj_' /etc/group\`."

q_choice \
  "Que contient une ligne de \`/etc/group\` ?" \
  "login:UID:GID:home|nom:GID:permissions|groupe:hash:expiration|nom:mot_de_passe:GID:liste_des_membres" \
  4 \
  "Il y a 4 champs séparés par \`:\`." \
  "Le troisième champ est le GID." \
  "Le dernier champ liste les membres supplémentaires."

# ------------------------------------------------------------ id -----------
step "Tape \`id usr_ali\` : repère son UID."

q_number \
  "Quel UID le système a-t-il attribué à \`usr_ali\` ?" \
  "$(id -u usr_ali 2>/dev/null)" \
  "\`id usr_ali\` affiche \`uid=...\`." \
  "\`id -u usr_ali\` n'affiche que le nombre." \
  "La valeur dépend de ta machine : lis-la, ne la devine pas."

step "Tape \`id -gn usr_ali\` : c'est le groupe principal du compte."

q_fixed \
  "Quel est le groupe principal de \`usr_ali\` ?" \
  "usr_ali" \
  "\`id -gn usr_ali\` affiche le nom du groupe principal." \
  "Grâce à \`useradd -U\`, il porte le même nom que le compte." \
  "C'est le groupe usr_ali, pas proj_web."

step "Tape \`groups usr_ali\` (ou \`id -Gn usr_ali\`)."

q_choice \
  "Que liste la commande \`groups\` ?" \
  "le groupe principal et les groupes supplémentaires|uniquement le groupe principal|les fichiers du groupe|les permissions du groupe" \
  1 \
  "La sortie peut contenir plusieurs noms." \
  "Le groupe principal vient de \`/etc/passwd\`, les autres de \`/etc/group\`." \
  "\`groups usr_ali\` doit montrer usr_ali ET proj_web."

# ---------------------------------------------------- passwd / chage --------
step "Consulte \`man passwd\` et \`man chage\`, puis découvre où le mot de passe haché d'un compte est réellement conservé."

q_choice \
  "Où est stocké le hash du mot de passe, et à quoi sert \`chage\` ?" \
  "dans /etc/group ; chage crée des groupes|dans le home ; chage supprime le compte|dans /etc/shadow ; chage gère l'expiration du mot de passe|dans /etc/passwd ; chage change le shell" \
  3 \
  "\`/etc/passwd\` est lisible par tous : le mot de passe ne peut pas y être en clair." \
  "Le champ mot de passe de \`/etc/passwd\` vaut souvent \`x\` : c'est un renvoi." \
  "\`chage -l\` affiche la politique d'expiration du mot de passe."

synthese \
  "1. Pourquoi un compte est-il identifié par un UID plutôt que par son nom ?" \
  "2. Quels champs de /etc/passwd relient un compte à son groupe principal ?" \
  "3. Où est stocké le hash du mot de passe, et pourquoi pas dans /etc/passwd ?" \
  "4. Que change exactement usermod -aG proj_web usr_ali ?"

finalize
