#!/usr/bin/env bash
# =============================================================================
# lab08_ex3.sh — Objectif 3 : Répertoire partagé entre deux utilisateurs
# =============================================================================
. "$(dirname "${BASH_SOURCE[0]}")/lab08_lib.sh"

BANNER="Rappel : l'annexe du PDF (bits spéciaux, sudo) + man chmod, man ls, man sudo. Comptes : usr_ali, usr_sara ; groupe : proj_web."

begin "report_lab08_ex3.txt" 17 "Objectif 3 — Répertoire partagé" "TP08" 5 "$BANNER"

title "Objectif 3 — Partager /srv/partage entre usr_ali et usr_sara (SGID, sticky, SUID)"

# --- helpers ---------------------------------------------------------------
P="/srv/partage"
mode_est() { [ "$(ls -ld "$1" 2>/dev/null | cut -c1-10)" = "$2" ]; }
user_is()  { [ -n "$(find "$1" -user "$2"  2>/dev/null)" ]; }
group_is() { [ -n "$(find "$1" -group "$2" 2>/dev/null)" ]; }
in_group() { case " $(id -Gn "$1" 2>/dev/null) " in *" $2 "*) return 0 ;; *) return 1 ;; esac; }

# ---------------------------------------------------------- préparation -----
step "Vérifie que les comptes et le groupe de l'objectif 1 sont prêts."

q_fs "usr_ali et usr_sara existent et sont membres de proj_web" \
  'id usr_ali >/dev/null 2>&1 && id usr_sara >/dev/null 2>&1 && getent group proj_web >/dev/null 2>&1 && in_group usr_ali proj_web && in_group usr_sara proj_web' \
  "Ces comptes sont créés à l'objectif 1." \
  "Vérifie avec \`id -Gn usr_ali\` et \`id -Gn usr_sara\`." \
  "Si un compte manque, reprends \`lab08_ex1.sh\`." \
  "id usr_ali && id usr_sara && getent group proj_web"

# ------------------------------------------------------------ bits ---------
step "Consulte \`man chmod\` (cherche setuid, setgid, sticky) et l'annexe du TP, tableau « Bits spéciaux et élévation »."

q_choice \
  "Quel est l'ordre octal des bits SUID, SGID, sticky ?" \
  "1, 2, 4|4, 2, 1|4, 1, 2|2, 4, 1" \
  2 \
  "Le quatrième chiffre, en tête du mode, est réservé à ces trois bits." \
  "SUID est le plus grand, sticky le plus petit." \
  "Dans \`ls -l\`, \`s\` (propriétaire/groupe) et \`t\` (autres) les matérialisent."

step "Crée le répertoire partagé : \`sudo mkdir -p /srv/partage\`, \`sudo chgrp proj_web /srv/partage\`, \`sudo chmod 775 /srv/partage\`."

q_fs "/srv/partage existe en drwxrwxr-x, root:proj_web" \
  'mode_est "$P" "drwxrwxr-x" && group_is "$P" proj_web && user_is "$P" root' \
  "Le répertoire doit appartenir au groupe proj_web." \
  "775 donne rwx au propriétaire et au groupe, r-x aux autres." \
  "Vérifie avec \`ls -ld /srv/partage\`." \
  "sudo mkdir -p /srv/partage && sudo chgrp proj_web /srv/partage && sudo chmod 775 /srv/partage"

# -------------------------------------------------------- avant SGID -------
step "Crée un fichier en tant que usr_ali : \`sudo -u usr_ali bash -c 'umask 002; cd /srv/partage; touch fichierA'\`, puis \`ls -l /srv/partage/fichierA\`."

q_fs "fichierA appartient au groupe usr_ali (mode 664)" \
  'group_is "$P/fichierA" usr_ali && mode_est "$P/fichierA" "-rw-rw-r--"' \
  "\`umask 002\` rend les fichiers créés écrivibles par le groupe." \
  "Avant le SGID, le groupe d'un fichier est le groupe principal de son créateur." \
  "Vérifie avec \`ls -l /srv/partage/fichierA\`." \
  "sudo -u usr_ali bash -c 'umask 002; cd /srv/partage; touch fichierA'"

step "Tente d'écrire dans ce fichier en tant que usr_sara : \`sudo -u usr_sara bash -c 'cd /srv/partage; echo test >> fichierA'\`."

q_choice \
  "Pourquoi l'écriture échoue-t-elle ?" \
  "fichierA appartient au groupe usr_ali, dont usr_sara n'est pas membre|le dossier n'est pas accessible|le sticky bit interdit l'écriture|le SGID interdit l'écriture" \
  1 \
  "\`ls -l fichierA\` montre le groupe usr_ali." \
  "\`id usr_sara\` ne contient pas usr_ali." \
  "Le bit d'écriture du groupe vaut pour usr_ali, pas pour proj_web."

# ------------------------------------------------------------ SGID ---------
step "Active le SGID : \`sudo chmod 2775 /srv/partage\`."

q_fs "/srv/partage est en drwxrwsr-x" \
  'mode_est "$P" "drwxrwsr-x"' \
  "\`chmod 2775\` ajoute le SGID (2) au mode 775." \
  "Le \`s\` remplace le \`x\` du groupe." \
  "Vérifie avec \`ls -ld /srv/partage\`." \
  "sudo chmod 2775 /srv/partage"

step "Observe \`ls -ld /srv/partage\` : que change le SGID pour les nouveaux fichiers ?"

q_choice \
  "Quel est l'effet du SGID sur un répertoire ?" \
  "exécution avec l'UID du propriétaire|suppression restreinte|les nouveaux fichiers héritent du groupe du répertoire|lecture seule" \
  3 \
  "Le SGID sur un dossier force l'héritage du groupe." \
  "Le \`s\` apparaît sur le groupe dans \`ls -ld\`." \
  "Compare le groupe de fichierA (usr_ali) avec celui du prochain fichier."

step "Crée un fichier en tant que usr_ali : \`sudo -u usr_ali bash -c 'umask 002; cd /srv/partage; touch fichierB'\`, puis \`ls -l /srv/partage/fichierB\`."

q_fs "fichierB hérite du groupe proj_web (mode 664)" \
  'group_is "$P/fichierB" proj_web && mode_est "$P/fichierB" "-rw-rw-r--"' \
  "Avec le SGID, le groupe du dossier est transmis aux nouveaux fichiers." \
  "Vérifie avec \`ls -l /srv/partage/fichierB\` : usr_ali proj_web." \
  "Le groupe n'est plus usr_ali mais proj_web." \
  "sudo -u usr_ali bash -c 'umask 002; cd /srv/partage; touch fichierB'"

step "Écris dans ce fichier en tant que usr_sara : \`sudo -u usr_sara bash -c 'cd /srv/partage; echo \"test sara\" >> fichierB'\`, puis \`ls -l /srv/partage/fichierB\`."

q_fs "fichierB contient « test sara »" \
  'grep -q "test sara" "$P/fichierB"' \
  "usr_sara est membre de proj_web, groupe de fichierB." \
  "Le mode 664 donne l'écriture au groupe." \
  "Vérifie avec \`cat /srv/partage/fichierB\`." \
  "sudo -u usr_sara bash -c 'cd /srv/partage; echo \"test sara\" >> fichierB'"

# ------------------------------------------------------------ sticky -------
step "Ajoute le sticky bit en gardant le SGID : \`sudo chmod 3775 /srv/partage\`."

q_fs "/srv/partage est en drwxrwsr-t" \
  'mode_est "$P" "drwxrwsr-t"' \
  "\`chmod 3775\` ajoute le sticky (1) et le SGID (2)." \
  "Le \`t\` remplace le \`x\` des autres." \
  "Vérifie avec \`ls -ld /srv/partage\`." \
  "sudo chmod 3775 /srv/partage"

step "Crée un fichier en tant que usr_ali : \`sudo -u usr_ali bash -c 'umask 002; cd /srv/partage; touch protege.txt'\`."

q_fs "protege.txt appartient au groupe proj_web (mode 664)" \
  'group_is "$P/protege.txt" proj_web && mode_est "$P/protege.txt" "-rw-rw-r--"' \
  "\`umask 002\` rend le fichier écrivible par le groupe." \
  "\`ls -l protege.txt\` doit montrer usr_ali proj_web, mode -rw-rw-r--." \
  "Le SGID fait hériter le groupe proj_web." \
  "sudo -u usr_ali bash -c 'umask 002; cd /srv/partage; touch protege.txt'"

step "En tant que usr_sara : tente \`sudo -u usr_sara bash -c 'cd /srv/partage; rm protege.txt'\` (échec), puis crée et supprime ton propre fichier : \`sudo -u usr_sara bash -c 'cd /srv/partage; touch fichier_sara.txt; rm fichier_sara.txt'\`."

q_choice \
  "Pourquoi \`usr_sara\` ne peut-elle pas supprimer \`protege.txt\` (fichier de usr_ali), alors qu'elle supprime \`fichier_sara.txt\` (son fichier) ?" \
  "le SGID interdit la suppression|le fichier est en lecture seule|usr_sara n'est plus dans proj_web|le sticky bit réserve la suppression au propriétaire du fichier (ou root)" \
  4 \
  "\`rm protege.txt\` échoue, mais pas celui de \`fichier_sara.txt\`." \
  "La suppression dépend de qui possède le fichier, pas des droits d'écriture." \
  "Le sticky bit protège les fichiers des autres dans un répertoire partagé."

step "Vérifie l'état après ces tests."

q_fs "protege.txt existe encore ; fichier_sara.txt a été supprimé" \
  '[ -f "$P/protege.txt" ] && [ ! -e "$P/fichier_sara.txt" ]' \
  "\`rm protege.txt\` doit échouer : le fichier reste." \
  "\`touch fichier_sara.txt ; rm fichier_sara.txt\` doit avoir supprimé le fichier de usr_sara." \
  "protege.txt (fichier de usr_ali) ne doit pas avoir été supprimé." \
  "ls -l /srv/partage/protege.txt && ls -l /srv/partage/fichier_sara.txt"

# ------------------------------------------------------------- SUID --------
step "Observe un vrai binaire SUID : \`ls -l \"\$(command -v passwd)\"\`."

q_choice \
  "Pourquoi la commande \`passwd\` porte-t-elle le bit SUID ?" \
  "pour écrire /etc/shadow avec les droits de root|pour aller plus vite|pour changer le shell de l'utilisateur|pour supprimer des comptes" \
  1 \
  "\`passwd\` modifie le mot de passe, stocké dans un fichier réservé à root." \
  "Le \`s\` du propriétaire indique que le binaire s'exécute avec l'UID de son propriétaire (root)." \
  "Relis l'annexe « Bits spéciaux et élévation »."

# --------------------------------------------------------- audit find ------
step "Audite les bits posés sur le répertoire : \`find /srv/partage -type d -perm -2000 -ls\` puis \`find /srv/partage -type d -perm -1000 -ls\`."

q_fs "les deux find retrouvent /srv/partage (SGID et sticky posés)" \
  '[ -n "$(find "$P" -type d -perm -2000 2>/dev/null)" ] && [ -n "$(find "$P" -type d -perm -1000 2>/dev/null)" ]' \
  "\`-perm -2000\` recherche le SGID, \`-perm -1000\` le sticky bit." \
  "Tu dois voir \`/srv/partage\` dans chacune des deux sorties." \
  "Le tiret devant le mode signifie « tous ces bits sont posés »." \
  "find /srv/partage -type d -perm -2000 -ls && find /srv/partage -type d -perm -1000 -ls"

step "Cherche les binaires SUID du système : \`find /usr/bin -type f -perm -4000 -ls 2>/dev/null | head\`."

q_choice \
  "Que recherche \`find -perm -4000\` ?" \
  "les fichiers SUID|les fichiers SGID|les fichiers avec sticky bit|les fichiers exécutables" \
  1 \
  "\`4000\` correspond au bit SUID (le \`s\` du propriétaire)." \
  "Tu devrais voir \`passwd\` et \`sudo\` dans la sortie." \
  "Compare avec \`-2000\` (SGID) et \`-1000\` (sticky) vus à l'étape précédente."

# ------------------------------------------------------------ nettoyage ----
step "Nettoie : \`sudo rm -rf /srv/partage\`."

q_fs "/srv/partage a été supprimé" \
  '[ ! -e "$P" ]' \
  "\`sudo rm -rf /srv/partage\` supprime le répertoire partagé." \
  "Vérifie avec \`ls -ld /srv/partage\` : il doit ne plus exister." \
  "Ce TP ne crée pas de binaire SUID de démonstration : seul le vrai \`passwd\` est resté en lecture." \
  "sudo rm -rf /srv/partage"

synthese \
  "1. Pourquoi usr_sara ne peut-elle pas écrire fichierA avant le SGID ?" \
  "2. Que change le SGID pour les nouveaux fichiers de /srv/partage ?" \
  "3. Pourquoi le sticky bit interdit-il de supprimer protege.txt (fichier d'un autre), mais pas de supprimer son propre fichier ?" \
  "4. Pourquoi la commande passwd porte-t-elle le bit SUID, et pourquoi est-ce sensible ?"

finalize
