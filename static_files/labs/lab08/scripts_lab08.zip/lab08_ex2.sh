#!/usr/bin/env bash
# =============================================================================
# lab08_ex2.sh — Objectif 2 : Permissions, chmod, chown, chgrp, umask
# =============================================================================
. "$(dirname "${BASH_SOURCE[0]}")/lab08_lib.sh"

BANNER="Rappel : l'annexe du PDF (aide-mémoire) + man chmod, help umask, man chown, man chgrp. Comptes : usr_ali, usr_sara ; groupe : proj_web."

begin "report_lab08_ex2.txt" 18 "Objectif 2 — Permissions et umask" "TP08" 5 "$BANNER"

title "Objectif 2 — Appliquer les modes, le umask et la propriété"

# --- helpers ---------------------------------------------------------------
L="$HOME/oslabs/lab08"
mode_est() { [ "$(ls -ld "$1" 2>/dev/null | cut -c1-10)" = "$2" ]; }
owner_is() { [ -n "$(find "$1" -user "$2" 2>/dev/null)" ]; }
group_is() { [ -n "$(find "$1" -group "$2" 2>/dev/null)" ]; }

# ------------------------------------------------------------- garde -------
step "Place-toi dans le dossier du TP et vérifie avec \`pwd\`."

q_fs "tu es bien dans ~/oslabs/lab08" \
  '[ "$PWD" = "$HOME/oslabs/lab08" ]' \
  "Tape \`pwd\` : le chemin affiché doit être celui du dossier du TP." \
  "Le dossier du TP est ~/oslabs/lab08." \
  "Utilise \`cd\` avec un chemin absolu si nécessaire." \
  "cd ~/oslabs/lab08 && pwd"

# ---------------------------------------------------------- chmod ----------
step "Consulte \`man chmod\` (ou l'annexe du TP) et retrouve la valeur octale des droits."

q_choice \
  "Que vaut le droit de lecture (r) en octal ?" \
  "1 (exécution)|4 (lecture)|2 (écriture)|0 (aucun)" \
  2 \
  "r=4, w=2, x=1." \
  "Le droit d'écriture vaut 2, l'exécution 1." \
  "Relis la section du manuel qui donne le mode octal."

step "Crée les deux premières entrées : \`touch rapport.txt\` puis \`mkdir atelier\`."

q_fs "rapport.txt et atelier/ existent" \
  '[ -f "$L/rapport.txt" ] && [ -d "$L/atelier" ]' \
  "\`touch\` crée un fichier, \`mkdir\` un dossier." \
  "Les deux commandes se font dans ~/oslabs/lab08." \
  "Vérifie avec \`ls -ld\`." \
  "touch rapport.txt && mkdir atelier"

step "Convertir le mode \`-rw-r-----\` en octal."

q_number \
  "Quel est le mode octal de \`-rw-r-----\` ?" \
  "640" \
  "Découpe en trois blocs : propriétaire, groupe, autres." \
  "Propriétaire rw = 6 ; groupe r = 4 ; autres = 0." \
  "r=4, w=2, x=1."

step "Applique ce mode puis vérifie : \`chmod 640 rapport.txt\` puis \`ls -ld rapport.txt\`."

q_fs "rapport.txt a le mode -rw-r-----" \
  'mode_est "$L/rapport.txt" "-rw-r-----"' \
  "\`chmod 640 rapport.txt\`." \
  "\`ls -ld rapport.txt\` doit montrer -rw-r----- en première colonne." \
  "Le 0 final retire tous les droits aux autres." \
  "chmod 640 rapport.txt && ls -ld rapport.txt"

step "Convertir le mode \`-rwxr-x---\` en octal."

q_number \
  "Quel est le mode octal de \`-rwxr-x---\` ?" \
  "750" \
  "Propriétaire rwx = 7." \
  "Groupe r-x = 5 ; autres = 0." \
  "r=4, w=2, x=1."

step "Applique ce mode au dossier puis vérifie : \`chmod 750 atelier\` puis \`ls -ld atelier\`."

q_fs "atelier/ a le mode drwxr-x--- (750)" \
  'mode_est "$L/atelier" "drwxr-x---"' \
  "\`chmod 750 atelier\`." \
  "\`ls -ld atelier\` doit montrer drwxr-x---." \
  "Le \`x\` du groupe permet de traverser le dossier." \
  "chmod 750 atelier && ls -ld atelier"

step "Applique un mode symbolique puis vérifie : \`chmod u=rw,g=,o= rapport.txt\` puis \`ls -ld rapport.txt\`."

q_fs "rapport.txt a le mode -rw------- (600)" \
  'mode_est "$L/rapport.txt" "-rw-------"' \
  "\`u=\` concerne le propriétaire, \`g=\` le groupe, \`o=\` les autres." \
  "\`g=\` et \`o=\` vides retirent tous les droits." \
  "Vérifie avec \`ls -ld rapport.txt\`." \
  "chmod u=rw,g=,o= rapport.txt && ls -ld rapport.txt"

# ---------------------------------------------------------- umask ----------
step "Consulte \`man umask\` (ou \`help umask\`)."

q_choice \
  "À quoi sert \`umask 027\` ?" \
  "force les permissions à 027|ajoute 027 aux permissions|retire les bits 027 des permissions par défaut|change le propriétaire" \
  3 \
  "Le umask masque certains bits lors de la création." \
  "Il ne fixe pas une valeur : il enlève des droits." \
  "Les droits retirés s'appliquent aux permissions par défaut (fichier 666, dossier 777)."

step "Tape \`umask 027\`, puis crée \`touch fichier_umask.txt\` et \`mkdir dossier_umask\`."

q_fs "fichier_umask.txt et dossier_umask/ existent" \
  '[ -f "$L/fichier_umask.txt" ] && [ -d "$L/dossier_umask" ]' \
  "Crée les deux entrées APRÈS avoir tapé \`umask 027\`." \
  "\`touch\` crée le fichier, \`mkdir\` le dossier." \
  "Vérifie avec \`ls -ld fichier_umask.txt dossier_umask\`." \
  "umask 027 && touch fichier_umask.txt && mkdir dossier_umask"

step "Calcule le nouveau mode octal du fichier créé sous \`umask 027\` (aide : \`ls -ld fichier_umask.txt\`)."

q_number \
  "Quel mode octal obtient \`fichier_umask.txt\` ?" \
  "640" \
  "Un fichier naît en 666 ; \`umask 027\` retire 027." \
  "666 - 027 = 640." \
  "Vérifie la 1re colonne de \`ls -ld fichier_umask.txt\`."

step "Calcule le mode octal du dossier créé sous \`umask 027\` (aide : \`ls -ld dossier_umask\`)."

q_number \
  "Quel mode octal obtient \`dossier_umask\` ?" \
  "750" \
  "Un dossier naît en 777 ; \`umask 027\` retire 027." \
  "777 - 027 = 750." \
  "Vérifie la 1re colonne de \`ls -ld dossier_umask\`."

step "Restaure \`umask 022\`."

q_choice \
  "Pourquoi restaurer \`umask 022\` ?" \
  "pour que les prochains fichiers ne restent pas en 027|pour supprimer les fichiers créés|pour changer le shell|pour créer un groupe" \
  1 \
  "\`umask 027\` ne vaut que pour les sessions où tu l'as posé." \
  "Remettre 022 revient au comportement par défaut habituel." \
  "Tape simplement \`umask 022\`."

# ------------------------------------------------- chown / chgrp ------------
step "Consulte \`man chown\` et \`man chgrp\`."

q_choice \
  "Quelle est la différence entre \`chown\` et \`chgrp\` ?" \
  "chown change le groupe, chgrp le propriétaire|les deux font la même chose|chown ne fonctionne que sur les dossiers|chown change le propriétaire (et éventuellement le groupe), chgrp seulement le groupe" \
  4 \
  "\`chown\` peut recevoir \`user:group\`." \
  "Changer de propriétaire exige les droits root (sudo)." \
  "\`chgrp\` ne touche qu'au groupe."

step "Définis propriétaire ET groupe de \`rapport.txt\`, puis vérifie : \`sudo chown usr_ali:proj_web rapport.txt\` puis \`ls -ld rapport.txt\`."

q_fs "rapport.txt appartient à usr_ali:proj_web" \
  'owner_is "$L/rapport.txt" usr_ali && group_is "$L/rapport.txt" proj_web' \
  "\`chown user:groupe\` règle les deux d'un coup." \
  "\`ls -ld\` montre le propriétaire (3e colonne) et le groupe (4e colonne)." \
  "Attendu : usr_ali proj_web." \
  "sudo chown usr_ali:proj_web rapport.txt && ls -ld rapport.txt"

step "Définis propriétaire ET groupe de \`atelier\`, puis vérifie : \`sudo chown usr_sara:proj_web atelier\` puis \`ls -ld atelier\`."

q_fs "atelier appartient à usr_sara:proj_web" \
  'owner_is "$L/atelier" usr_sara && group_is "$L/atelier" proj_web' \
  "\`chown user:groupe\` règle les deux d'un coup." \
  "\`ls -ld\` montre le propriétaire (3e colonne) et le groupe (4e colonne)." \
  "Attendu : usr_sara proj_web." \
  "sudo chown usr_sara:proj_web atelier && ls -ld atelier"

step "Définis propriétaire ET groupe de \`fichier_umask.txt\`, puis vérifie : \`sudo chown usr_ali:proj_web fichier_umask.txt\` puis \`ls -ld fichier_umask.txt\`."

q_fs "fichier_umask.txt appartient à usr_ali:proj_web" \
  'owner_is "$L/fichier_umask.txt" usr_ali && group_is "$L/fichier_umask.txt" proj_web' \
  "\`chown user:groupe\` règle les deux d'un coup." \
  "\`ls -ld\` montre le propriétaire (3e colonne) et le groupe (4e colonne)." \
  "Attendu : usr_ali proj_web." \
  "sudo chown usr_ali:proj_web fichier_umask.txt && ls -ld fichier_umask.txt"

step "Définis propriétaire ET groupe de \`dossier_umask\`, puis vérifie : \`sudo chown usr_sara:proj_web dossier_umask\` puis \`ls -ld dossier_umask\`."

q_fs "dossier_umask appartient à usr_sara:proj_web" \
  'owner_is "$L/dossier_umask" usr_sara && group_is "$L/dossier_umask" proj_web' \
  "\`chown user:groupe\` règle les deux d'un coup." \
  "\`ls -ld\` montre le propriétaire (3e colonne) et le groupe (4e colonne)." \
  "Attendu : usr_sara proj_web." \
  "sudo chown usr_sara:proj_web dossier_umask && ls -ld dossier_umask"

synthese \
  "1. Convertir -rw-r----- en octal et expliquer chaque bloc." \
  "2. Quelle est la différence entre chmod 640 et chmod u=rw,g=r,o= ?" \
  "3. Que retire umask 027 à un fichier et à un dossier créés ensuite ?" \
  "4. Quelle est la différence entre chown et chgrp ?"

finalize
