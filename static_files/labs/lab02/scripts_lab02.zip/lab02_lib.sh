#!/usr/bin/env bash
# =============================================================================
# lab02_lib.sh — moteur de mission TP (portable : bash 3.2+, outils POSIX)
# Fonctionne sur WSL / Kali / Ubuntu / macOS. Aucune dépendance GNU-only.
# =============================================================================

# --- chemins ---------------------------------------------------------------
LIB_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# --- couleurs (uniquement si stdout est un terminal) -----------------------
if [ -t 1 ]; then
    c_blue=$(printf '\033[1;34m');  c_green=$(printf '\033[1;32m')
    c_red=$(printf '\033[1;31m');   c_yellow=$(printf '\033[1;33m')
    c_reset=$(printf '\033[0m')
else
    c_blue=''; c_green=''; c_red=''; c_yellow=''; c_reset=''
fi

# --- état global (réinitialisé par chaque script d'exercice) ---------------
SCORE=0        # étapes réussies
TOTAL=0        # étapes totales
HINTS_USED=0   # indices consommés
REVEALED=0     # réponses révélées (après épuisement des indices)
STEP_NO=0      # numéro d'étape courant
MAX_STEPS=0    # nombre total d'étapes (fixé par l'exercice)
REPORT=""      # chemin du rapport (fixé par l'exercice)
POINTS=5       # barème cible de l'objectif (fixé par l'exercice)

# --- sortie élémentaire ----------------------------------------------------
say()     { printf '%s\n' "$*"; }
title()   { printf '\n%s\n' "${c_blue}== $* ==${c_reset}"; }
correct() { SCORE=$((SCORE+1)); say "${c_green}  [OK] Correct.${c_reset}"; }
hint()    { HINTS_USED=$((HINTS_USED+1)); say "${c_yellow}  Indice : $*${c_reset}"; }
reveal()  { REVEALED=$((REVEALED+1)); say "${c_yellow}  Réponse : $*${c_reset}"; }

record()  { printf '%s\n' "$*" >> "$REPORT"; }

# --- demander le nom de l'étudiant (capture + question) --------------------
ask_name() {
    # capture système (toujours)
    SYS_USER=$(whoami 2>/dev/null || printf '%s' "$USER")
    SYS_HOST=$(hostname 2>/dev/null || printf 'inconnu')

    NAME_FILE="$LIB_DIR/.mission_name"
    if [ -s "$NAME_FILE" ]; then
        NAME=$(cat "$NAME_FILE")
    else
        printf 'Ton nom et prénom : '
        read -r NAME
        if [ -n "$NAME" ]; then
            printf '%s' "$NAME" > "$NAME_FILE" 2>/dev/null || true
        fi
    fi
    [ -n "$NAME" ] || NAME='(non renseigné)'
}

# --- init : en-tête du rapport ---------------------------------------------
begin() {
    # $1 = nom du rapport ; $2 = nombre d'étapes ; $3 = titre ; $4 = libellé (ex TP02) ; $5 = points (défaut 5)
    REPORT="$LIB_DIR/$1"
    MAX_STEPS="$2"
    LABEL="${4:-TP}"
    POINTS="${5:-5}"

    say "${c_red}Rappel : l'annexe du PDF (aide-mémoire) liste les commandes du TP.${c_reset}"
    say "${c_red}En cas de doute : \`man commande\`. Commande oubliée : \`man -k mot-clé\`.${c_reset}"

    ask_name

    rm -f "$REPORT"
    : > "$REPORT"
    record "================================================================"
    record "RAPPORT DE MISSION — $LABEL"
    record "$3"
    record "================================================================"
    record "Étudiant    : $NAME"
    record "Machine     : $SYS_USER@$SYS_HOST"
    record "Date        : $(date '+%Y-%m-%d %H:%M:%S')"
    record "================================================================"
    record ""
    record "--- Déroulé ---"
}

# --- signature : cksum (POSIX, portable) du corps du rapport ---------------
finalize() {
    record ""
    record "--- Score ---"
    record "Étapes réussies : $SCORE/$MAX_STEPS"

    # équivalent sur POINTS, arrondi entier
    if [ "$MAX_STEPS" -gt 0 ]; then
        EQ=$(( (SCORE * POINTS + MAX_STEPS / 2) / MAX_STEPS ))
    else
        EQ=0
    fi
    record "Équivalent /$POINTS : $EQ"
    record "Indices utilisés: $HINTS_USED"
    record "Réponses révélées: $REVEALED"
    record ""

    # signature du corps produit jusqu'ici (détecte une édition manuelle)
    SIG=$(cksum < "$REPORT")
    record "--- Signature ---"
    record "cksum: $SIG"
    record "================================================================"

    chmod 444 "$REPORT" 2>/dev/null || true

    title "Objectif terminé — score $SCORE/$MAX_STEPS (≈ $EQ/$POINTS)"
    say "${c_red}Rapport verrouillé en lecture seule — toute modification invalide la signature cksum.${c_reset}"
    say "Ton rapport est dans : $REPORT"
}

# --- une étape : énoncé + « fais-le dans ton terminal » --------------------
step() {
    STEP_NO=$((STEP_NO+1))
    TOTAL=$((TOTAL+1))
    printf '\n%s\n' "${c_yellow}Étape ${STEP_NO}/${MAX_STEPS}${c_reset}"
    say "$1"
    say "Fais-le dans TON terminal, puis reviens ici et appuie sur Entrée."
    read -r _
}

# --- question à réponse fixe (variantes acceptées, normalisées) ------------
# usage : q_fixed "question" "variante1|variante2" "indice1" "indice2" "indice3"
q_fixed() {
    local question="$1" expected="$2"; shift 2
    local hints=("$@") attempt=0 ans norm ok e IFS old_IFS="$IFS" revealed

    while true; do
        say "$question"
        printf '> '
        read -r ans
        record "Q${STEP_NO}. $question"
        record "   → réponse : « $ans »"

        norm=$(printf '%s' "$ans" | tr '[:upper:]' '[:lower:]' | sed 's/^[[:space:]]*//; s/[[:space:]]*$//' | tr -s ' ')

        ok=0
        IFS='|'
        for e in $expected; do
            [ "$norm" = "$e" ] && { ok=1; break; }
        done
        IFS="$old_IFS"

        if [ "$ok" = "1" ]; then
            correct
            return 0
        fi

        if [ "$attempt" -lt "${#hints[@]}" ]; then
            record "   → indice  : ${hints[$attempt]}"
            hint "${hints[$attempt]}"
            attempt=$((attempt+1))
        else
            revealed=$(printf '%s' "$expected" | cut -d'|' -f1)
            record "   → réponse révélée : $revealed"
            reveal "$revealed"
            while true; do
                say "Répète la réponse pour continuer (l'étape reste notée 0) :"
                printf '> '
                read -r ans
                norm=$(printf '%s' "$ans" | tr '[:upper:]' '[:lower:]' | sed 's/^[[:space:]]*//; s/[[:space:]]*$//' | tr -s ' ')
                ok=0
                IFS='|'
                for e in $expected; do
                    [ "$norm" = "$e" ] && { ok=1; break; }
                done
                IFS="$old_IFS"
                [ "$ok" = "1" ] && break
            done
            record "   → complété (révélé)"
            return 1
        fi
    done
}

# --- question numérique (la vérité est calculée EN DIRECT, portable) -------
# usage : q_number "question" <valeur-attendue> "indice1" "indice2" "indice3"
q_number() {
    local question="$1" truth="$2"; shift 2
    local hints=("$@") attempt=0 ans

    # normaliser la vérité (BSD wc padde le nombre, ex. "      42")
    truth=$(printf '%s' "$truth" | sed 's/^[[:space:]]*//; s/[[:space:]]*$//')

    while true; do
        say "$question"
        printf '> '
        read -r ans
        record "Q${STEP_NO}. $question"
        record "   → réponse : « $ans »"

        ans=$(printf '%s' "$ans" | sed 's/^[[:space:]]*//; s/[[:space:]]*$//')

        if [ "$ans" = "$truth" ]; then
            correct
            return 0
        fi

        if [ "$attempt" -lt "${#hints[@]}" ]; then
            record "   → indice  : ${hints[$attempt]}"
            hint "${hints[$attempt]}"
            attempt=$((attempt+1))
        else
            record "   → réponse révélée : $truth"
            reveal "$truth"
            while true; do
                say "Répète la réponse pour continuer (l'étape reste notée 0) :"
                printf '> '
                read -r ans
                ans=$(printf '%s' "$ans" | sed 's/^[[:space:]]*//; s/[[:space:]]*$//')
                [ "$ans" = "$truth" ] && break
            done
            record "   → complété (révélé)"
            return 1
        fi
    done
}

# --- vérification de l'état réel du filesystem (aucune saisie) -------------
# usage : q_fs "description" 'test ...' "indice1" "indice2" "indice3" "réponse"
q_fs() {
    local desc="$1" testcmd="$2" h1="$3" h2="$4" h3="$5" answer="$6"
    local attempt=0

    while true; do
        say "Je vérifie : $desc"
        record "Q${STEP_NO}. $desc"
        if eval "$testcmd"; then
            record "   → [OK] état vérifié"
            correct
            return 0
        fi
        record "   → état non conforme"
        if [ "$attempt" -eq 0 ]; then
            record "   → indice  : $h1"; hint "$h1"
        elif [ "$attempt" -eq 1 ]; then
            record "   → indice  : $h2"; hint "$h2"
        elif [ "$attempt" -eq 2 ]; then
            record "   → indice  : $h3"; hint "$h3"
        else
            record "   → réponse révélée : $answer"
            reveal "$answer"
            while ! eval "$testcmd"; do
                say "Corrige dans ton terminal (la commande est ci-dessus), puis reviens ici et appuie sur Entrée."
                read -r _
            done
            record "   → complété (révélé)"
            return 1
        fi
        attempt=$((attempt+1))
        say "Corrige dans ton terminal, puis reviens ici et appuie sur Entrée."
        read -r _
    done
}
