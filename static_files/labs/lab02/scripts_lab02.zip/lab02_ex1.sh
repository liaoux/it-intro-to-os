#!/usr/bin/env bash
# =============================================================================
# lab02_ex1.sh — Objectif 1 : Navigation et gestion de fichiers
# =============================================================================
. "$(dirname "${BASH_SOURCE[0]}")/lab02_lib.sh"

begin "report_lab02_ex1.txt" 10 "Objectif 1 — Navigation, fichiers et métacaractères" "TP02" 7

title "Objectif 1 — Sécuriser le terrain"

step "Repère-toi dans ton terminal."

q_fixed \
  "Quelle commande affiche le répertoire courant ?" \
  "pwd|print working directory" \
  "C'est l'abréviation de « print working directory »." \
  "Elle fait trois lettres." \
  "Regarde la 1re ligne du tableau « Navigation » de l'annexe."

step "Liste les fichiers cachés de ton répertoire personnel avec \`ls\`."

q_fixed \
  "Quelle option de \`ls\` affiche les fichiers cachés (commençant par un point) ?" \
  "-a|--all|a|all|-la|la" \
  "Les fichiers cachés commencent par un point (ex. .bashrc)." \
  "Tape \`ls --help\` et cherche « hidden »." \
  "Consulte \`man ls\` ou l'annexe pour trouver l'option des fichiers cachés."

step "Crée d'un coup les répertoires \`rapports\`, \`donnees\` et \`archives\` dans \`~/oslabs/lab02/audit\` (parents inclus)."

q_fs "l'arborescence ~/oslabs/lab02/audit/{rapports,donnees,archives} existe" \
  '[ -d "$HOME/oslabs/lab02/audit/rapports" ] && [ -d "$HOME/oslabs/lab02/audit/donnees" ] && [ -d "$HOME/oslabs/lab02/audit/archives" ]' \
  "Utilise \`mkdir\` pour créer un répertoire." \
  "Une seule commande suffit si tu listes les trois répertoires." \
  "Consulte \`man mkdir\` : quelle option crée les répertoires parents manquants ?" \
  "mkdir -p ~/oslabs/lab02/audit/rapports ~/oslabs/lab02/audit/donnees ~/oslabs/lab02/audit/archives"

step "Dans \`~/oslabs/lab02/audit/donnees\`, crée \`notes.txt\`, \`carnet.txt\` et \`carnet.log\` avec \`touch\`."

q_fs "notes.txt et carnet.txt existent dans ~/oslabs/lab02/audit/donnees" \
  '[ -f "$HOME/oslabs/lab02/audit/donnees/notes.txt" ] && [ -f "$HOME/oslabs/lab02/audit/donnees/carnet.txt" ]' \
  "\`touch\` crée un fichier vide." \
  "Une seule commande \`touch\` peut créer plusieurs fichiers à la fois." \
  "Vérifie que tu es bien dans \`donnees\` avec \`pwd\`." \
  "cd ~/oslabs/lab02/audit/donnees && touch notes.txt carnet.txt carnet.log"

step "Copie \`carnet.txt\` en \`carnet.bak\`."

q_fs "le fichier ~/oslabs/lab02/audit/donnees/carnet.bak existe" \
  '[ -f "$HOME/oslabs/lab02/audit/donnees/carnet.bak" ]' \
  "\`cp source cible\` copie." \
  "La source est \`carnet.txt\`." \
  "Consulte \`man cp\` : la cible garde le même nom de base mais une autre extension." \
  "cp carnet.txt carnet.bak"

step "Déplace \`carnet.log\` vers \`~/oslabs/lab02/audit/archives\`."

q_fs "carnet.log est dans ~/oslabs/lab02/audit/archives" \
  '[ -f "$HOME/oslabs/lab02/audit/archives/carnet.log" ]' \
  "\`mv\` déplace ET renomme." \
  "Indique le dossier de destination." \
  "Consulte \`man mv\` : déplace le fichier vers le dossier réservé aux fichiers terminés." \
  "mv carnet.log ~/oslabs/lab02/audit/archives/"

step "Renomme \`notes.txt\` en \`resume.txt\`."

q_fs "resume.txt remplace notes.txt dans ~/oslabs/lab02/audit/donnees" \
  '[ -f "$HOME/oslabs/lab02/audit/donnees/resume.txt" ] && [ ! -e "$HOME/oslabs/lab02/audit/donnees/notes.txt" ]' \
  "\`mv ancien nouveau\` renomme." \
  "Le nom change, pas le contenu." \
  "Consulte \`man mv\` : renommer, c'est déplacer vers un nom plus descriptif." \
  "mv notes.txt resume.txt"

step "Crée des fichiers de test : \`photo-01.jpg\`, \`photo-02.jpg\`, \`rapport-2026.pdf\`, \`rapport-2027.pdf\`."

q_fs "photo-01.jpg et rapport-2026.pdf existent dans ~/oslabs/lab02/audit/donnees" \
  '[ -f "$HOME/oslabs/lab02/audit/donnees/photo-01.jpg" ] && [ -f "$HOME/oslabs/lab02/audit/donnees/rapport-2026.pdf" ]' \
  "Une seule commande \`touch\` peut créer plusieurs fichiers." \
  "Liste les quatre noms après \`touch\`, séparés par des espaces." \
  "Consulte \`man touch\` : une seule commande peut créer plusieurs fichiers d'un coup." \
  "touch photo-01.jpg photo-02.jpg rapport-2026.pdf rapport-2027.pdf"

step "Dans \`~/oslabs/lab02/audit/donnees\`, tape \`ls *.txt\` et observe."

q_number \
  "Combien de fichiers affiche \`ls *.txt\` ? (un nombre)" \
  "$(ls "$HOME/oslabs/lab02/audit/donnees/"*.txt 2>/dev/null | wc -l)" \
  "Le motif \`*.txt\` est remplacé par le shell par les noms en .txt." \
  "Compte les fichiers de \`donnees\` qui se terminent par \`.txt\`." \
  "\`carnet.bak\` ne compte pas ; cherche les fichiers en \`.txt\`."

step "Supprime les fichiers \`.jpg\` en demandant confirmation pour chacun."

q_fixed \
  "Quelle option de \`rm\` demande confirmation avant chaque suppression ?" \
  "-i|--interactive|i|interactive" \
  "Tape \`rm --help\` et cherche « prompt » ou « interactive »." \
  "L'option s'écrit avec un tiret suivi d'une seule lettre." \
  "Consulte \`man rm\` : cherche l'option « prompt before every removal »."

finalize
