#!/usr/bin/env bash
# =============================================================================
# lab02_ex2.sh — Objectif 2 : Filtres, redirections et pipelines (BOSS)
# =============================================================================
. "$(dirname "${BASH_SOURCE[0]}")/lab02_lib.sh"

begin "report_lab02_ex2.txt" 12 "Objectif 2 — Filtres, redirections et pipelines" "TP02" 8

title "Objectif 2 (BOSS) — Produire le rapport d'audit"

step "Depuis \`~/oslabs/lab02\`, tape \`head -n 5 comptes.txt\` et observe le format d'un compte."

q_fixed \
  "Quel est le nom du tout premier compte du fichier comptes.txt ?" \
  "root" \
  "Regarde la toute première ligne affichée." \
  "C'est le compte de l'administrateur." \
  "Ce compte a le numéro d'identification le plus bas."

step "Compte les comptes du fichier avec \`wc -l comptes.txt\`."

q_number \
  "Combien de lignes contient comptes.txt ? (un nombre)" \
  "$(wc -l < "$HOME/oslabs/lab02/comptes.txt")" \
  "\`wc -l\` compte les lignes ; chaque ligne = un compte." \
  "Utilise \`wc -l comptes.txt\` et lis le premier nombre affiché." \
  "Le résultat est le nombre total de comptes du fichier."

step "Recommence en passant le fichier par l'entrée standard : \`wc -l < comptes.txt\`."

q_fixed \
  "Quel symbole redirige un fichier vers l'entrée standard d'une commande ?" \
  "<|chevron ouvrant|inferieur|plus petit" \
  "Voir le tableau « Redirections » de l'annexe." \
  "C'est l'opérateur opposé à \`>\`." \
  "L'annexe liste l'opérateur d'entrée juste à côté de l'opérateur de sortie."

step "Trie comptes.txt en ordre alphabétique inverse et limite l'affichage aux 5 premières lignes."

q_fixed \
  "Quelle option de \`sort\` trie en ordre décroissant (inverse) ?" \
  "-r|--reverse|r|reverse" \
  "Tape \`sort --help\` et cherche « reverse »." \
  "C'est l'option « reverse »." \
  "Consulte \`man sort\` : l'option porte le nom anglais de « reverse »."

step "Extrais le premier champ de comptes.txt (les noms de comptes) et enregistre la liste dans \`~/oslabs/lab02/audit/donnees/utilisateurs.txt\` SANS l'afficher à l'écran."

q_fs "~/oslabs/lab02/audit/donnees/utilisateurs.txt existe et n'est pas vide" \
  '[ -s "$HOME/oslabs/lab02/audit/donnees/utilisateurs.txt" ]' \
  "Commence par \`cut\` pour extraire le champ 1, avec le bon séparateur." \
  "Le séparateur des champs de comptes.txt est \`:\`." \
  "Après avoir extrait, consulte le tableau « Redirections » de l'annexe pour écrire dans un fichier sans afficher." \
  "cut -d: -f1 ~/oslabs/lab02/comptes.txt > ~/oslabs/lab02/audit/donnees/utilisateurs.txt"

step "Sépare données et erreurs : depuis \`~/oslabs/lab02\`, liste \`comptes.txt\` ET un fichier qui n'existe pas, résultats dans \`audit/donnees/config.txt\`, erreurs dans \`audit/donnees/erreurs.log\`."

q_fs "~/oslabs/lab02/audit/donnees/config.txt et erreurs.log existent et ne sont pas vides" \
  '[ -s "$HOME/oslabs/lab02/audit/donnees/config.txt" ] && [ -s "$HOME/oslabs/lab02/audit/donnees/erreurs.log" ]' \
  "Une seule commande peut produire à la fois une sortie et une erreur." \
  "Une redirection pour la sortie standard, une autre pour les erreurs." \
  "Consulte le tableau « Redirections » de l'annexe : une flèche pour stdout, une pour stderr." \
  "ls comptes.txt introuvable > audit/donnees/config.txt 2> audit/donnees/erreurs.log"

step "Teste l'ordre des redirections : depuis \`~/oslabs/lab02\`, tape \`ls introuvable > sortie.txt 2>&1\` puis lis \`sortie.txt\`."

q_fixed \
  "Quel opérateur fusionne la sortie d'erreur (stderr) vers la sortie standard (stdout) ?" \
  "2>&1" \
  "Les descripteurs : 0 = entrée, 1 = sortie, 2 = erreur." \
  "On « duplique » le flux 2 vers la destination du flux 1." \
  "Consulte le tableau « Redirections » de l'annexe : l'opérateur fusionne le flux 2 vers le flux 1."

step "Construis le pipeline complet : \`cut -d: -f1 comptes.txt | sort | uniq | wc -l\`."

q_number \
  "Quel nombre affiche ce pipeline complet ? (un nombre)" \
  "$(cut -d: -f1 "$HOME/oslabs/lab02/comptes.txt" | sort | uniq | wc -l)" \
  "Lis le pipeline de gauche à droite : couper, trier, dédoublonner, compter." \
  "Chaque commande reçoit la sortie de la précédente via le pipe \`|\`." \
  "Les noms sont tous uniques, donc le résultat est le nombre total de comptes."

step "Compte les shells utilisés : \`cut -d: -f7 comptes.txt | sort | uniq -c\`."

q_number \
  "Combien de LIGNES affiche cette table de fréquences ? (un nombre)" \
  "$(cut -d: -f7 "$HOME/oslabs/lab02/comptes.txt" | sort -u | wc -l)" \
  "\`uniq -c\` compte les occurrences de chaque valeur distincte." \
  "Chaque ligne de la table correspond à un shell différent." \
  "Le nombre cherché est le nombre de shells DISTINCTS."

step "Enregistre la liste triée des comptes DANS un fichier TOUT EN l'affichant, avec \`tee\` : \`~/oslabs/lab02/audit/rapports/comptes_tries.txt\`."

q_fs "~/oslabs/lab02/audit/rapports/comptes_tries.txt existe et n'est pas vide" \
  '[ -s "$HOME/oslabs/lab02/audit/rapports/comptes_tries.txt" ]' \
  "\`tee fichier\` écrit dans le fichier ET laisse passer le flux." \
  "Place \`tee\` entre \`sort\` et \`wc -l\`." \
  "Consulte \`man tee\` : le dossier \`rapports\` doit exister avant d'y écrire." \
  "cut -d: -f1 ~/oslabs/lab02/comptes.txt | sort | tee ~/oslabs/lab02/audit/rapports/comptes_tries.txt | wc -l"

step "Vérifie le fichier que tu viens de créer en comptant ses lignes."

q_number \
  "Combien de lignes contient ~/oslabs/lab02/audit/rapports/comptes_tries.txt ? (un nombre)" \
  "$(wc -l < "$HOME/oslabs/lab02/audit/rapports/comptes_tries.txt" 2>/dev/null)" \
  "\`wc -l fichier\` (ou \`wc -l < fichier\`) compte les lignes." \
  "Ce fichier contient la liste triée des comptes, un par ligne." \
  "Ce nombre est le même que celui de l'étape du pipeline complet."

step "Surveille comptes.txt en direct : depuis \`~/oslabs/lab02\`, lance \`tail -f comptes.txt\` pendant ~20 s, puis interromps."

q_fixed \
  "Quelle combinaison de touches interrompt \`tail -f\` ?" \
  "ctrl+c|ctrl c|ctrl + c|ctrl-c|^c|control+c" \
  "C'est un signal d'interruption envoyé au programme en avant-plan." \
  "Le \`+\` désigne « en même temps » : maintiens une touche et appuie l'autre." \
  "Ce signal s'appelle SIGINT."

finalize
