#!/usr/bin/env bash
# =============================================================================
# lab09_ex3.sh — Objectif 3 : Du programme au noyau
# =============================================================================
. "$(dirname "${BASH_SOURCE[0]}")/lab09_lib.sh"

A="$HOME/oslabs/lab09/audit"
BANNER="Rappel : consulte le manuel avant chaque nouvelle commande. strace montre les appels système ; les compteurs de défauts de page et les valeurs de vmstat dépendent de la machine."

begin "report_lab09_ex3.txt" 20 "Objectif 3 — Du programme au noyau" "TP09" 5 "$BANNER"

title "Objectif 3 — Allocation, appels système et défauts de page"

step "Déplace-toi dans le dossier du TP et vérifie le chemin affiché."

q_fs "tu es bien dans ~/oslabs/lab09" \
  '[ "$PWD" = "$HOME/oslabs/lab09" ]' \
  "Utilise cd avec un chemin absolu." \
  "Le dossier est ~/oslabs/lab09." \
  "Tu dois être à la racine du TP, pas dans audit/." \
  "cd ~/oslabs/lab09"

step "Vérifie que malloc_demo.c est dans audit/ ; sinon copie-le depuis le dossier du TP."

q_fs "le fichier audit/malloc_demo.c existe" \
  '[ -s "$A/malloc_demo.c" ]' \
  "Le source est fourni dans ~/oslabs/lab09/." \
  "Le dossier de destination est audit/." \
  "Copie le fichier avec cp." \
  'cp "$HOME/oslabs/lab09/malloc_demo.c" "$HOME/oslabs/lab09/audit/"'

step "Lis l'en-tête et la fonction usage de malloc_demo.c, puis affiche l'aide avec ./audit/malloc_demo --help."

q_choice \
  "Que fait malloc_demo sans argument ?" \
  "il affiche seulement l'usage|il lance les allocations ; --help affiche l'usage|il compile le programme|il ne fait rien" \
  2 \
  "L'en-tête décrit les trois allocations." \
  "La fonction usage est appelée avec --help." \
  "Sans argument, le programme exécute la démonstration."

step "Lis les commentaires des fonctions touch_pages et allocate."

q_choice \
  "Pourquoi touch_pages écrit-il dans chaque page ?" \
  "pour libérer la mémoire|pour provoquer des défauts de page et rendre les pages résidentes|pour compiler le programme|pour créer une table des pages" \
  2 \
  "malloc réserve de l'espace virtuel." \
  "Le premier accès à une page déclenche un défaut de page." \
  "Le programme écrit un octet par page."

step "Compile malloc_demo.c dans audit/ avec gcc."

q_fs "le binaire audit/malloc_demo existe et est exécutable" \
  '[ -x "$A/malloc_demo" ]' \
  "Compile malloc_demo.c avec gcc." \
  "Le source est dans audit/." \
  "Le binaire doit s'appeler malloc_demo." \
  'cd "$HOME/oslabs/lab09/audit" && gcc -Wall -Wextra -o malloc_demo malloc_demo.c'

step "Cherche malloc dans le manuel, section 3."

q_choice \
  "Que fait malloc, et que retourne-t-elle en cas d'échec ?" \
  "elle alloue un bloc et retourne NULL en cas d'échec|elle libère un bloc et retourne 0|elle affiche la mémoire libre|elle crée une projection" \
  1 \
  "malloc alloue des octets." \
  "La valeur de retour est un pointeur." \
  "En cas d'échec, le pointeur vaut NULL."

step "Cherche brk dans le manuel, section 2."

q_choice \
  "Que déplace brk ?" \
  "la table des pages|la limite supérieure du tas|le registre de base|la pile" \
  2 \
  "brk concerne le tas." \
  "Il déplace la limite du heap." \
  "Cherche brk dans la section 2 du manuel."

step "Cherche mmap dans le manuel, section 2."

q_choice \
  "Que fait mmap ?" \
  "crée une projection dans l'espace d'adressage|supprime une projection|lit le disque|change les permissions" \
  1 \
  "mmap projette une région." \
  "Elle peut être anonyme ou liée à un fichier." \
  "Cherche mmap dans la section 2 du manuel."

step "Cherche strace dans le manuel, section 1."

q_choice \
  "Que fait l'option -e trace=... de strace ?" \
  "compiler le programme|filtrer les appels système tracés|afficher les fichiers|arrêter le programme" \
  2 \
  "strace trace les appels système." \
  "-e permet de filtrer." \
  "Cherche strace dans la section 1 du manuel."

step "Trace uniquement brk pendant une exécution de malloc_demo."

q_fs "la trace audit/trace_brk.txt contient brk" \
  '[ -s "$A/trace_brk.txt" ] && grep -q "brk" "$A/trace_brk.txt"' \
  "Trace uniquement les appels brk." \
  "Exécute audit/malloc_demo depuis audit/." \
  "Enregistre la trace dans audit/trace_brk.txt." \
  'cd "$HOME/oslabs/lab09/audit" && strace -e trace=brk -o trace_brk.txt ./malloc_demo'

step "Après la trace brk, explique le choix de malloc pour la petite allocation."

q_choice \
  "Pourquoi malloc utilise-t-il brk pour la petite allocation ?" \
  "il étend le tas pour les petites allocations|il utilise toujours mmap|le noyau crée une table des pages|le programme lit le disque" \
  1 \
  "La petite allocation est sous le seuil de mmap." \
  "malloc utilise le heap." \
  "Relis la slide sur brk et sbrk."

step "Trace mmap et munmap pendant une exécution de malloc_demo."

q_fs "la trace audit/trace_mmap.txt contient mmap, munmap et MAP_ANONYMOUS" \
  '[ -s "$A/trace_mmap.txt" ] && grep -q "mmap" "$A/trace_mmap.txt" && grep -q "munmap" "$A/trace_mmap.txt" && grep -q "MAP_ANONYMOUS" "$A/trace_mmap.txt"' \
  "Trace mmap et munmap." \
  "Exécute audit/malloc_demo depuis audit/." \
  "Enregistre la trace dans audit/trace_mmap.txt." \
  'cd "$HOME/oslabs/lab09/audit" && strace -e trace=mmap,munmap -o trace_mmap.txt ./malloc_demo'

step "Repère l'appel système qui supprime une projection créée par mmap."

q_choice \
  "Quel appel système supprime une projection créée par mmap ?" \
  "brk|mlock|munmap|mprotect" \
  3 \
  "Son nom commence par m et contient unmap." \
  "Il libère la plage d'adresses." \
  "Cherche dans la section 2 du manuel."

step "Exécute malloc_demo et observe sa sortie."

q_choice \
  "Que contient la sortie de malloc_demo ?" \
  "uniquement PID|les adresses, PID, PAGE_SIZE, SMALL_KB, MEDIUM_KB, LARGE_MB, MINFLT et MAJFLT|MemTotal, SwapTotal, Cached|seulement MINFLT" \
  2 \
  "Le programme affiche les tailles allouées." \
  "getrusage fournit les compteurs de défauts de page." \
  "Regarde les lignes MINFLT et MAJFLT."

step "Interprète les adresses affichées par malloc_demo."

q_choice \
  "Que peut-on déduire des adresses affichées ?" \
  "elles sont toujours identiques|la petite allocation est souvent près du tas, la grande dans une zone mmap, et les adresses changent selon l'exécution|elles indiquent le contenu des pages|elles remplacent MINFLT" \
  2 \
  "La petite allocation utilise souvent brk." \
  "La grande allocation utilise souvent mmap." \
  "Les adresses dépendent du processus et de l'ASLR."

step "Interprète les compteurs MINFLT et MAJFLT."

q_choice \
  "Que signifient MINFLT et MAJFLT ?" \
  "MINFLT = mémoire libre ; MAJFLT = swap|MINFLT = défauts de page mineurs sans lecture disque ; MAJFLT = défauts majeurs avec lecture disque|MINFLT = pages allouées ; MAJFLT = pages libres|MINFLT = CPU ; MAJFLT = disque" \
  2 \
  "Ces compteurs viennent de getrusage." \
  "Un défaut mineur ne nécessite pas de lecture disque." \
  "Un défaut majeur lit une page depuis un fichier ou le swap."

step "Relie les défauts de page au chargement réel des pages."

q_choice \
  "Que fait le noyau lors d'un défaut de page ?" \
  "le matériel déclenche un trap, le noyau trouve un cadre, remplit, met à jour la table puis reprend|le programme est tué immédiatement|le disque est formaté|la page est copiée dans le cache" \
  1 \
  "Le bit de validité est à 0." \
  "Le noyau traite le défaut en 5 étapes." \
  "Relis la slide sur le défaut de page."

step "Cherche vmstat dans le manuel, section 8."

q_choice \
  "Que fait vmstat 1 5 ?" \
  "affiche cinq processus|crée cinq swaps|compile cinq fois|échantillonne toutes les secondes, cinq fois" \
  4 \
  "Le premier nombre est l'intervalle." \
  "Le second est le nombre d'échantillons." \
  "Cherche vmstat dans la section 8 du manuel."

step "Dans vmstat_trace.txt, cherche la plus grande valeur de la colonne so."

q_number \
  "Quelle est la valeur maximale de so dans vmstat_trace.txt ?" \
  "$(awk 'NR>2 {if ($8+0 > max) max=$8+0} END {print max}' "$A/vmstat_trace.txt")" \
  "so est la 8e colonne." \
  "Ignore les deux lignes d'en-tête." \
  "Cherche la plus grande valeur de la colonne so."

step "Interprète wa et les valeurs élevées de si et so."

q_choice \
  "Que signifient wa et des valeurs élevées de si/so ?" \
  "wa = mémoire libre ; si/so = CPU|wa = attente E/S ; si/so élevés = forte pression mémoire|wa = swap utilisé ; si/so = disque|wa = nombre de processus ; si/so = cache" \
  2 \
  "wa signifie I/O wait." \
  "Des si/so élevés en permanence signalent une pression mémoire." \
  "Relis la slide vmstat et la ligne de synthèse."

synthese \
  "1. Pourquoi malloc utilise-t-il brk pour une petite allocation et mmap pour une grande ?" \
  "2. Décris les 5 étapes du traitement d'un défaut de page." \
  "3. Que signifient si, so et wa dans vmstat ? Que signale une valeur élevée de si/so ?" \
  "4. Quel appel système empêche une page d'être envoyée dans le swap (mlock) ? Lequel indique si des pages sont résidentes (mincore) ?"

finalize
