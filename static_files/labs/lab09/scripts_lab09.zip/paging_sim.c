/*
 * paging_sim — simulateur pédagogique de pagination.
 *
 * Modèle de la figure 18 du CM09 :
 *   mémoire virtuelle : 16 octets = 4 pages de 4 octets
 *   mémoire physique  : 32 octets = 8 cadres de 4 octets
 *   table des pages   : page logique -> cadre physique
 *
 * Adresse logique sur 4 bits :
 *   p = 2 bits (numéro de page)
 *   d = 2 bits (déplacement dans la page)
 * Adresse physique sur 5 bits :
 *   f = 3 bits (numéro de cadre)
 *   d = 2 bits (déplacement)
 *
 * Commandes :
 *   map <page> <cadre>       associe une page à un cadre libre
 *   unmap <page>             libère le cadre d'une page
 *   translate <adresse>      calcule l'adresse physique
 *   show                     affiche la table et les cadres libres
 *   reset                    réinitialise la simulation
 *   help                     affiche les commandes
 *   quit                     quitte
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define VIRTUAL_SIZE 16
#define PHYSICAL_SIZE 32
#define PAGE_SIZE 4
#define NUM_PAGES 4
#define NUM_FRAMES 8
#define PAGE_BITS 2
#define OFFSET_BITS 2
#define FRAME_BITS 3
#define PHYSICAL_BITS 5

static int page_table[NUM_PAGES];
static int frame_used[NUM_FRAMES];

static void print_bits(int value, int bits)
{
    int i;

    for (i = bits - 1; i >= 0; i--) {
        printf("%d", (value >> i) & 1);
    }
}

static void usage(const char *prog)
{
    printf("Usage: %s [--help]\n", prog);
    printf("Simulateur de pagination : %d pages de %d octets, %d cadres de %d octets.\n",
           NUM_PAGES, PAGE_SIZE, NUM_FRAMES, PAGE_SIZE);
    printf("\nCommandes :\n");
    printf("  map <page> <cadre>   associe une page (0..%d) à un cadre (0..%d)\n",
           NUM_PAGES - 1, NUM_FRAMES - 1);
    printf("  unmap <page>         libère le cadre associé à une page\n");
    printf("  translate <adresse>  calcule l'adresse physique (0..%d)\n", VIRTUAL_SIZE - 1);
    printf("  show                 affiche la table et les cadres libres\n");
    printf("  reset                réinitialise la simulation\n");
    printf("  help                 affiche cette aide\n");
    printf("  quit                 quitte\n");
}

static void reset_sim(void)
{
    int i;

    for (i = 0; i < NUM_PAGES; i++) {
        page_table[i] = -1;
    }
    for (i = 0; i < NUM_FRAMES; i++) {
        frame_used[i] = 0;
    }
}

static int valid_page(int page)
{
    return page >= 0 && page < NUM_PAGES;
}

static int valid_frame(int frame)
{
    return frame >= 0 && frame < NUM_FRAMES;
}

static void map_page(int page, int frame)
{
    if (!valid_page(page)) {
        printf("Page invalide : 0..%d.\n", NUM_PAGES - 1);
        return;
    }
    if (!valid_frame(frame)) {
        printf("Cadre invalide : 0..%d.\n", NUM_FRAMES - 1);
        return;
    }
    if (page_table[page] != -1) {
        printf("La page %d est déjà associée au cadre %d.\n", page, page_table[page]);
        return;
    }
    if (frame_used[frame]) {
        printf("Le cadre %d est déjà utilisé.\n", frame);
        return;
    }

    page_table[page] = frame;
    frame_used[frame] = 1;
    printf("page %d -> cadre %d\n", page, frame);
}

static void unmap_page(int page)
{
    int frame;

    if (!valid_page(page)) {
        printf("Page invalide : 0..%d.\n", NUM_PAGES - 1);
        return;
    }
    frame = page_table[page];
    if (frame == -1) {
        printf("La page %d n'est pas associée.\n", page);
        return;
    }

    page_table[page] = -1;
    frame_used[frame] = 0;
    printf("page %d libérée (cadre %d)\n", page, frame);
}

static void translate(int logical)
{
    int page;
    int offset;
    int frame;
    int physical;

    if (logical < 0 || logical >= VIRTUAL_SIZE) {
        printf("Adresse logique invalide : 0..%d.\n", VIRTUAL_SIZE - 1);
        return;
    }

    page = logical / PAGE_SIZE;
    offset = logical % PAGE_SIZE;
    frame = page_table[page];

    if (frame == -1) {
        printf("Page %d non associée : défaut de page simulé.\n", page);
        return;
    }

    physical = frame * PAGE_SIZE + offset;
    printf("adresse logique %d = page %d (", logical, page);
    print_bits(page, PAGE_BITS);
    printf("), déplacement %d (", offset);
    print_bits(offset, OFFSET_BITS);
    printf(")\n");
    printf("table : page %d -> cadre %d (", page, frame);
    print_bits(frame, FRAME_BITS);
    printf(")\n");
    printf("adresse physique %d (", physical);
    print_bits(physical, PHYSICAL_BITS);
    printf(") = cadre %d x %d + déplacement %d\n",
           frame, PAGE_SIZE, offset);
}

static void show_state(void)
{
    int i;
    int any;

    printf("\nTable des pages :\n");
    for (i = 0; i < NUM_PAGES; i++) {
        if (page_table[i] == -1) {
            printf("  page %d -> non associée\n", i);
        } else {
            printf("  page %d -> cadre %d\n", i, page_table[i]);
        }
    }

    printf("Cadres libres :");
    any = 0;
    for (i = 0; i < NUM_FRAMES; i++) {
        if (!frame_used[i]) {
            printf(" %d", i);
            any = 1;
        }
    }
    if (!any) {
        printf(" aucun");
    }
    printf("\n\n");
}

int main(int argc, char **argv)
{
    char line[128];
    char cmd[32];
    int a;
    int b;

    if (argc > 1) {
        usage(argv[0]);
        return strcmp(argv[1], "--help") == 0 ? 0 : 1;
    }

    reset_sim();
    printf("Simulateur de pagination — modèle de la figure 18\n");
    printf("%d pages de %d octets, %d cadres de %d octets\n",
           NUM_PAGES, PAGE_SIZE, NUM_FRAMES, PAGE_SIZE);
    printf("Tapez help pour les commandes.\n");

    for (;;) {
        printf("paging> ");
        fflush(stdout);
        if (!fgets(line, sizeof(line), stdin)) {
            printf("\n");
            break;
        }
        line[strcspn(line, "\n")] = '\0';

        if (sscanf(line, "%31s", cmd) != 1) {
            continue;
        }
        if (strcmp(cmd, "quit") == 0 || strcmp(cmd, "exit") == 0) {
            break;
        }
        if (strcmp(cmd, "help") == 0) {
            usage(argv[0]);
        } else if (strcmp(cmd, "show") == 0) {
            show_state();
        } else if (strcmp(cmd, "reset") == 0) {
            reset_sim();
            printf("Simulation réinitialisée.\n");
        } else if (strcmp(cmd, "map") == 0) {
            if (sscanf(line, "%31s %d %d", cmd, &a, &b) != 3) {
                printf("Usage : map <page> <cadre>\n");
            } else {
                map_page(a, b);
            }
        } else if (strcmp(cmd, "unmap") == 0) {
            if (sscanf(line, "%31s %d", cmd, &a) != 2) {
                printf("Usage : unmap <page>\n");
            } else {
                unmap_page(a);
            }
        } else if (strcmp(cmd, "translate") == 0) {
            if (sscanf(line, "%31s %d", cmd, &a) != 2) {
                printf("Usage : translate <adresse>\n");
            } else {
                translate(a);
            }
        } else {
            printf("Commande inconnue : %s. Tapez help.\n", cmd);
        }
    }
    return 0;
}
