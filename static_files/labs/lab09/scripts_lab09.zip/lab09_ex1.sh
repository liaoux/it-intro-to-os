#!/usr/bin/env bash
# =============================================================================
# lab09_ex1.sh — Objectif 1 : Mémoire globale et swap
# =============================================================================
. "$(dirname "${BASH_SOURCE[0]}")/lab09_lib.sh"

BANNER="Rappel : consulte le manuel avant chaque nouvelle commande. Les sections utiles sont 1 (commandes), 2 (appels système), 5 (formats de fichiers) et 8 (administration). Les valeurs mémoire dépendent de ta machine : observe, ne devine pas."

begin "report_lab09_ex1.txt" 16 "Objectif 1 — Mémoire globale et swap" "TP09" 5 "$BANNER"

title "Objectif 1 — Lire la mémoire globale, le cache et le swap"

step "Déplace-toi dans le dossier du TP et vérifie le chemin affiché."

q_fs "tu es bien dans ~/oslabs/lab09" \
  '[ "$PWD" = "$HOME/oslabs/lab09" ]' \
  "Utilise cd avec un chemin absolu." \
  "Le dossier est ~/oslabs/lab09." \
  "Tu dois être à la racine du TP, pas dans audit/." \
  "cd ~/oslabs/lab09"

step "Consulte man man et repère le rôle des sections 2, 5 et 8."

q_choice \
  "Que trouve-t-on dans les sections 2, 5 et 8 du manuel ?" \
  "2 = formats de fichiers ; 5 = appels système ; 8 = commandes utilisateur|2 = appels système ; 5 = formats de fichiers ; 8 = commandes d'administration|2 = commandes utilisateur ; 5 = appels système ; 8 = formats de fichiers|2 = appels système ; 5 = commandes d'administration ; 8 = formats de fichiers" \
  2 \
  "La section 2 documente les appels système." \
  "La section 5 documente les formats de fichiers." \
  "La section 8 regroupe les commandes d'administration."

step "Cherche free dans le manuel, section 1."

q_choice \
  "Quel est le rôle de free ?" \
  "afficher l'espace disque|afficher les processus|résumer l'état de la mémoire et du swap|lister les fichiers ouverts" \
  3 \
  "Le nom de la commande évoque la mémoire libre." \
  "Sa sortie contient une ligne Mem et une ligne Swap." \
  "Cherche free dans la section 1 du manuel."

step "Utilise free : repère la mémoire libre et le cache."

q_choice \
  "Pourquoi la mémoire libre peut-elle être faible sans saturation ?" \
  "le noyau garde des fichiers en cache, récupérables|le swap est toujours plein|les processus consomment toute la mémoire sans cache|la mémoire libre n'existe pas" \
  1 \
  "free distingue mémoire utilisée et cache." \
  "Le cache peut être libéré si un processus en a besoin." \
  "Relis la description de free dans le manuel."

step "Découvre man -k : utilise man -k proc_ et observe la liste des pages trouvées."

q_choice \
  "À quoi sert man -k ?" \
  "afficher une page de manuel précise|chercher des pages de manuel par mot-clé dans leurs descriptions|lister les processus|créer une page de manuel" \
  2 \
  "L'option -k signifie keyword." \
  "La sortie associe des pages et une courte description." \
  "Essaie man -k proc_ pour voir le résultat."

step "Utilise man -k proc_ et repère la page consacrée à la mémoire."

q_fixed \
  "Quelle page de la section 5 documente /proc/meminfo ?" \
  "proc_meminfo|proc_meminfo(5)|proc_meminfo (5)" \
  "La liste contient plusieurs pages proc_." \
  "Cherche une page dont le nom contient meminfo." \
  "La page trouvée est en section 5."

step "Consulte la page trouvée en section 5 et repère le fichier décrit."

q_man "manuel proc_meminfo (section 5)" \
  "Quel fichier expose les compteurs mémoire du noyau ?" \
  "/proc/meminfo|proc/meminfo|meminfo" \
  "La page décrit un fichier sous /proc." \
  "Son nom contient meminfo." \
  "C'est le fichier des compteurs mémoire."

step "Affiche les 10 premières lignes de /proc/meminfo avec head -n 10."

q_choice \
  "Que contient /proc/meminfo ?" \
  "les partitions disque|les compteurs mémoire du noyau|les processus|les appels système" \
  2 \
  "Les noms commencent souvent par Mem." \
  "Il y a aussi des lignes Swap." \
  "Observe les 10 premières lignes affichées."

step "Utilise grep -E pour chercher MemTotal, MemFree, Buffers et Cached dans /proc/meminfo."

q_number \
  "Quelle est la valeur de MemTotal (en kB) ?" \
  "$(awk '/^MemTotal:/ {print $2}' /proc/meminfo)" \
  "La ligne commence par MemTotal." \
  "La valeur est le deuxième champ." \
  "Lis-la dans le fichier, ne la devine pas."

step "Consulte swapon --help : quelle option longue affiche la table des swaps actifs ?"

q_man "swapon --help" \
  "Quelle option longue affiche la table des swaps actifs ?" \
  "--show|swapon --show|-s|swapon -s" \
  "L'aide de swapon décrit les options." \
  "Cherche une option qui affiche un tableau récapitulatif." \
  "Cette option longue contient le mot show."

step "Utilise swapon --show : observe les colonnes. Sans option, swapon active un swap ; --show liste les swaps."

q_choice \
  "Que montre swapon --show ?" \
  "les files d'attente du scheduler|les pages du cache|les espaces de swap actifs (type, taille, utilisé, priorité)|les processus bloqués" \
  3 \
  "La sortie contient des colonnes NAME, TYPE, SIZE, USED et PRIO." \
  "La table vient des swaps actifs du noyau." \
  "La commande concerne le swap."

step "Utilise man -k proc_swaps et repère la page consacrée aux swaps."

q_fixed \
  "Quelle page de la section 5 documente /proc/swaps ?" \
  "proc_swaps|proc_swaps(5)|proc_swaps (5)" \
  "man -k cherche dans les descriptions." \
  "La page trouvée contient swaps dans son nom." \
  "La page est en section 5."

step "Consulte la page trouvée en section 5 et repère le fichier décrit."

q_man "manuel proc_swaps (section 5)" \
  "Quel fichier expose la table des swaps ?" \
  "/proc/swaps|proc/swaps|swaps" \
  "La page décrit un fichier sous /proc." \
  "Son nom contient swaps." \
  "C'est le fichier de la table des swaps."

swap_total=$(awk '/^SwapTotal:/ {print $2}' /proc/meminfo)
swap_free=$(awk '/^SwapFree:/ {print $2}' /proc/meminfo)
swap_total=${swap_total:-0}
swap_free=${swap_free:-0}
swap_used=$((swap_total - swap_free))

step "Utilise grep -E pour chercher SwapTotal et SwapFree dans /proc/meminfo. Calcule l'espace de swap utilisé."

q_number \
  "Sachant SwapTotal = $swap_total kB et SwapFree = $swap_free kB, quel est l'espace de swap utilisé (en kB) ?" \
  "$swap_used" \
  "SwapUsed = SwapTotal - SwapFree." \
  "Utilise les deux valeurs affichées dans la question." \
  "Le résultat est exprimé en kB."

step "Utilise free : observe la ligne Swap."

q_choice \
  "Que donne la ligne Swap de free ?" \
  "la mémoire cache|l'espace de swap total, utilisé et libre|les buffers du noyau|les pages partagées" \
  2 \
  "La sortie contient une ligne Mem et une ligne Swap." \
  "La ligne Swap est la dernière." \
  "Elle donne trois valeurs : total, used et free."

step "Cherche Huge et Hugetlb dans /proc/meminfo avec grep -E 'Huge|Hugetlb'."

q_choice \
  "Quel est l'intérêt principal des huge pages ?" \
  "augmenter le swap|créer des partitions|accélérer les accès disque|réduire le nombre d'entrées TLB" \
  4 \
  "Les huge pages sont plus grandes que 4 Ko." \
  "Elles réduisent la pression sur le TLB." \
  "Relie-les à la taille de page et à la traduction d'adresses."

synthese \
  "1. Pourquoi free peut-il afficher peu de mémoire libre alors que le système n'est pas saturé ?" \
  "2. Quelle est la différence entre MemFree, Buffers et Cached ?" \
  "3. Que représentent SwapTotal et SwapFree, et que mesure l'espace de swap utilisé ?" \
  "4. Quels avantages les huge pages apportent-elles à la traduction d'adresses ?"

finalize
