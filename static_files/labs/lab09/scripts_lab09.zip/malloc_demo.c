/*
 * malloc_demo — montre comment malloc consomme la mémoire.
 *
 * Le programme effectue trois allocations de tailles différentes, touche
 * chaque page pour provoquer des défauts de page, affiche ses
 * compteurs getrusage, puis libère les blocs.
 *
 *   petite allocation : 64 Ko   -> souvent brk
 *   allocation moyenne : 1 Mo
 *   grande allocation  : 8 Mo   -> souvent mmap
 *
 * Aucun fichier n'est écrit : les résultats sont affichés sur stdout.
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/resource.h>
#include <sys/time.h>
#include <string.h>

/*
 * usage — affiche le mode d'emploi du programme.
 * Appelée avec --help ou avec un argument inattendu.
 */
static void usage(const char *prog)
{
    printf("Usage: %s\n", prog);
    printf("Alloue 64 Ko, 1 Mo et 8 Mo, touche les pages, affiche MINFLT/MAJFLT, puis libère.\n");
}

/*
 * touch_pages — écrit un octet dans chaque page de la zone [p, p+len).
 * Ce premier accès provoque les défauts de page que l'on veut observer.
 */
static void touch_pages(volatile unsigned char *p, unsigned long len, long page)
{
    unsigned long i;

    for (i = 0; i < len; i += (unsigned long)page) {
        p[i] = (unsigned char)(i & 0xffUL);
    }
}

/*
 * allocate — encapsule malloc et arrête le programme si l'allocation échoue.
 * malloc retourne NULL en cas d'échec.
 */
static void *allocate(unsigned long size)
{
    void *p = malloc(size);

    if (!p) {
        fprintf(stderr, "malloc_demo: allocation de %lu octets impossible\n", size);
        exit(1);
    }
    return p;
}

/*
 * main — effectue trois allocations de tailles différentes, touche les pages,
 * lit les compteurs getrusage, affiche les résultats puis libère les blocs.
 */
int main(int argc, char **argv)
{
    long page;
    unsigned long small_size = 64UL * 1024UL;
    unsigned long medium_size = 1024UL * 1024UL;
    unsigned long large_size = 8UL * 1024UL * 1024UL;
    unsigned char *small;
    unsigned char *medium;
    unsigned char *large;
    struct rusage ru;

    /* Sans argument : lance la démonstration. Avec --help : affiche l'usage. */
    if (argc > 1) {
        usage(argv[0]);
        return strcmp(argv[1], "--help") == 0 ? 0 : 1;
    }

    page = sysconf(_SC_PAGESIZE);
    if (page <= 0) {
        fprintf(stderr, "malloc_demo: taille de page invalide\n");
        return 1;
    }

    small = allocate(small_size);
    touch_pages(small, small_size, page);
    printf("small : %lu octets à l'adresse %p\n", small_size, (void *)small);

    medium = allocate(medium_size);
    touch_pages(medium, medium_size, page);
    printf("medium: %lu octets à l'adresse %p\n", medium_size, (void *)medium);

    large = allocate(large_size);
    touch_pages(large, large_size, page);
    printf("large : %lu octets à l'adresse %p\n", large_size, (void *)large);

    if (getrusage(RUSAGE_SELF, &ru) != 0) {
        fprintf(stderr, "malloc_demo: getrusage impossible\n");
        free(large);
        free(medium);
        free(small);
        return 1;
    }

    printf("PID=%ld\n", (long)getpid());
    printf("PAGE_SIZE=%ld\n", page);
    printf("SMALL_KB=%lu\n", small_size / 1024UL);
    printf("MEDIUM_KB=%lu\n", medium_size / 1024UL);
    printf("LARGE_MB=%lu\n", large_size / (1024UL * 1024UL));
    /*
     * MINFLT : défauts de page mineurs depuis le démarrage. La page peut être
     *          fournie sans lecture disque (page zéro, cache, copy-on-write).
     * MAJFLT : défauts de page majeurs. La page doit être lue depuis un
     *          fichier, le swap ou un périphérique : opération coûteuse.
     */
    printf("MINFLT=%ld\n", ru.ru_minflt);
    printf("MAJFLT=%ld\n", ru.ru_majflt);

    free(large);
    free(medium);
    free(small);
    return 0;
}
