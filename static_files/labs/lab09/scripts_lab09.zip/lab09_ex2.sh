#!/usr/bin/env bash
# =============================================================================
# lab09_ex2.sh — Objectif 2 : Pagination, pages et cadres
# =============================================================================
. "$(dirname "${BASH_SOURCE[0]}")/lab09_lib.sh"

A="$HOME/oslabs/lab09/audit"
BANNER="Rappel : le simulateur de pagination est déterministe. Le modèle utilise 4 octets par page pour reproduire la figure 18 ; Linux utilise getconf PAGESIZE."

begin "report_lab09_ex2.txt" 22 "Objectif 2 — Pagination : pages, cadres et table des pages" "TP09" 5 "$BANNER"

title "Objectif 2 — Découper la mémoire virtuelle et physique"

step "Déplace-toi dans le dossier du TP et vérifie le chemin affiché."

q_fs "tu es bien dans ~/oslabs/lab09" \
  '[ "$PWD" = "$HOME/oslabs/lab09" ]' \
  "Utilise cd avec un chemin absolu." \
  "Le dossier est ~/oslabs/lab09." \
  "Tu dois être à la racine du TP, pas dans audit/." \
  "cd ~/oslabs/lab09"

step "Affiche la taille de page réelle de Linux avec getconf PAGESIZE."

q_number \
  "Quelle est la taille d'une page Linux (en octets) ?" \
  "$(getconf PAGESIZE)" \
  "getconf lit la configuration du système." \
  "Le paramètre s'appelle PAGESIZE." \
  "La valeur est exprimée en octets."

step "Vérifie que paging_sim.c est dans audit/ ; sinon copie-le depuis le dossier du TP."

q_fs "le fichier audit/paging_sim.c existe" \
  '[ -s "$A/paging_sim.c" ]' \
  "Le source est fourni dans ~/oslabs/lab09/." \
  "Le dossier de destination est audit/." \
  "Copie le fichier avec cp." \
  'cp "$HOME/oslabs/lab09/paging_sim.c" "$HOME/oslabs/lab09/audit/"'

step "Compile paging_sim.c dans audit/ avec gcc."

q_fs "le binaire audit/paging_sim existe et est exécutable" \
  '[ -x "$A/paging_sim" ]' \
  "Compile paging_sim.c avec gcc." \
  "Le source est dans audit/." \
  "Le binaire doit s'appeler paging_sim." \
  'cd "$HOME/oslabs/lab09/audit" && gcc -Wall -Wextra -o paging_sim paging_sim.c'

step "Avant de lancer le simulateur, identifie le nombre de bits m, n, p, d et f."

q_choice \
  "Quelles sont les tailles de m, n, p, d et f ?" \
  "m=2, n=4, p=2, d=2, f=3|m=4, n=4, p=1, d=3, f=2|m=4, n=2, p=2, d=2, f=3|m=5, n=2, p=2, d=2, f=3" \
  3 \
  "La mémoire virtuelle fait 16 octets = 2^4." \
  "Une page fait 4 octets = 2^2." \
  "La mémoire physique fait 32 octets = 2^5, soit 8 cadres = 2^3."

step "Lance ./audit/paging_sim et tape help."

q_choice \
  "Quelles commandes propose le simulateur de pagination ?" \
  "alloc, free, show, reset, help, quit|create, delete, print, stop|malloc, free, brk, mmap|map, unmap, translate, show, reset, help, quit" \
  4 \
  "Tape help dans le simulateur." \
  "map associe une page à un cadre." \
  "translate calcule une adresse physique."

step "Dans le simulateur, tape map 0 5 puis map 1 6."

q_choice \
  "Quelle association obtient la page 1 ?" \
  "page 1 -> cadre 1|page 1 -> cadre 6|page 1 -> cadre 5|page 1 -> non associée" \
  2 \
  "Tu as tapé map 1 6." \
  "Le cadre 6 doit apparaître dans la table." \
  "Tape show pour vérifier."

step "Tape map 2 1 puis map 3 2. Quels cadres restent libres ?"

q_choice \
  "Quels cadres restent libres après les quatre associations ?" \
  "0, 1, 2, 3|5, 6, 1, 2|aucun|0, 3, 4, 7" \
  4 \
  "Les cadres utilisés sont 5, 6, 1 et 2." \
  "Les cadres physiques vont de 0 à 7." \
  "Tape show pour vérifier."

step "Tape show et vérifie la table complète des pages."

q_choice \
  "Quelle association la table contient-elle pour la page 3 ?" \
  "page 3 -> cadre 1|page 3 -> cadre 5|page 3 -> cadre 2|page 3 -> non associée" \
  3 \
  "Tu as tapé map 3 2." \
  "La page 3 est la dernière page virtuelle." \
  "Tape show pour afficher la table."

step "Calcule l'adresse physique de l'adresse logique 0, puis vérifie avec translate 0."

q_number \
  "Quelle est l'adresse physique de l'adresse logique 0 ?" \
  "20" \
  "L'adresse 0 est dans la page 0, déplacement 0." \
  "La page 0 est associée au cadre 5." \
  "Adresse physique = cadre x 4 + déplacement."

step "Calcule l'adresse physique de l'adresse logique 1, puis vérifie avec translate 1."

q_number \
  "Quelle est l'adresse physique de l'adresse logique 1 ?" \
  "21" \
  "L'adresse 1 est dans la page 0, déplacement 1." \
  "La page 0 est associée au cadre 5." \
  "Adresse physique = 5 x 4 + 1."

step "Calcule l'adresse physique de l'adresse logique 4, puis vérifie avec translate 4."

q_number \
  "Quelle est l'adresse physique de l'adresse logique 4 ?" \
  "24" \
  "L'adresse 4 est dans la page 1, déplacement 0." \
  "La page 1 est associée au cadre 6." \
  "Adresse physique = 6 x 4 + 0."

step "Calcule l'adresse physique de l'adresse logique 6, puis vérifie avec translate 6."

q_number \
  "Quelle est l'adresse physique de l'adresse logique 6 ?" \
  "26" \
  "L'adresse 6 est dans la page 1, déplacement 2." \
  "La page 1 est associée au cadre 6." \
  "Adresse physique = 6 x 4 + 2."

step "Calcule l'adresse physique de l'adresse logique 8, puis vérifie avec translate 8."

q_number \
  "Quelle est l'adresse physique de l'adresse logique 8 ?" \
  "4" \
  "L'adresse 8 est dans la page 2, déplacement 0." \
  "La page 2 est associée au cadre 1." \
  "Adresse physique = 1 x 4 + 0."

step "Calcule l'adresse physique de l'adresse logique 9, puis vérifie avec translate 9."

q_number \
  "Quelle est l'adresse physique de l'adresse logique 9 ?" \
  "5" \
  "L'adresse 9 est dans la page 2, déplacement 1." \
  "La page 2 est associée au cadre 1." \
  "Adresse physique = 1 x 4 + 1."

step "Calcule l'adresse physique de l'adresse logique 12, puis vérifie avec translate 12."

q_number \
  "Quelle est l'adresse physique de l'adresse logique 12 ?" \
  "8" \
  "L'adresse 12 est dans la page 3, déplacement 0." \
  "La page 3 est associée au cadre 2." \
  "Adresse physique = 2 x 4 + 0."

step "Calcule l'adresse physique de l'adresse logique 14, puis vérifie avec translate 14."

q_number \
  "Quelle est l'adresse physique de l'adresse logique 14 ?" \
  "10" \
  "L'adresse 14 est dans la page 3, déplacement 2." \
  "La page 3 est associée au cadre 2." \
  "Adresse physique = 2 x 4 + 2."

step "Tape unmap 2 et observe l'état de la page 2."

q_choice \
  "Après unmap 2, quelle est l'association de la page 2 ?" \
  "page 2 -> cadre 1|page 2 -> cadre 5|page 2 -> non associée|page 2 -> cadre 4" \
  3 \
  "unmap 2 libère le cadre associé à la page 2." \
  "La page 2 n'a plus de cadre." \
  "Tape show pour vérifier."

step "Tape translate 8 et observe la réaction du simulateur."

q_choice \
  "Que fait translate 8 après unmap 2 ?" \
  "il traduit normalement vers le cadre 1|il signale un défaut de page simulé, car la page 2 n'est plus associée|il associe automatiquement un cadre|il réinitialise la table" \
  2 \
  "L'adresse 8 appartient à la page 2." \
  "La page 2 n'est plus dans la table." \
  "Le simulateur affiche « défaut de page simulé »."

step "Tape map 2 4 pour résoudre le défaut de page simulé."

q_choice \
  "Après map 2 4, quelle association obtient-on ?" \
  "page 2 -> cadre 1|page 2 -> cadre 5|page 2 -> non associée|page 2 -> cadre 4" \
  4 \
  "map 2 4 associe la page 2 au cadre 4." \
  "Le cadre 1 est libre depuis unmap 2." \
  "Tape show pour vérifier."

step "Calcule la nouvelle adresse physique de l'adresse logique 8, puis vérifie avec translate 8."

q_number \
  "Quelle est la nouvelle adresse physique de l'adresse logique 8 ?" \
  "16" \
  "L'adresse 8 reste dans la page 2, déplacement 0." \
  "La page 2 est maintenant associée au cadre 4." \
  "Adresse physique = 4 x 4 + 0."

step "Après unmap 2 puis map 2 4, quels cadres sont libres ?"

q_choice \
  "Quels cadres restent libres après unmap 2 puis map 2 4 ?" \
  "0, 3, 4, 7|0, 1, 3, 7|1, 2, 4, 6|aucun" \
  2 \
  "Les cadres utilisés sont 5, 6, 4 et 2." \
  "Le cadre 1 a été libéré par unmap 2." \
  "Tape show pour vérifier."

synthese \
  "1. Pourquoi la mémoire virtuelle est-elle découpée en pages et la mémoire physique en cadres ?" \
  "2. Comment la table des pages associe-t-elle une page à un cadre ?" \
  "3. Comment calcule-t-on l'adresse physique à partir de p, d et f ?" \
  "4. Pourquoi le simulateur utilise-t-il 4 octets par page alors que Linux utilise 4096 ?"

finalize
