#!/usr/bin/env bash
# =============================================================================
# lab10_ex1.sh — Objectif 1 : CM01 — Introduction aux systèmes d'exploitation
# Préparation au CF — contexte : passation d'un serveur Linux.
# Objectif 1 = questions de cours (QCM) uniquement, sans synthèse.
# Concepts strictement issus de cm_concepts_reference.md (CM01).
# =============================================================================
. "$(dirname "${BASH_SOURCE[0]}")/../lab10_lib.sh"

BANNER="Avant de commencer : révise cm01.pdf. Aucun rappel ici ; aide : man. Lance ce script depuis ~/oslabs/lab10/obj01."

begin "report_lab10_ex1.txt" 18 "Objectif 1 — CM01 : Introduction aux SE" "TP10" 2 "$BANNER"

title "Objectif 1 — CM01 : questions de cours"

step "Place-toi dans le dossier de l'objectif : \`cd ~/oslabs/lab10/obj01\` puis vérifie avec \`pwd\`."
q_fs "tu es dans le dossier obj01" \
  '[ "$(basename "$PWD")" = "obj01" ]' \
  "Utilise \`cd\` vers le dossier obj01." \
  "Le dossier est ~/oslabs/lab10/obj01." \
  "Vérifie avec \`pwd\`." \
  "cd ~/oslabs/lab10/obj01"

# --- Q1 ---------------------------------------------------------------------
qstep
q_choice \
  "Que désigne le système d'exploitation au sens large ?" \
  "Uniquement le noyau|Le noyau + les programmes système + le middleware|Uniquement les applications utilisateur|Le BIOS" \
  2 \
  "Le SE ne se limite pas au noyau." \
  "Il inclut aussi des utilitaires et des bibliothèques." \
  "Noyau + programmes système + middleware."

# --- Q2 ---------------------------------------------------------------------
qstep
q_choice \
  "Qu'est-ce que le noyau (kernel) ?" \
  "Un programme utilisateur ordinaire|Un fichier de configuration|Un type de mémoire|Un programme toujours en mémoire, exécuté en mode privilégié, qui gère les ressources" \
  4 \
  "Il s'exécute en mode privilégié." \
  "Il est toujours présent en mémoire." \
  "C'est le cœur du système d'exploitation."

# --- Q3 ---------------------------------------------------------------------
qstep
q_choice \
  "Quel est l'ordre du modèle à quatre composants (du plus bas au plus haut niveau) ?" \
  "Matériel → SE → applications → utilisateurs|Utilisateurs → applications → SE → matériel|SE → matériel → utilisateurs → applications|Applications → matériel → SE → utilisateurs" \
  1 \
  "On part du matériel." \
  "Matériel, puis SE, puis applications, puis utilisateurs." \
  "Le plus bas niveau est physique."

# --- Q4 ---------------------------------------------------------------------
qstep
q_choice \
  "À quoi sert le bus système ?" \
  "À stocker les fichiers de façon permanente|À exécuter les instructions arithmétiques|À transporter données, adresses et signaux de contrôle entre les composants|À convertir le courant électrique" \
  3 \
  "Il relie les composants entre eux." \
  "Il transporte données, adresses et contrôle." \
  "Il ne stocke rien, il transmet."

# --- Q5 ---------------------------------------------------------------------
qstep
q_choice \
  "Quelle est la chronologie correcte d'une interruption ?" \
  "Restauration → sauvegarde → gestionnaire|Sauvegarde de l'état → exécution du gestionnaire (ISR) → reprise|Exécution du gestionnaire → redémarrage|Suppression du processus → sauvegarde → restauration" \
  2 \
  "On préserve d'abord l'état interrompu." \
  "Sauvegarde, gestionnaire, reprise." \
  "Le programme reprend ensuite là où il s'était arrêté."

# --- Q6 ---------------------------------------------------------------------
qstep
q_choice \
  "Quelle affirmation distingue correctement le mode utilisateur du mode noyau ?" \
  "Le mode noyau est non privilégié ; le mode utilisateur est privilégié|Les deux modes ont exactement les mêmes privilèges|Les applications s'exécutent toujours en mode noyau|En mode noyau, le code peut exécuter des instructions privilégiées (accéder au matériel) ; en mode utilisateur, elles sont interdites" \
  4 \
  "Le mode noyau est privilégié." \
  "Les applications tournent en mode utilisateur." \
  "Les instructions matérielles sensibles sont réservées au noyau."

# --- Q7 ---------------------------------------------------------------------
qstep
q_choice \
  "Qu'est-ce que le vecteur d'interruption ?" \
  "Une table en mémoire basse reliant chaque interruption à sa routine (numéros 0–255)|Le nom du périphérique qui interrompt|Un registre du CPU contenant les données|Un type de bus de données" \
  1 \
  "C'est une table en mémoire basse." \
  "Chaque type d'interruption a un numéro unique." \
  "Elle donne l'adresse de la routine de traitement."

# --- Q8 ---------------------------------------------------------------------
qstep
q_choice \
  "Quel est l'intérêt du DMA (Direct Memory Access) ?" \
  "Accélérer les calculs du processeur|Remplacer la mémoire cache|Transférer un bloc sans intervention continue du CPU (une seule interruption en fin de bloc)|Augmenter la taille de la RAM" \
  3 \
  "Le CPU n'a pas à surveiller chaque octet." \
  "Le contrôleur DMA fait le transfert." \
  "Une seule interruption en fin de bloc."

# --- Q9 ---------------------------------------------------------------------
qstep
q_choice \
  "Classe ces mémoires par vitesse d'accès décroissante." \
  "Disque > RAM > cache > registres|Registres > cache > RAM > disque|RAM > registres > cache > disque|Cache > registres > disque > RAM" \
  2 \
  "Les registres sont les plus rapides." \
  "Registres, cache, RAM, disque." \
  "Plus on s'éloigne du CPU, plus c'est lent."

# --- Q10 --------------------------------------------------------------------
qstep
q_choice \
  "Qu'est-ce que le cache ?" \
  "Une mémoire permanente|Un programme du noyau|Un bus rapide|Une copie temporaire de données fréquemment utilisées dans un support plus rapide" \
  4 \
  "Ce n'est pas une mémoire permanente." \
  "Il accélère l'accès aux données fréquentes." \
  "C'est une copie temporaire dans un support plus rapide."

# --- Q11 --------------------------------------------------------------------
qstep
q_choice \
  "Que fait le chargeur (loader) au démarrage ?" \
  "Il compile le noyau|Il supprime les interruptions|Il copie le noyau du disque vers la RAM|Il crée les utilisateurs" \
  3 \
  "Le noyau doit être en mémoire pour s'exécuter." \
  "Il est chargé depuis le disque." \
  "Le chargeur copie le noyau en RAM."

# --- Q12 --------------------------------------------------------------------
qstep
q_choice \
  "Quelle affirmation sur les architectures est correcte ?" \
  "Multicœur = plusieurs ordinateurs en réseau|Monoprocesseur = plusieurs processeurs|Cluster = un seul cœur|Multicœur = plusieurs cœurs sur une même puce" \
  4 \
  "Un cluster regroupe plusieurs ordinateurs." \
  "Un monoprocesseur a un seul processeur." \
  "Multicœur = plusieurs cœurs sur une puce."

# --- Q13 --------------------------------------------------------------------
qstep
q_choice \
  "Quel service du SE gère l'accès au processeur, à la mémoire et au stockage ?" \
  "La gestion des ressources|La compilation du code|L'archivage des fichiers|Le rendu graphique" \
  1 \
  "CPU, mémoire et stockage sont des ressources." \
  "Le SE les alloue et les arbitre." \
  "C'est la gestion des ressources."

# --- Q14 --------------------------------------------------------------------
qstep
q_choice \
  "Quelle évolution a marqué les années 1950 puis 1970 ?" \
  "Temps partagé puis traitement par lots|Cloud puis mobile|Traitement par lots (batch) puis temps partagé (time-sharing)|Multicœur puis monoprocesseur" \
  3 \
  "Dans les années 1950, les traitements se faisaient par lots." \
  "Dans les années 1970, plusieurs utilisateurs partagent le CPU." \
  "Batch puis time-sharing."

# --- Q15 --------------------------------------------------------------------
qstep
q_choice \
  "Le temps partagé (time-sharing) désigne :" \
  "L'exécution de lots sans interaction|Le partage du temps CPU entre plusieurs utilisateurs/programmes interactifs|L'arrêt des interruptions|La copie du noyau en RAM" \
  2 \
  "Plusieurs utilisateurs interagissent en même temps." \
  "Le temps CPU est partagé." \
  "Chacun reçoit une tranche de temps."

# --- Q16 --------------------------------------------------------------------
qstep
q_choice \
  "Un système temps réel dur se caractérise par :" \
  "Aucune contrainte de temps|Un délai souhaitable mais non fatal|Un temps de réponse non borné|Un délai garanti (résultat correct dans une échéance stricte)" \
  4 \
  "La contrainte est temporelle et stricte." \
  "Un retard est inacceptable." \
  "Délai garanti (temps réel dur)."

# --- Q17 --------------------------------------------------------------------
qstep
q_choice \
  "Un système embarqué est :" \
  "Un ordinateur dédié à une tâche spécifique|Un serveur cloud|Un cluster de calcul|Un système de fichiers" \
  1 \
  "Il est dédié à une tâche précise." \
  "Il est intégré dans un équipement." \
  "Embarqué = dédié à une tâche spécifique."

finalize
