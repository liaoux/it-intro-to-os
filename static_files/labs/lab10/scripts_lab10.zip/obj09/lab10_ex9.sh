#!/usr/bin/env bash
# =============================================================================
# lab10_ex9.sh — Objectif 9 : CM09 — Gestion de la mémoire
# Préparation au CF — contexte : passation d'un serveur Linux.
# 8 QCM + simulation de pagination (2 tailles de page : 4 et 8 octets) + synthèse.
# Travaille DANS ~/oslabs/lab10/obj09 (paging_sim.c fourni).
# =============================================================================
. "$(dirname "${BASH_SOURCE[0]}")/../lab10_lib.sh"

if [ "$(basename "$PWD")" != "obj09" ]; then
  echo "Ce script doit être lancé depuis ~/oslabs/lab10/obj09 :"
  echo "  cd ~/oslabs/lab10/obj09 && ./lab10_ex9.sh"
  exit 1
fi

BANNER="Avant de commencer : révise cm09.pdf. Aide : man. Lance ce script depuis ~/oslabs/lab10/obj09."

begin "report_lab10_ex9.txt" 15 "Objectif 9 — CM09 : gestion de la mémoire" "TP10" 1 "$BANNER"

title "Objectif 9 — CM09 : gestion de la mémoire"

# ===================================================================== QCM --
title "Partie A — Questions de cours (QCM)"

qstep
q_choice \
  "Quelle est la différence entre une adresse logique et une adresse physique ?" \
  "La logique est réelle (RAM) ; la physique est virtuelle|La logique est virtuelle (vue par le programme) ; la physique est réelle (RAM)|Les deux sont identiques|La physique est générée par le programme" \
  2 \
  "Le programme manipule des adresses virtuelles." \
  "La RAM est adressée physiquement." \
  "Logique = virtuelle ; physique = réelle."

qstep
q_choice \
  "Quel est le rôle de la MMU ?" \
  "Exécuter les instructions|Gérer les fichiers|Compter les pages|Traduire les adresses logiques en adresses physiques" \
  4 \
  "La MMU est un composant matériel." \
  "Elle fait la traduction logique -> physique." \
  "MMU = traduction d'adresses."

qstep
q_choice \
  "Une page est … et un cadre est …" \
  "virtuelle ; physique|physique ; virtuelle|un fichier ; un dossier|un bloc ; un inode" \
  1 \
  "La page appartient à l'espace virtuel." \
  "Le cadre appartient à la mémoire physique." \
  "Page = virtuelle ; cadre = physique."

qstep
q_choice \
  "À quoi sert la table des pages ?" \
  "À stocker les données|À compter les défauts|À associer chaque page à un cadre|À trier les processus" \
  3 \
  "C'est une table de correspondance." \
  "Elle associe page logique -> cadre physique." \
  "Table des pages = page -> cadre."

qstep
q_choice \
  "Quel est le rôle du TLB ?" \
  "Stocker les pages sur disque|Accélérer la traduction d'adresses (cache de traductions)|Allouer la mémoire|Compter les défauts de page" \
  2 \
  "C'est un petit cache matériel." \
  "Il garde les traductions récentes." \
  "TLB = cache de traduction."

qstep
q_choice \
  "Si le taux de succès du TLB diminue, le temps d'accès effectif (EAT) :" \
  "diminue|reste identique|devient négatif|augmente" \
  4 \
  "Un échec TLB coûte un accès à la table." \
  "Plus de misses = plus d'accès mémoire." \
  "EAT augmente."

qstep
q_choice \
  "La pagination élimine principalement :" \
  "la fragmentation externe|la fragmentation interne|les défauts de page|le TLB" \
  1 \
  "Les pages peuvent être placées n'importe où." \
  "Plus besoin de blocs contigus." \
  "Elle supprime la fragmentation externe."

qstep
q_choice \
  "À quoi sert le swap ?" \
  "À accélérer le CPU|À créer des inodes|À déplacer des pages entre la RAM et le disque|À trier les fichiers" \
  3 \
  "La RAM est limitée." \
  "Des pages peuvent être écrites sur disque." \
  "Swap = RAM <-> disque."

# ============================================================ Mise en œuvre --
title "Partie B — Simulation de pagination (page size 4 puis 8)"

step "Compile le simulateur : \`gcc -Wall -Wextra -o paging_sim paging_sim.c\`."
q_fs "l'exécutable paging_sim existe" \
  '[ -x paging_sim ]' \
  "gcc produit un exécutable (-o paging_sim)." \
  "Corrige les erreurs si besoin." \
  "Vérifie : \`ls -l paging_sim\`." \
  "gcc -Wall -Wextra -o paging_sim paging_sim.c"

step "Lance \`./paging_sim\` : \`pagesize 4\`, puis \`map 0 5\`, \`map 1 2\`, \`map 2 7\`, \`map 3 1\`, puis \`translate 7\`. Lis l'adresse physique."
q_number \
  "Adresse physique de 7 (page size 4) ?" \
  "11" \
  "page = 7 / 4 = 1 ; décalage = 7 % 4 = 3." \
  "cadre de la page 1 = 2." \
  "physique = 2 × 4 + 3."

step "Puis \`translate 13\`. Lis l'adresse physique."
q_number \
  "Adresse physique de 13 (page size 4) ?" \
  "5" \
  "page = 13 / 4 = 3 ; décalage = 1." \
  "cadre de la page 3 = 1." \
  "physique = 1 × 4 + 1."

step "Puis \`unmap 2\` et \`translate 9\`. Que renvoie le simulateur ?"
q_choice \
  "Après unmap 2, que renvoie translate 9 ?" \
  "L'adresse physique 7|Une erreur de syntaxe|Un défaut de page simulé|La valeur 0" \
  3 \
  "La page 2 n'est plus associée à un cadre." \
  "Le simulateur détecte une page non mappée." \
  "C'est un défaut de page."

step "\`pagesize 8\`, puis \`map 0 3\`, \`map 1 1\`, puis \`translate 13\`. Lis l'adresse physique."
q_number \
  "Adresse physique de 13 (page size 8) ?" \
  "13" \
  "page = 13 / 8 = 1 ; décalage = 13 % 8 = 5." \
  "cadre de la page 1 = 1." \
  "physique = 1 × 8 + 5."

step "Puis \`translate 5\`. Lis l'adresse physique."
q_number \
  "Adresse physique de 5 (page size 8) ?" \
  "29" \
  "page = 5 / 8 = 0 ; décalage = 5." \
  "cadre de la page 0 = 3." \
  "physique = 3 × 8 + 5."

step "Puis \`unmap 1\` et \`translate 10\`. Que renvoie le simulateur ?"
q_choice \
  "Après unmap 1, que renvoie translate 10 (page size 8) ?" \
  "L'adresse physique 29|La valeur 0|Une erreur de syntaxe|Un défaut de page simulé" \
  4 \
  "La page 1 n'est plus associée." \
  "Le simulateur détecte une page non mappée." \
  "C'est un défaut de page."

# ================================================================ Synthèse --
synthese \
  "Quelle est la différence entre une adresse logique et une adresse physique, et quel est le rôle de la MMU ?" \
  "Quelle différence entre une page et un cadre, et à quoi sert la table des pages ?" \
  "Comment la taille de page change-t-elle la décomposition d'une adresse (comparer 4 et 8 octets) ?" \
  "Pourquoi la pagination élimine-t-elle la fragmentation externe (mais pas forcément l'interne) ?" \
  "Quel est le rôle du TLB, et pourquoi un faible taux de succès pénalise-t-il l'EAT ?"

finalize
