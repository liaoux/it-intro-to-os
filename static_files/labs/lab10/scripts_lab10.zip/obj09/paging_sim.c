/*
 * paging_sim — simulateur pédagogique de pagination (Objectif 9 — CM09).
 *
 * Mémoire virtuelle : 16 octets ; mémoire physique : 32 octets.
 * Taille de page configurable : 4 ou 8 octets (commande pagesize).
 *   page size 4 -> 4 pages / 8 cadres (offset sur 2 bits)
 *   page size 8 -> 2 pages / 4 cadres (offset sur 3 bits)
 *
 * Commandes :
 *   pagesize <4|8>       fixe la taille de page et réinitialise
 *   map <page> <cadre>   associe une page à un cadre
 *   unmap <page>         libère le cadre d'une page
 *   translate <adresse>  calcule l'adresse physique (détail du calcul)
 *   show                 configuration + table + cadres libres
 *   reset                réinitialise la table
 *   help                 aide
 *   quit                 quitte
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define VIRTUAL_SIZE 16
#define PHYSICAL_SIZE 32
#define MAX_PAGES 8
#define MAX_FRAMES 16

static int page_size = 4;
static int num_pages = 4;
static int num_frames = 8;
static int page_table[MAX_PAGES];
static int frame_used[MAX_FRAMES];

static void reset_sim(void)
{
    int i;
    num_pages = VIRTUAL_SIZE / page_size;
    num_frames = PHYSICAL_SIZE / page_size;
    for (i = 0; i < MAX_PAGES; i++) {
        page_table[i] = -1;
    }
    for (i = 0; i < MAX_FRAMES; i++) {
        frame_used[i] = 0;
    }
}

static void usage(void)
{
    printf("Commandes :\n");
    printf("  pagesize <4|8>       taille de page (octets)\n");
    printf("  map <page> <cadre>   associe une page à un cadre\n");
    printf("  unmap <page>         libère le cadre d'une page\n");
    printf("  translate <adresse>  calcule l'adresse physique\n");
    printf("  show                 configuration + table + cadres libres\n");
    printf("  reset                réinitialise la table\n");
    printf("  help                 cette aide\n");
    printf("  quit                 quitte\n");
}

static int valid_page(int page)
{
    return page >= 0 && page < num_pages;
}

static int valid_frame(int frame)
{
    return frame >= 0 && frame < num_frames;
}

static void map_page(int page, int frame)
{
    if (!valid_page(page)) {
        printf("Page invalide : 0..%d.\n", num_pages - 1);
        return;
    }
    if (!valid_frame(frame)) {
        printf("Cadre invalide : 0..%d.\n", num_frames - 1);
        return;
    }
    if (page_table[page] != -1) {
        printf("La page %d est déjà associée au cadre %d.\n", page, page_table[page]);
        return;
    }
    if (frame_used[frame]) {
        printf("Le cadre %d est déjà utilisé.\n", frame);
        return;
    }
    page_table[page] = frame;
    frame_used[frame] = 1;
    printf("page %d -> cadre %d\n", page, frame);
}

static void unmap_page(int page)
{
    int frame;
    if (!valid_page(page)) {
        printf("Page invalide : 0..%d.\n", num_pages - 1);
        return;
    }
    frame = page_table[page];
    if (frame == -1) {
        printf("La page %d n'est pas associée.\n", page);
        return;
    }
    page_table[page] = -1;
    frame_used[frame] = 0;
    printf("page %d libérée (cadre %d)\n", page, frame);
}

static void translate(int logical)
{
    int page;
    int offset;
    int frame;
    int physical;

    if (logical < 0 || logical >= VIRTUAL_SIZE) {
        printf("Adresse logique invalide : 0..%d.\n", VIRTUAL_SIZE - 1);
        return;
    }
    page = logical / page_size;
    offset = logical % page_size;
    frame = page_table[page];

    printf("adresse logique %d : page = %d / %d = %d, décalage = %d %% %d = %d\n",
           logical, logical, page_size, page, logical, page_size, offset);
    if (frame == -1) {
        printf("Table : page %d non associée -> DÉFAUT DE PAGE simulé.\n", page);
        return;
    }
    physical = frame * page_size + offset;
    printf("Table : page %d -> cadre %d\n", page, frame);
    printf("adresse physique = cadre(%d) × page_size(%d) + décalage(%d) = %d\n",
           frame, page_size, offset, physical);
}

static void show_state(void)
{
    int i;
    int any;

    printf("\nConfiguration : page_size=%d octets, %d pages (0..%d), %d cadres (0..%d)\n",
           page_size, num_pages, num_pages - 1, num_frames, num_frames - 1);
    printf("Table des pages :\n");
    for (i = 0; i < num_pages; i++) {
        if (page_table[i] == -1) {
            printf("  page %d -> non associée\n", i);
        } else {
            printf("  page %d -> cadre %d\n", i, page_table[i]);
        }
    }
    printf("Cadres libres :");
    any = 0;
    for (i = 0; i < num_frames; i++) {
        if (!frame_used[i]) {
            printf(" %d", i);
            any = 1;
        }
    }
    if (!any) {
        printf(" aucun");
    }
    printf("\n\n");
}

int main(void)
{
    char line[128];
    char cmd[32];
    int a;
    int b;

    reset_sim();
    printf("Simulateur de pagination — mémoire virtuelle 16 o, physique 32 o\n");
    printf("Page size par défaut : 4 octets. Tapez help.\n");

    for (;;) {
        printf("paging> ");
        fflush(stdout);
        if (!fgets(line, sizeof(line), stdin)) {
            printf("\n");
            break;
        }
        if (sscanf(line, "%31s", cmd) != 1) {
            continue;
        }
        if (strcmp(cmd, "quit") == 0 || strcmp(cmd, "exit") == 0) {
            break;
        } else if (strcmp(cmd, "help") == 0) {
            usage();
        } else if (strcmp(cmd, "reset") == 0) {
            reset_sim();
            printf("Simulation réinitialisée (page_size=%d).\n", page_size);
        } else if (strcmp(cmd, "show") == 0) {
            show_state();
        } else if (strcmp(cmd, "pagesize") == 0) {
            if (sscanf(line, "%31s %d", cmd, &a) != 2 || (a != 4 && a != 8)) {
                printf("Usage : pagesize <4|8>\n");
            } else {
                page_size = a;
                reset_sim();
                printf("Page size = %d octets : %d pages, %d cadres (table réinitialisée).\n",
                       page_size, num_pages, num_frames);
            }
        } else if (strcmp(cmd, "map") == 0) {
            if (sscanf(line, "%31s %d %d", cmd, &a, &b) != 3) {
                printf("Usage : map <page> <cadre>\n");
            } else {
                map_page(a, b);
            }
        } else if (strcmp(cmd, "unmap") == 0) {
            if (sscanf(line, "%31s %d", cmd, &a) != 2) {
                printf("Usage : unmap <page>\n");
            } else {
                unmap_page(a);
            }
        } else if (strcmp(cmd, "translate") == 0) {
            if (sscanf(line, "%31s %d", cmd, &a) != 2) {
                printf("Usage : translate <adresse>\n");
            } else {
                translate(a);
            }
        } else {
            printf("Commande inconnue : %s. Tapez help.\n", cmd);
        }
    }
    return 0;
}
