#!/bin/bash
# script_debug.sh — compte ou liste les fichiers .txt du répertoire courant
# Usage : ./script_debug.sh compte | liste

lister() {
    for f in *.txt; do
        echo "- $f"
    done
}

compter() {
    local n=0
    for f in *.txt; do
        if [ -f $f ]
        then
            n = n + 1
        fi
    done
    echo "$n"
}

if [ $# -eq 0 ]
    echo "usage : $0 {compte|liste}"
    exit 1
fi

case "$1" in
    compte) compter ;;
    liste)  lister
    *)      echo "usage : $0 {compte|liste}" ;;
esac
