#!/usr/bin/env bash
# =============================================================================
# lab10_ex6.sh — Objectif 6 : CM06 — Programmation shell
# Préparation au CF — contexte : passation d'un serveur Linux.
# 8 QCM + débogage d'un script fourni (3 étapes) + synthèse.
# Travaille DANS ~/oslabs/lab10/obj06 (script_debug.sh + fichiers de test fournis).
# =============================================================================
. "$(dirname "${BASH_SOURCE[0]}")/../lab10_lib.sh"

if [ "$(basename "$PWD")" != "obj06" ]; then
  echo "Ce script doit être lancé depuis ~/oslabs/lab10/obj06 :"
  echo "  cd ~/oslabs/lab10/obj06 && ./lab10_ex6.sh"
  exit 1
fi

BANNER="Avant de commencer : révise cm06.pdf. Aide : man bash. Lance ce script depuis ~/oslabs/lab10/obj06."

begin "report_lab10_ex6.txt" 11 "Objectif 6 — CM06 : programmation shell" "TP10" 1 "$BANNER"

title "Objectif 6 — CM06 : programmation shell"

# ===================================================================== QCM --
title "Partie A — Questions de cours (QCM)"

qstep
q_choice \
  "Que contient la première ligne #!/bin/bash d'un script ?" \
  "Un commentaire ignoré|Le shebang (interpréteur à utiliser)|Le nom du script|Une variable" \
  2 \
  "La ligne commence par #!." \
  "Elle indique le programme qui interprète le script." \
  "C'est le shebang."

qstep
q_choice \
  "Quelle différence entre ./script et source script ?" \
  "Les deux sont identiques|source crée un sous-processus|./script exécute dans le shell courant|source exécute dans le shell courant (variables persistantes)" \
  4 \
  "./ lance un nouveau processus ; source non." \
  "Les variables exportées persistent avec source." \
  "source agit sur le shell courant."

qstep
q_choice \
  "Que renvoie la variable \$? ?" \
  "Le code de sortie de la dernière commande|Le nombre d'arguments|Le nom du script|Le PID du shell" \
  1 \
  "C'est le statut de retour (0 = succès)." \
  "À tester après une commande." \
  "\$? = code de sortie."

qstep
q_choice \
  "Que contient \$# ?" \
  "Le premier argument|Le nom du script|Le nombre d'arguments positionnels|La liste des arguments" \
  3 \
  "C'est un compteur." \
  "\$# = nombre d'arguments." \
  "Utile pour valider le nombre d'arguments."

qstep
q_choice \
  "Quelle différence entre \$@ et \$* ?" \
  "Les deux sont identiques|\$@ = arguments séparés ; \$* = une seule chaîne|\$@ = code de retour|\$* = nombre d'arguments" \
  2 \
  "Le comportement diffère entre guillemets." \
  "\"$@\" préserve chaque argument séparé." \
  "\$@ séparés ; \$* une chaîne."

qstep
q_choice \
  "À quoi sert l'instruction case ?" \
  "Compter|Boucler|Déclarer une fonction|Brancher sur plusieurs cas (menu)" \
  4 \
  "Elle compare une valeur à plusieurs motifs." \
  "Chaque branche se termine par ;;." \
  "case = branchement multi-cas."

qstep
q_choice \
  "À quoi sert getopts ?" \
  "Analyser les options de la ligne de commande|Trier les fichiers|Lancer une commande|Compter les arguments" \
  1 \
  "Il lit des options comme -v, -a." \
  "Il s'utilise dans une boucle while." \
  "getopts = analyse des options."

qstep
q_choice \
  "Que fait bash -x script.sh ?" \
  "Vérifie la syntaxe|Exécute plus vite|Affiche une trace des commandes exécutées (débogage)|Supprime les erreurs" \
  3 \
  "C'est le mode trace." \
  "Chaque commande est affichée avant exécution." \
  "bash -x = débogage par trace."

# ============================================================ Mise en œuvre --
title "Partie B — Déboguer script_debug.sh (dans obj06/)"

step "Lis le script : \`less script_debug.sh\`."
q_fixed \
  "Quel interpréteur est déclaré dans le shebang ?" \
  "bash|/bin/bash" \
  "La première ligne commence par #!." \
  "C'est le shell bash." \
  "Réponds : bash"

step "Vérifie la syntaxe : \`bash -n script_debug.sh\` ; corrige les erreurs de syntaxe jusqu'à ce que la commande réussisse."
q_fs "bash -n script_debug.sh ne signale plus d'erreur de syntaxe" \
  'bash -n script_debug.sh 2>/dev/null' \
  "bash -n vérifie la syntaxe sans exécuter." \
  "Il y a des erreurs de syntaxe à corriger (if/case)." \
  "Relance bash -n après chaque correction." \
  "bash -n script_debug.sh"

step "Trace et exécute : \`bash -x script_debug.sh compte\` ; corrige les erreurs restantes, puis vérifie que \`bash script_debug.sh compte\` affiche 3."
q_fs "le script compte correctement 3 fichiers .txt" \
  '[ "$(bash script_debug.sh compte 2>/dev/null)" = "3" ]' \
  "bash -x montre chaque commande (repère l'affectation fautive)." \
  "Attention aux noms de fichiers contenant des espaces (quoting)." \
  "La sortie doit être exactement 3." \
  "bash script_debug.sh compte"

# ================================================================ Synthèse --
synthese \
  "Liste les erreurs du script et explique pourquoi chacune pose problème." \
  "Quelle est la différence entre ./script (sous-shell) et source script (shell courant) ?" \
  "Que fait \$? et comment l'utiliser pour gérer les erreurs d'un script ?" \
  "Quelle est la différence entre \$@ et \$* ?" \
  "Quand utiliser bash -n (syntaxe) puis bash -x (trace) pour déboguer ?"

finalize
