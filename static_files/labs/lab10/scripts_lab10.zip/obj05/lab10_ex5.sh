#!/usr/bin/env bash
# =============================================================================
# lab10_ex5.sh — Objectif 5 : CM05 — Outils de traitement de texte
# Préparation au CF — contexte : passation d'un serveur Linux.
# 8 QCM + 6 mises en œuvre (grep/sed/regex sur server.log) + synthèse.
# Travaille DANS ~/oslabs/lab10/obj05 (server.log fourni).
# =============================================================================
. "$(dirname "${BASH_SOURCE[0]}")/../lab10_lib.sh"

if [ "$(basename "$PWD")" != "obj05" ]; then
  echo "Ce script doit être lancé depuis ~/oslabs/lab10/obj05 :"
  echo "  cd ~/oslabs/lab10/obj05 && ./lab10_ex5.sh"
  exit 1
fi

BANNER="Avant de commencer : révise cm05.pdf. Aide : man grep / man sed. Lance ce script depuis ~/oslabs/lab10/obj05."

begin "report_lab10_ex5.txt" 14 "Objectif 5 — CM05 : outils de traitement de texte" "TP10" 1 "$BANNER"

title "Objectif 5 — CM05 : outils de traitement de texte"

# ===================================================================== QCM --
title "Partie A — Questions de cours (QCM)"

qstep
q_choice \
  "Que représente ^ dans une expression régulière ?" \
  "Fin de ligne|Début de ligne|N'importe quel caractère|Un ou plusieurs" \
  2 \
  "C'est une ancre." \
  "Elle marque le début de la ligne." \
  "^ = début de ligne."

qstep
q_choice \
  "Quelle est la différence entre * et + en regex (ERE) ?" \
  "* = 1 ou plusieurs, + = 0 ou plusieurs|Les deux sont identiques|* = 0 ou plusieurs ; + = 1 ou plusieurs|* = fin de ligne, + = début" \
  3 \
  "* peut être absent ; + exige au moins une occurrence." \
  "* = {0,} ; + = {1,}." \
  "* = 0+ ; + = 1+."

qstep
q_choice \
  "Que reconnaît [0-9] ?" \
  "Un chiffre de 0 à 9|Les caractères 0, - et 9|Un nombre entier|Un espace" \
  1 \
  "C'est une classe de caractères." \
  "[ ] définit un ensemble ; ici de 0 à 9." \
  "[0-9] = un chiffre."

qstep
q_choice \
  "Pour utiliser +, | ou () sans les échapper avec grep, il faut :" \
  "grep par défaut (BRE)|Rien, ils marchent toujours|grep -E (ERE)|grep -c" \
  3 \
  "BRE et ERE n'interprètent pas les mêmes métacaractères." \
  "-E active les expressions étendues (ERE)." \
  "grep -E = ERE."

qstep
q_choice \
  "Quelle expression reconnaît une adresse IPv4 (forme simplifiée) ?" \
  "[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}|[a-z]+|^[0-9]+$|.*" \
  1 \
  "Quatre nombres séparés par des points." \
  "[0-9]{1,3} = 1 à 3 chiffres ; \. = un point littéral." \
  "Le motif à quatre groupes de chiffres."

qstep
q_choice \
  "Que fait grep -c motif fichier ?" \
  "Affiche les lignes|Compte les lignes correspondantes|Inverse la sélection|Ignore la casse" \
  2 \
  "-c signifie count." \
  "Il affiche un nombre, pas les lignes." \
  "-c compte les lignes."

qstep
q_choice \
  "Que fait sed 's/a/b/g' fichier ?" \
  "Remplace toutes les occurrences de a par b|Remplace la première occurrence seulement|Supprime les lignes|Compte les a" \
  1 \
  "Le drapeau g = global." \
  "s/ancien/nouveau/ substitue." \
  "g remplace toutes les occurrences."

qstep
q_choice \
  "Que fait l'option grep -o ?" \
  "Inverse la sélection|Affiche uniquement la partie correspondante|Ignore la casse|Compte les lignes" \
  2 \
  "-o = only-matching." \
  "Utile pour extraire des IP, des nombres." \
  "-o n'affiche que ce qui correspond."

# ============================================================ Mise en œuvre --
title "Partie B — Mise en œuvre (dans obj05/)"

step "Compte les lignes contenant 404 : \`grep -c 404 server.log\`."
q_number \
  "Combien de lignes contiennent 404 ?" \
  "$(grep -c 404 server.log 2>/dev/null)" \
  "\`grep -c\` compte les lignes correspondantes." \
  "Le motif est 404." \
  "Lis la valeur affichée."

step "Compte les lignes contenant « error » sans tenir compte de la casse : \`grep -ci error server.log\`."
q_number \
  "Combien de lignes contiennent error (insensible à la casse) ?" \
  "$(grep -ci error server.log 2>/dev/null)" \
  "\`-i\` ignore la casse, \`-c\` compte." \
  "Cela inclut [ERROR], [error] et « error » dans le texte." \
  "Lis la valeur affichée."

step "Extrais les IPv4 et compte-les distinctes : \`grep -oE '([0-9]{1,3}\\.){3}[0-9]{1,3}' server.log | sort -u | wc -l\`."
q_number \
  "Combien d'adresses IPv4 distinctes ?" \
  "$(grep -oE '([0-9]{1,3}\.){3}[0-9]{1,3}' server.log 2>/dev/null | sort -u | wc -l)" \
  "\`-o\` extrait chaque IP ; \`-E\` active l'ERE." \
  "\`sort -u\` dédoublonne." \
  "\`... | sort -u | wc -l\` donne le nombre d'IP distinctes."

step "Remplace la date par DATE : \`sed 's/2026-10-17/DATE/g' server.log > norm.txt\`."
q_fs "norm.txt contient DATE et plus la date d'origine" \
  '[ -s norm.txt ] && grep -q DATE norm.txt && ! grep -q "2026-10-17" norm.txt' \
  "\`s/ancien/nouveau/g\` substitue globalement." \
  "Redirige avec \`> norm.txt\`." \
  "Vérifie : \`head norm.txt\`." \
  "sed 's/2026-10-17/DATE/g' server.log > norm.txt"

step "Trouve l'IP la plus fréquente : \`grep -oE '([0-9]{1,3}\\.){3}[0-9]{1,3}' server.log | sort | uniq -c | sort -nr | head -n 1\`."
q_number \
  "Combien de fois apparaît l'IP la plus fréquente ?" \
  "$(grep -oE '([0-9]{1,3}\.){3}[0-9]{1,3}' server.log 2>/dev/null | sort | uniq -c | sort -nr | head -n 1 | awk '{print $1}')" \
  "\`sort | uniq -c\` compte les occurrences (après tri)." \
  "\`sort -nr\` classe par compte décroissant." \
  "\`head -n 1\` garde la première ligne : son n° est le compte."

step "Sauvegarde ET affiche les lignes 404 avec tee : \`grep 404 server.log | tee resultats_404.txt | wc -l\`."
q_fs "resultats_404.txt contient 2 lignes" \
  '[ -f resultats_404.txt ] && [ "$(wc -l < resultats_404.txt)" -eq 2 ]' \
  "\`tee\` écrit dans le fichier ET transmet le flux à \`wc -l\`." \
  "Redirige la sortie de grep vers tee." \
  "Vérifie : \`wc -l resultats_404.txt\`." \
  "grep 404 server.log | tee resultats_404.txt | wc -l"

# ================================================================ Synthèse --
synthese \
  "Quel rôle jouent respectivement grep (filtrer) et sed (transformer) dans un pipeline ?" \
  "Quelle est la différence BRE/ERE (pourquoi -E) et pourquoi grep -o sert-il à extraire (IP, etc.) ?" \
  "Quelle différence entre grep -c, grep -i et grep -o (quand les utiliser) ?" \
  "Que fait sed 's/a/b/g' et que change l'option -i ?" \
  "Dans le pipeline « top IP », pourquoi trier, puis uniq -c, puis retrier (sort -nr) ?"

finalize
