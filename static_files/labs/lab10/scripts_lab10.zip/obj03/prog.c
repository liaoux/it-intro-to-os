/*
 * prog.c — Objectif 3 (CM03) : programme fourni COMPLET.
 * À lire et comprendre ; repérer les appels système POSIX (open, write, close)
 * et les fonctions de bibliothèque (strlen, perror), puis les chercher au manuel.
 *
 * But : ouvrir "sortie.txt" en écriture, y écrire une chaîne, puis fermer.
 */
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>

int main(void)
{
    int fd;
    ssize_t n;
    const char *msg = "Bonjour depuis les appels systeme\n";

    /* Appel système : ouvrir/créer le fichier en écriture. */
    fd = open("sortie.txt", O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (fd < 0) {
        perror("open");
        return 1;
    }

    /* Appel système : écrire la chaîne ; strlen est une fonction de bibliothèque. */
    n = write(fd, msg, strlen(msg));
    if (n < 0) {
        perror("write");
        close(fd);
        return 1;
    }

    /* Appel système : fermer le descripteur. */
    close(fd);
    return 0;
}
