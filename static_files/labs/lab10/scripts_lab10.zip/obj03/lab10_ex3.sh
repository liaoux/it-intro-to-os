#!/usr/bin/env bash
# =============================================================================
# lab10_ex3.sh — Objectif 3 : CM03 — Services et appels système
# Préparation au CF — contexte : passation d'un serveur Linux.
# prog.c fourni COMPLET : lecture (less), manuel (man 2), gcc, strace.
# 6 QCM + 6 mises en œuvre + synthèse.
# Travaille DANS ~/oslabs/lab10/obj03 (prog.c fourni).
# =============================================================================
. "$(dirname "${BASH_SOURCE[0]}")/../lab10_lib.sh"

if [ "$(basename "$PWD")" != "obj03" ]; then
  echo "Ce script doit être lancé depuis ~/oslabs/lab10/obj03 :"
  echo "  cd ~/oslabs/lab10/obj03 && ./lab10_ex3.sh"
  exit 1
fi

BANNER="Avant de commencer : révise cm03.pdf. Aide : man 2 / man 3. Lance ce script depuis ~/oslabs/lab10/obj03."

begin "report_lab10_ex3.txt" 12 "Objectif 3 — CM03 : services et appels système" "TP10" 1 "$BANNER"

title "Objectif 3 — CM03 : services et appels système"

# ===================================================================== QCM --
title "Partie A — Questions de cours (QCM)"

qstep
q_choice \
  "Qu'est-ce qu'un appel système ?" \
  "Une commande tapée dans le shell|L'interface par laquelle un programme utilisateur demande un service au noyau, via une instruction de trap|Une fonction exécutée uniquement en mode utilisateur|Un périphérique d'entrée/sortie" \
  2 \
  "C'est la frontière entre programme et noyau." \
  "Le programme demande un service, via un trap." \
  "C'est le point d'entrée contrôlé vers le noyau."

qstep
q_choice \
  "Quelle est la différence entre man 2 et man 3 ?" \
  "La section 2 décrit les commandes shell ; la 3 les appels système|Les sections 2 et 3 sont identiques|La section 2 décrit les fichiers de configuration|La section 2 décrit les appels système ; la section 3 les fonctions de bibliothèque" \
  4 \
  "Les appels système et les fonctions de bibliothèque sont documentés séparément." \
  "Section 2 = appels système." \
  "Section 3 = fonctions de bibliothèque (libc)."

qstep
q_choice \
  "Dans quelle catégorie POSIX classer open, read, write, close ?" \
  "Gestion des fichiers|Contrôle des processus|Communication|Protection" \
  1 \
  "Ces appels agissent sur des fichiers/descripteurs." \
  "Ils manipulent des objets de type fichier." \
  "C'est la gestion des fichiers."

qstep
q_choice \
  "Quelle est la différence entre strace et ltrace ?" \
  "strace trace les appels de bibliothèque ; ltrace les appels système|Les deux sont identiques|strace trace les appels système ; ltrace les appels de bibliothèque|ltrace trace uniquement les signaux" \
  3 \
  "L'un trace le noyau, l'autre la bibliothèque." \
  "strace a rapport aux appels système." \
  "strace = appels système ; ltrace = appels de bibliothèque."

qstep
q_choice \
  "À quoi sert gcc dans la chaîne source → exécutable ?" \
  "À exécuter le programme|À compiler et produire un exécutable (édition de liens incluse)|À éditer le code source|À tracer les appels système" \
  2 \
  "gcc transforme le source en exécutable." \
  "Il compile puis lie le programme." \
  "gcc compile et produit l'exécutable."

qstep
q_choice \
  "Quelle affirmation décrit un micro-noyau ?" \
  "Seuls les services essentiels sont dans le noyau, le reste en espace utilisateur|Tous les services s'exécutent dans un même espace noyau|Le noyau n'existe pas|Les services s'exécutent sur un serveur distant" \
  1 \
  "Micro = peu de services dans le noyau." \
  "Le reste tourne en espace utilisateur." \
  "Seuls les services essentiels sont dans le noyau."

# ============================================================ Mise en œuvre --
title "Partie B — Mise en œuvre (dans obj03/)"

step "Lis \`prog.c\` avec \`less\` (recherche : \`/open\`, \`/write\`, \`/close\` ; \`q\` pour quitter)."
q_choice \
  "Lesquelles de ces fonctions de prog.c sont des appels système ?" \
  "strlen et printf|open, write et close|perror et main|aucune" \
  2 \
  "Les appels système sont documentés à la section 2 du manuel." \
  "strlen est une fonction de bibliothèque (section 3)." \
  "open, write et close dialoguent avec le noyau."

step "Consulte le manuel : \`man 2 open\`."
q_man \
  "man 2 open" \
  "Que renvoie l'appel open en cas de succès ?" \
  "un descripteur de fichier|un descripteur|descripteur|descripteur de fichier" \
  "C'est un petit entier (souvent 3)." \
  "Ce descripteur sert ensuite à write/close." \
  "open renvoie un descripteur de fichier."

step "Consulte le manuel : \`man 2 write\`."
q_man \
  "man 2 write" \
  "Que renvoie l'appel write en cas de succès ?" \
  "le nombre d'octets écrits|nombre d'octets|le nombre d'octets|nombre d'octets ecrits" \
  "write renvoie une quantité d'octets." \
  "C'est le nombre d'octets effectivement écrits." \
  "write renvoie le nombre d'octets écrits."

step "Compile le programme : \`gcc -Wall -Wextra -o prog prog.c\`."
q_fs "l'exécutable prog existe" \
  '[ -x prog ]' \
  "gcc prend le source et produit un exécutable (-o prog)." \
  "Corrige les erreurs affichées (le fichier est fourni complet)." \
  "Vérifie : \`ls -l prog\`." \
  "gcc -Wall -Wextra -o prog prog.c"

step "Exécute le programme : \`./prog\`."
q_fs "sortie.txt contient le message écrit" \
  '[ -f sortie.txt ] && grep -q Bonjour sortie.txt' \
  "Le programme crée sortie.txt et y écrit la chaîne." \
  "Lance-le avec ./prog (préfixe ./)." \
  "Vérifie : \`cat sortie.txt\`." \
  "./prog"

step "Trace les appels système : \`strace -e openat,write,close -o trace.txt ./prog\`."
q_fs "la trace contient openat, write et close" \
  '[ -s trace.txt ] && grep -q openat trace.txt && grep -q write trace.txt && grep -q close trace.txt' \
  "strace trace les appels système du programme." \
  "-e filtre sur les appels voulus ; -o écrit dans un fichier." \
  "Vérifie : \`cat trace.txt\`." \
  "strace -e openat,write,close -o trace.txt ./prog"

# ================================================================ Synthèse --
synthese \
  "Décris le chemin complet d'un appel write() : programme C, libc, trap, noyau, disque." \
  "Pourquoi man 2 et man 3 ne documentent-ils pas la même chose ?" \
  "Que renvoie open en cas de succès, et à quoi sert ce retour ?" \
  "Que renvoie write en cas de succès, et pourquoi vérifier ce retour ?" \
  "Quel rôle joue la libc entre le programme et l'appel système ?"

finalize
