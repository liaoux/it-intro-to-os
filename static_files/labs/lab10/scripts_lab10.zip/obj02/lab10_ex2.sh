#!/usr/bin/env bash
# =============================================================================
# lab10_ex2.sh — Objectif 2 : CM02 — Commandes, redirections et pipelines
# Préparation au CF — contexte : passation d'un serveur Linux.
# Version allégée : 8 QCM + 7 mises en œuvre atomiques + synthèse.
# Travaille DANS ~/oslabs/lab10/obj02 (données déjà présentes).
# =============================================================================
. "$(dirname "${BASH_SOURCE[0]}")/../lab10_lib.sh"

if [ "$(basename "$PWD")" != "obj02" ]; then
  echo "Ce script doit être lancé depuis ~/oslabs/lab10/obj02 :"
  echo "  cd ~/oslabs/lab10/obj02 && ./lab10_ex2.sh"
  exit 1
fi

BANNER="Avant de commencer : révise cm02.pdf. Aide : man. Lance ce script depuis ~/oslabs/lab10/obj02."

begin "report_lab10_ex2.txt" 15 "Objectif 2 — CM02 : commandes, redirections et pipelines" "TP10" 1 "$BANNER"

title "Objectif 2 — CM02 : commandes, redirections et pipelines"

# ===================================================================== QCM --
title "Partie A — Questions de cours (QCM)"

qstep
q_choice \
  "Quelle affirmation distingue une commande interne (builtin) d'une commande externe ?" \
  "Une commande interne est un programme séparé trouvé dans le PATH ; une commande externe est intégrée au shell|Une commande interne est intégrée au shell (ex. cd) ; une commande externe est un programme sur disque trouvé via le PATH|Les deux sont toujours des programmes séparés|Une commande externe ne peut pas recevoir d'arguments" \
  2 \
  "\`cd\` doit modifier l'état du shell lui-même." \
  "Interne = builtin ; externe = programme sur disque (PATH)." \
  "Une commande externe est un fichier exécutable."

qstep
q_choice \
  "Quelle est la différence entre man et --help ?" \
  "man affiche une aide courte ; --help ouvre le manuel complet|man n'existe pas sous Linux|man affiche le manuel complet (pages) ; --help affiche un résumé rapide des options|Les deux sont strictement identiques" \
  3 \
  "L'un ouvre une page structurée, l'autre un résumé." \
  "man est structuré en sections." \
  "--help donne un résumé rapide ; man la page complète."

qstep
q_choice \
  "Quelle affirmation distingue cat et less ?" \
  "cat affiche tout le fichier d'un coup ; less permet de le parcourir page par page|cat pagine ; less affiche tout|cat supprime le fichier ; less le copie|cat et less sont identiques" \
  1 \
  "L'un affiche tout, l'autre permet de naviguer." \
  "less se quitte avec q." \
  "cat affiche tout ; less pagine."

qstep
q_choice \
  "Quelle commande crée un répertoire (et ses parents avec -p) ?" \
  "touch|rm|cd|mkdir" \
  4 \
  "touch crée un fichier, pas un répertoire." \
  "L'option -p crée les parents." \
  "mkdir crée un répertoire."

qstep
q_choice \
  "Que renvoie la commande wc -l fichier ?" \
  "Le nombre de mots|Le nombre de lignes|Le nombre d'octets|Le nom du fichier seulement" \
  2 \
  "-l signifie lines (lignes)." \
  "-w compte les mots, -c les octets." \
  "-l compte les lignes."

qstep
q_choice \
  "Pourquoi faut-il trier (sort) avant uniq ?" \
  "Parce que uniq trie automatiquement|Parce que sort supprime les doublons|Pour accélérer le pipe|Parce que uniq ne supprime que les doublons adjacents" \
  4 \
  "uniq compare des lignes voisines." \
  "Il faut regrouper les doublons (trier) d'abord." \
  "Sans tri, les doublons non adjacents restent."

qstep
q_choice \
  "Qui interprète le motif *.txt dans la commande ls *.txt ?" \
  "Le shell, avant de lancer la commande|La commande ls|Le noyau|Le système de fichiers" \
  1 \
  "Le motif est développé avant l'exécution." \
  "C'est le shell qui réalise le globbing." \
  "La commande reçoit la liste des fichiers, pas le motif."

qstep
q_choice \
  "Que fait la commande cmd > f 2>&1 ?" \
  "Redirige uniquement stdout vers f|Redirige uniquement stderr vers f|Envoie stdout ET stderr dans f|Crée un pipe entre cmd et f" \
  3 \
  "\`2>&1\` envoie stderr vers la sortie courante." \
  "La sortie courante est déjà redirigée vers f." \
  "stdout et stderr aboutissent dans f."

# ============================================================ Mise en œuvre --
title "Partie B — Mise en œuvre (dans obj02/)"

step "Crée un répertoire : \`mkdir -p atelier\`."
q_fs "atelier/ existe" \
  '[ -d atelier ]' \
  "\`mkdir\` crée un répertoire ; \`-p\` crée les parents." \
  "Le dossier doit être dans obj02/ : \`ls\`." \
  "Vérifie : \`[ -d atelier ]\`." \
  "mkdir -p atelier"

step "Crée un fichier vide : \`touch atelier/f1.txt\`."
q_fs "atelier/f1.txt existe" \
  '[ -f atelier/f1.txt ]' \
  "\`touch\` crée un fichier vide." \
  "Le chemin est atelier/f1.txt." \
  "Vérifie : \`ls atelier\`." \
  "touch atelier/f1.txt"

step "Copie le fichier : \`cp atelier/f1.txt atelier/f2.txt\`."
q_fs "atelier/f1.txt et atelier/f2.txt existent" \
  '[ -f atelier/f1.txt ] && [ -f atelier/f2.txt ]' \
  "\`cp source destination\` copie." \
  "La destination est atelier/f2.txt." \
  "Les deux fichiers doivent exister." \
  "cp atelier/f1.txt atelier/f2.txt"

step "Affiche les 2 premières lignes dans un fichier : \`head -n 2 comptes.txt > tete.txt\`."
q_fs "tete.txt contient 2 lignes" \
  '[ -f tete.txt ] && [ "$(wc -l < tete.txt)" -eq 2 ]' \
  "\`head -n\` affiche le début du fichier." \
  "Redirige avec \`> tete.txt\`." \
  "Vérifie : \`wc -l tete.txt\`." \
  "head -n 2 comptes.txt > tete.txt"

step "Extrais le premier champ : \`cut -d: -f1 comptes.txt > utilisateurs.txt\`."
q_fs "utilisateurs.txt contient 26 lignes" \
  '[ -f utilisateurs.txt ] && [ "$(wc -l < utilisateurs.txt)" -eq 26 ]' \
  "\`-d:\` fixe le séparateur, \`-f1\` le premier champ." \
  "Redirige avec \`> utilisateurs.txt\`." \
  "Vérifie : \`wc -l utilisateurs.txt\`." \
  "cut -d: -f1 comptes.txt > utilisateurs.txt"

step "Sépare stdout et stderr : \`ls comptes.txt inexistant > out.txt 2> err.txt\`."
q_fs "out.txt contient comptes.txt et err.txt n'est pas vide" \
  '[ -s out.txt ] && [ -s err.txt ] && case "$(cat out.txt)" in *comptes.txt*) true;; *) false;; esac' \
  "\`>\` capture la sortie standard, \`2>\` la sortie d'erreur." \
  "comptes.txt existe, inexistant non." \
  "out.txt reçoit comptes.txt, err.txt reçoit l'erreur." \
  "ls comptes.txt inexistant > out.txt 2> err.txt"

step "Pipeline : \`cat comptes.txt | cut -d: -f7 | sort | uniq -c | sort -nr\`."
q_number \
  "Combien de shells distincts le fichier contient-il ?" \
  "$(cut -d: -f7 comptes.txt 2>/dev/null | sort -u | wc -l)" \
  "\`cut -f7\` extrait le champ du shell." \
  "\`sort -u\` (ou \`sort | uniq\`) dédoublonne." \
  "\`... | sort -u | wc -l\` donne le nombre de shells distincts."

# ================================================================ Synthèse --
synthese \
  "Pourquoi \`cmd > f 2>&1\` et \`cmd 2>&1 > f\` ne donnent-ils pas le même résultat ?" \
  "Pourquoi faut-il trier (sort) avant uniq ?" \
  "Quelle est la différence entre un pipe et une redirection (flux vs fichier) ?" \
  "Que fait tee et quand est-il utile dans un pipeline ?" \
  "Quelle différence entre \`wc -l < f\` et \`wc -l f\` ?"

finalize
