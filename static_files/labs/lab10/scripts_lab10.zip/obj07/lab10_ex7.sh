#!/usr/bin/env bash
# =============================================================================
# lab10_ex7.sh — Objectif 7 : CM07 — Système de fichiers
# Préparation au CF — contexte : passation d'un serveur Linux.
# Structure entrelacée : mise en œuvre puis questions, par thème.
#   3 QCM généraux · Liens (3 IMPL + 3 QCM) · Cachés (1 IMPL + 1 QCM)
#   · dd (2 IMPL + 2 QCM) · synthèse.
# Travaille DANS ~/oslabs/lab10/obj07 (evidence.txt, badges.txt fournis).
# =============================================================================
. "$(dirname "${BASH_SOURCE[0]}")/../lab10_lib.sh"

if [ "$(basename "$PWD")" != "obj07" ]; then
  echo "Ce script doit être lancé depuis ~/oslabs/lab10/obj07 :"
  echo "  cd ~/oslabs/lab10/obj07 && ./lab10_ex7.sh"
  exit 1
fi

BANNER="Avant de commencer : révise cm07.pdf. Aide : man ls / man ln / man dd. Lance ce script depuis ~/oslabs/lab10/obj07."

begin "report_lab10_ex7.txt" 15 "Objectif 7 — CM07 : système de fichiers" "TP10" 1 "$BANNER"

title "Objectif 7 — CM07 : système de fichiers"

# ================================================== Partie A — QCM généraux --
title "Partie A — Questions générales"

qstep
q_choice \
  "Que montre ls -l ?" \
  "Le contenu du fichier|Les attributs (type, permissions, liens, taille, dates)|Les inodes des voisins|Les blocs libres" \
  2 \
  "ls -l donne une ligne détaillée par fichier." \
  "On y voit type, droits, liens, taille, dates." \
  "ls -l affiche les attributs."

qstep
q_choice \
  "À quoi sert le superbloc d'un système de fichiers ?" \
  "Décrire globalement le système de fichiers (métadonnées)|Stocker le contenu d'un fichier|Gérer les permissions|Compter les processus" \
  1 \
  "C'est une structure globale." \
  "Il contient les infos du FS (taille, blocs libres...)." \
  "Le superbloc décrit le FS."

qstep
q_choice \
  "Quelle méthode d'allocation souffre de la fragmentation externe ?" \
  "Indexée|Chaînée|Contiguë|Aucune" \
  3 \
  "La fragmentation externe = trous entre blocs alloués." \
  "L'allocation contiguë réserve des blocs adjacents." \
  "C'est l'allocation contiguë."

# ==================================================== Bloc 1 — Liens -------
title "Bloc 1 — Liens physiques et symboliques (mise en œuvre)"

step "Crée un lien physique : \`ln evidence.txt copie_dure.txt\`."
q_fs "copie_dure.txt partage le même inode que evidence.txt" \
  '[ "$(ls -i evidence.txt | cut -d" " -f1)" = "$(ls -i copie_dure.txt | cut -d" " -f1)" ]' \
  "\`ln source dest\` crée un lien physique (même inode)." \
  "Vérifie avec \`ls -i evidence.txt copie_dure.txt\`." \
  "Les deux doivent afficher le même numéro d'inode." \
  "ln evidence.txt copie_dure.txt"

step "Crée un lien symbolique : \`ln -s evidence.txt copie_sym.txt\`."
q_fs "copie_sym.txt est un lien symbolique avec un inode différent" \
  '[ -L copie_sym.txt ] && [ "$(ls -i evidence.txt | cut -d" " -f1)" != "$(ls -i copie_sym.txt | cut -d" " -f1)" ]' \
  "\`ln -s\` crée un lien symbolique (inode propre)." \
  "Vérifie : \`ls -l copie_sym.txt\` montre une flèche ->." \
  "Son inode diffère de celui de la cible." \
  "ln -s evidence.txt copie_sym.txt"

step "Supprime l'original : \`rm evidence.txt\`."
q_fs "copie_dure.txt survit et copie_sym.txt est cassé" \
  '[ -f copie_dure.txt ] && [ -L copie_sym.txt ] && [ ! -e copie_sym.txt ]' \
  "Le lien physique garde les données (même inode)." \
  "Le lien symbolique pointe vers un nom supprimé." \
  "Vérifie : \`ls -l copie_dure.txt copie_sym.txt\`." \
  "rm evidence.txt"

title "Bloc 1 — Questions sur les liens"

qstep
q_choice \
  "Après rm de l'original, que devient un lien physique ?" \
  "Il devient cassé|Il est supprimé|Il change d'inode|Le fichier survit (même inode, compteur)" \
  4 \
  "Le lien physique pointe le même inode." \
  "Tant que le compteur de liens > 0, les données restent." \
  "Le fichier survit via le lien physique."

qstep
q_choice \
  "Après suppression de la cible, un lien symbolique devient :" \
  "Cassé (dangling)|Un lien physique|Supprimé|Toujours valide" \
  1 \
  "Le symlink contient un chemin." \
  "Si la cible n'existe plus, le chemin est invalide." \
  "Il devient cassé."

qstep
q_choice \
  "Où est stocké le nom d'un fichier ?" \
  "Dans l'inode|Dans le répertoire (entrée nom vers inode)|Dans le superbloc|Au début du contenu" \
  2 \
  "L'inode ne contient pas le nom." \
  "Le répertoire associe un nom à un inode." \
  "Le nom vit dans le répertoire."

# ==================================================== Bloc 2 — Cachés -----
title "Bloc 2 — ls -la et fichiers cachés (mise en œuvre)"

step "Crée un fichier caché : \`touch .cache.txt\`, puis compare \`ls -a\` et \`ls\`."
q_fs ".cache.txt apparaît avec ls -a mais pas avec ls" \
  '[ -f .cache.txt ] && ls -a | grep -q "cache.txt" && ! ls | grep -q "cache.txt"' \
  "Un fichier caché commence par un point." \
  "\`ls -a\` affiche aussi les fichiers cachés." \
  "Vérifie : \`ls -a | head\`." \
  "touch .cache.txt"

title "Bloc 2 — Question sur les fichiers cachés"

qstep
q_choice \
  "Quelle différence entre ls et ls -a ?" \
  "Identiques|ls -a trie|ls -a affiche aussi les fichiers cachés (commençant par .)|ls affiche les inodes" \
  3 \
  "-a = all." \
  "Les fichiers cachés commencent par un point." \
  "ls -a montre les cachés."

# ==================================================== Bloc 3 — dd ----------
title "Bloc 3 — Accès direct avec dd (mise en œuvre)"

step "Lis l'enregistrement d'indice 1 : \`dd if=badges.txt bs=8 skip=1 count=1 2>/dev/null\`."
q_fixed \
  "Quel enregistrement est lu (bs=8 skip=1 count=1) ?" \
  "bdg-027" \
  "Chaque enregistrement fait 8 octets." \
  "\`skip=1\` saute le 1er bloc, \`count=1\` en lit un." \
  "Réponds : bdg-027"

step "Écris XXXXXXX à l'indice 2 sans tronquer : \`printf 'XXXXXXX\n' | dd of=badges.txt bs=8 seek=2 conv=notrunc 2>/dev/null\`."
q_fs "badges.txt fait toujours 40 octets et l'enregistrement 2 vaut XXXXXXX" \
  '[ "$(wc -c < badges.txt)" -eq 40 ] && dd if=badges.txt bs=8 skip=2 count=1 2>/dev/null | grep -q "XXXXXXX"' \
  "\`seek=2\` positionne l'écriture au 3e bloc." \
  "\`conv=notrunc\` évite de tronquer la suite du fichier." \
  "La taille doit rester 40 octets." \
  "printf 'XXXXXXX\\n' | dd of=badges.txt bs=8 seek=2 conv=notrunc"

title "Bloc 3 — Questions sur l'accès direct"

qstep
q_choice \
  "Qu'est-ce que l'accès direct (par rapport au séquentiel) ?" \
  "Lire tout le fichier depuis le début|Écrire à la fin du fichier|Supprimer un bloc|Sauter directement à un bloc sans lire les précédents" \
  4 \
  "L'accès direct va droit au bloc voulu." \
  "dd skip/count et lseek permettent ce saut." \
  "On saute au bloc sans tout lire."

qstep
q_choice \
  "Dans dd en écriture, à quoi servent seek et conv=notrunc ?" \
  "seek fixe la position ; conv=notrunc évite de tronquer la suite|seek tronque ; notrunc lit|Les deux comptent les blocs|seek supprime le fichier" \
  1 \
  "seek= place la sortie à un bloc donné." \
  "Sans notrunc, le fichier serait tronqué à cette position." \
  "seek positionne, notrunc préserve la suite."

# ================================================================ Synthèse --
synthese \
  "Pourquoi rm d'un nom ne supprime-t-il pas forcément la donnée (inode + compteur de liens) ?" \
  "Quelle est la différence entre accès séquentiel et accès direct (dd skip/count, lseek) ?" \
  "Lien physique vs symbolique : nom, inode, franchissement de systèmes de fichiers ?" \
  "Quelle différence entre ls et ls -a (fichiers cachés) ?" \
  "Allocation contiguë vs indexée : fragmentation externe et accès direct ?"

finalize
