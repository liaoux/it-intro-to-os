#!/usr/bin/env bash
# =============================================================================
# lab10_ex4.sh — Objectif 4 : CM04 — Processus et ordonnancement
# Préparation au CF — contexte : passation d'un serveur Linux.
# 8 QCM + simulateur d'ordonnancement (5 étapes, 5 processus) + 1 QCM finale + synthèse.
# Travaille DANS ~/oslabs/lab10/obj04 (sched_sim.c fourni).
# =============================================================================
. "$(dirname "${BASH_SOURCE[0]}")/../lab10_lib.sh"

if [ "$(basename "$PWD")" != "obj04" ]; then
  echo "Ce script doit être lancé depuis ~/oslabs/lab10/obj04 :"
  echo "  cd ~/oslabs/lab10/obj04 && ./lab10_ex4.sh"
  exit 1
fi

BANNER="Avant de commencer : révise cm04.pdf. Aide : man. Lance ce script depuis ~/oslabs/lab10/obj04."

begin "report_lab10_ex4.txt" 14 "Objectif 4 — CM04 : processus et ordonnancement" "TP10" 1 "$BANNER"

title "Objectif 4 — CM04 : processus et ordonnancement"

# ===================================================================== QCM --
title "Partie A — Questions de cours (QCM)"

qstep
q_choice \
  "Quelle affirmation distingue un programme d'un processus ?" \
  "Un programme est une exécution ; un processus est un fichier|Un programme est un fichier sur disque ; un processus est ce programme en cours d'exécution|Les deux sont identiques|Un processus est toujours en mode noyau" \
  2 \
  "Le programme est stocké sur disque." \
  "Le processus est le programme en cours d'exécution." \
  "Fichier (programme) vs exécution (processus)."

qstep
q_choice \
  "Que contient le PCB (bloc de contrôle de processus) ?" \
  "Le code source du programme|Le contenu du disque|Les fichiers ouverts du système entier|Les informations d'un processus (état, registres, PID…)" \
  4 \
  "C'est la fiche d'identité du processus." \
  "Il contient état, registres, PID, etc." \
  "Le PCB décrit un processus."

qstep
q_choice \
  "Que fait l'appel fork() ?" \
  "Il crée un processus enfant (copie du processus appelant)|Il termine le processus|Il remplace l'image du processus|Il attend un enfant" \
  1 \
  "fork crée un nouveau processus." \
  "L'enfant est une copie du père." \
  "fork() crée un enfant."

qstep
q_choice \
  "Que fait wait() dans le processus père ?" \
  "Il crée un enfant|Il remplace le programme|Il attend la fin d'un enfant et récupère son code de sortie|Il tue l'enfant" \
  3 \
  "Le père attend la fin de l'enfant." \
  "Il récupère le code de sortie." \
  "wait() attend et récupère le code."

qstep
q_choice \
  "Qu'est-ce qu'un processus zombie ?" \
  "Un processus qui consomme beaucoup de CPU|Un processus terminé mais pas encore récupéré par son père (wait)|Un processus sans père|Un processus en mode noyau" \
  2 \
  "Il est terminé mais non récolté." \
  "Le père doit appeler wait." \
  "Zombie = terminé, non récupéré."

qstep
q_choice \
  "Quelle affirmation sur SIGKILL est correcte ?" \
  "Il peut être intercepté par le processus|Il est identique à SIGTERM|Il suspend le processus|Il ne peut pas être intercepté (arrêt forcé)" \
  4 \
  "SIGTERM peut être intercepté, SIGKILL non." \
  "SIGKILL est l'arrêt forcé." \
  "SIGKILL ne peut pas être intercepté."

qstep
q_choice \
  "Quel algorithme minimise le temps d'attente moyen (pour un ensemble donné) ?" \
  "SJF (Shortest Job First)|FCFS|Round-Robin|Priorité" \
  1 \
  "Le plus court d'abord." \
  "SJF est optimal pour l'attente moyenne." \
  "SJF minimise le temps d'attente moyen."

qstep
q_choice \
  "Dans Round-Robin, le quantum sert à :" \
  "fixer la priorité|définir la durée maximale d'exécution avant préemption|choisir le prochain processus au hasard|supprimer les interruptions" \
  2 \
  "Chaque processus reçoit une tranche de temps." \
  "Au-delà du quantum, on préempte." \
  "Le quantum borne la tranche d'exécution."

# ============================================================ Mise en œuvre --
title "Partie B — Simulateur d'ordonnancement (5 processus, dans obj04/)"

step "Compile le simulateur : \`gcc -Wall -Wextra -o sched_sim sched_sim.c\`."
q_fs "l'exécutable sched_sim existe" \
  '[ -x sched_sim ]' \
  "gcc produit un exécutable (-o sched_sim)." \
  "Corrige les erreurs de compilation si besoin." \
  "Vérifie : \`ls -l sched_sim\`." \
  "gcc -Wall -Wextra -o sched_sim sched_sim.c"

step "Lance \`./sched_sim\` et ajoute 5 processus : \`add P1 0 5\`, \`add P2 1 3\`, \`add P3 2 1\`, \`add P4 3 4\`, \`add P5 4 2\`, puis \`run fcfs\`. Lis la colonne Attente."
q_number \
  "Temps d'attente de P5 en FCFS ?" \
  "9" \
  "FCFS sert dans l'ordre d'arrivée : P1, P2, P3, P4, P5." \
  "P5 arrive à 4, dure 2, finit à 15." \
  "Attente = 15 - 4 - 2."

step "Toujours dans le simulateur : \`run sjf\`. Lis la colonne Attente."
q_number \
  "Temps d'attente de P2 en SJF (non préemptif) ?" \
  "7" \
  "Après P1, SJF prend les plus courts : P3 (1), P5 (2), puis P2 (3), P4 (4)." \
  "P2 finit à 11, arrive à 1, dure 3." \
  "Attente = 11 - 1 - 3."

step "Puis : \`run rr 2\` (quantum 2). Lis la colonne Attente."
q_number \
  "Temps d'attente de P3 en Round-Robin (quantum 2) ?" \
  "2" \
  "Chaque processus reçoit des tranches de 2." \
  "P3 (durée 1) finit vite, à t=5." \
  "Attente = 5 - 2 - 1."

step "Priorité : \`reset\`, puis \`add P1 0 5 3\`, \`add P2 1 3 1\`, \`add P3 2 1 4\`, \`add P4 3 4 2\`, \`add P5 4 2 5\`, puis \`run prio\` (petit nombre = prioritaire). Lis Attente de P3."
q_number \
  "Temps d'attente de P3 en priorité préemptive ?" \
  "10" \
  "P2 (prio 1) passe d'abord, puis P4 (prio 2), puis P1 (prio 3)." \
  "P3 (prio 4) ne passe qu'après, à t=12." \
  "Attente = 13 - 2 - 1."

# ============================================================ QCM finale --
title "Pour finir — priorité sous Linux"

qstep
q_choice \
  "En Linux, quelle est la différence entre nice et renice ?" \
  "nice modifie un processus en cours ; renice en lance un nouveau|nice fixe la priorité au lancement d'un programme ; renice modifie la priorité d'un processus déjà en cours|Les deux sont identiques|renice supprime un processus" \
  2 \
  "L'un s'applique au lancement, l'autre à un processus existant." \
  "nice au démarrage, renice ensuite." \
  "Une valeur nice plus petite = priorité plus élevée."

# ================================================================ Synthèse --
synthese \
  "Pourquoi SJF minimise-t-il l'attente moyenne mais est-il difficile à implémenter (effet de convoi de FCFS) ?" \
  "Pourquoi Round-Robin convient-il à un système interactif (rôle du quantum) ?" \
  "Quelle est la différence entre un programme et un processus, et quel est le rôle du PCB ?" \
  "Qu'est-ce qu'un zombie, un orphelin, et quel rôle joue wait dans leur gestion ?" \
  "Quelle est la différence entre un algorithme préemptif et non préemptif ?"

finalize
