/*
 * sched_sim — simulateur pédagogique d'ordonnancement (Objectif 4 — CM04).
 *
 * Algorithmes : FCFS, SJF (non préemptif), Round-Robin (quantum), Priorité (préemptive).
 * Convention priorité : un NOMBRE PLUS PETIT = PRIORITÉ PLUS ÉLEVÉE (comme nice).
 *
 * Après chaque run : Gantt HORIZONTAL + tableau des métriques + explication du calcul.
 *
 * Commandes :
 *   add <nom> <arrivee> <duree> [prio]
 *   run fcfs | sjf | prio
 *   run rr <quantum>
 *   show | reset | help | quit
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAXP 16
#define MAXT 4096

typedef struct {
    char name[32];
    int arr;
    int burst;
    int prio;
} Proc;

static Proc procs[MAXP];
static int np = 0;
static int runner[MAXT];

static void usage(void)
{
    printf("Commandes :\n");
    printf("  add <nom> <arrivee> <duree> [priorite]  (petit nombre = prioritaire)\n");
    printf("  run fcfs | sjf | prio\n");
    printf("  run rr <quantum>\n");
    printf("  show | reset | help | quit\n");
}

static void show(void)
{
    int i;
    if (np == 0) {
        printf("Aucun processus. Utilise add.\n");
        return;
    }
    printf("%-10s %8s %8s %8s\n", "Nom", "Arrivee", "Duree", "Prio");
    for (i = 0; i < np; i++) {
        printf("%-10s %8d %8d %8d\n", procs[i].name, procs[i].arr,
               procs[i].burst, procs[i].prio);
    }
}

static void add_proc(const char *name, int arr, int burst, int prio)
{
    if (np >= MAXP) {
        printf("Trop de processus (max %d).\n", MAXP);
        return;
    }
    strncpy(procs[np].name, name, 31);
    procs[np].name[31] = '\0';
    procs[np].arr = arr;
    procs[np].burst = burst;
    procs[np].prio = prio;
    np++;
    printf("ajoute %s : arrivee=%d, duree=%d, prio=%d\n", name, arr, burst, prio);
}

static void clear_runner(void)
{
    int i;
    for (i = 0; i < MAXT; i++) {
        runner[i] = -1;
    }
}

static const char *algo_note(const char *algo)
{
    if (strcmp(algo, "fcfs") == 0) {
        return "ordre d'arrivee, non preemptif : chacun s'execute jusqu'au bout.";
    }
    if (strcmp(algo, "sjf") == 0) {
        return "non preemptif : a chaque liberation du CPU, on prend le processus arrive de plus courte duree.";
    }
    if (strcmp(algo, "rr") == 0) {
        return "chaque processus recoit une tranche de quantum ; s'il n'a pas fini, il retourne en fin de file.";
    }
    return "preemptif : a chaque instant, le processus pret de plus petite priorite s'execute.";
}

static void print_gantt(int total)
{
    int t;
    printf("\nGantt (horizontal) :\n");
    printf("      ");
    for (t = 0; t <= total; t++) {
        printf("%-4d", t);
    }
    printf("\n      ");
    for (t = 0; t < total; t++) {
        printf("+---");
    }
    printf("+\n      ");
    for (t = 0; t < total; t++) {
        int r = runner[t];
        if (r < 0) {
            printf("|   ");
        } else {
            printf("|%-3.3s", procs[r].name);
        }
    }
    printf("|\n      ");
    for (t = 0; t < total; t++) {
        printf("+---");
    }
    printf("+\n");
}

static void print_results(const int *completion, int total, const char *algo)
{
    int i;
    int waits[MAXP];
    int turns[MAXP];
    double wa = 0.0, ta = 0.0;

    print_gantt(total);

    printf("\n%-10s %8s %8s %8s %8s %8s\n", "Processus", "Arrivee", "Duree",
           "Fin", "Attente", "Sejour");
    for (i = 0; i < np; i++) {
        int fin = completion[i];
        turns[i] = fin - procs[i].arr;
        waits[i] = turns[i] - procs[i].burst;
        printf("%-10s %8d %8d %8d %8d %8d\n", procs[i].name, procs[i].arr,
               procs[i].burst, fin, waits[i], turns[i]);
        wa += waits[i];
        ta += turns[i];
    }
    printf("\nAttente moyenne : %.2f   Sejour moyen : %.2f\n", wa / np, ta / np);

    /* Explication du calcul */
    printf("\n--- Comment lit-on ces chiffres ? ---\n");
    printf("Formules : Sejour = Fin - Arrivee ; Attente = Sejour - Duree\n");
    for (i = 0; i < np; i++) {
        printf("  %s : Sejour = %d - %d = %d ; Attente = %d - %d = %d\n",
               procs[i].name, completion[i], procs[i].arr, turns[i],
               turns[i], procs[i].burst, waits[i]);
    }
    printf("Moyennes :\n  Attente = (");
    for (i = 0; i < np; i++) {
        printf("%d%s", waits[i], (i < np - 1) ? "+" : "");
    }
    printf(")/%d = %.2f\n  Sejour  = (", np, wa / np);
    for (i = 0; i < np; i++) {
        printf("%d%s", turns[i], (i < np - 1) ? "+" : "");
    }
    printf(")/%d = %.2f\n", np, ta / np);
    printf("Algorithme (%s) : %s\n", algo, algo_note(algo));
}

static void run_fcfs(void)
{
    int idx[MAXP];
    int completion[MAXP];
    int i, j, t = 0;

    for (i = 0; i < np; i++) {
        idx[i] = i;
    }
    for (i = 1; i < np; i++) {
        int k = idx[i];
        j = i - 1;
        while (j >= 0 && procs[idx[j]].arr > procs[k].arr) {
            idx[j + 1] = idx[j];
            j--;
        }
        idx[j + 1] = k;
    }
    clear_runner();
    for (i = 0; i < np; i++) {
        int p = idx[i];
        int k;
        if (t < procs[p].arr) {
            t = procs[p].arr;
        }
        for (k = 0; k < procs[p].burst; k++) {
            runner[t] = p;
            t++;
        }
        completion[p] = t;
    }
    print_results(completion, t, "fcfs");
}

static void run_sjf(void)
{
    int rem[MAXP];
    int completion[MAXP];
    int done = 0, t = 0, i;

    for (i = 0; i < np; i++) {
        rem[i] = procs[i].burst;
        completion[i] = -1;
    }
    clear_runner();
    while (done < np) {
        int pick = -1;
        for (i = 0; i < np; i++) {
            if (procs[i].arr <= t && rem[i] > 0) {
                if (pick < 0 || rem[i] < rem[pick] ||
                    (rem[i] == rem[pick] && procs[i].arr < procs[pick].arr)) {
                    pick = i;
                }
            }
        }
        if (pick < 0) {
            t++;
            continue;
        }
        {
            int k;
            for (k = 0; k < rem[pick]; k++) {
                runner[t] = pick;
                t++;
            }
        }
        rem[pick] = 0;
        completion[pick] = t;
        done++;
    }
    print_results(completion, t, "sjf");
}

static void run_rr(int q)
{
    int rem[MAXP];
    int completion[MAXP];
    int enq[MAXP];
    int queue[MAXT];
    int qh = 0, qt = 0;
    int cur = -1, slice = 0, t = 0, finished = 0, i;

    for (i = 0; i < np; i++) {
        rem[i] = procs[i].burst;
        completion[i] = -1;
        enq[i] = 0;
    }
    clear_runner();
    for (i = 0; i < np; i++) {
        if (procs[i].arr == 0) {
            queue[qt++] = i;
            enq[i] = 1;
        }
    }
    while (finished < np) {
        if (cur < 0) {
            if (qh < qt) {
                cur = queue[qh++];
                slice = q;
            } else {
                int na = -1;
                for (i = 0; i < np; i++) {
                    if (!enq[i] && (na < 0 || procs[i].arr < na)) {
                        na = procs[i].arr;
                    }
                }
                if (na < 0) {
                    break;
                }
                t = na;
                for (i = 0; i < np; i++) {
                    if (!enq[i] && procs[i].arr == t) {
                        queue[qt++] = i;
                        enq[i] = 1;
                    }
                }
                continue;
            }
        }
        runner[t] = cur;
        rem[cur]--;
        t++;
        slice--;
        for (i = 0; i < np; i++) {
            if (!enq[i] && procs[i].arr == t) {
                queue[qt++] = i;
                enq[i] = 1;
            }
        }
        if (rem[cur] == 0) {
            completion[cur] = t;
            cur = -1;
            finished++;
        } else if (slice == 0) {
            queue[qt++] = cur;
            cur = -1;
        }
    }
    print_results(completion, t, "rr");
}

static void run_prio(void)
{
    int rem[MAXP];
    int completion[MAXP];
    int done = 0, t = 0, i;

    for (i = 0; i < np; i++) {
        rem[i] = procs[i].burst;
        completion[i] = -1;
    }
    clear_runner();
    while (done < np) {
        int pick = -1;
        for (i = 0; i < np; i++) {
            if (procs[i].arr <= t && rem[i] > 0) {
                if (pick < 0 || procs[i].prio < procs[pick].prio ||
                    (procs[i].prio == procs[pick].prio &&
                     procs[i].arr < procs[pick].arr)) {
                    pick = i;
                }
            }
        }
        if (pick < 0) {
            t++;
            continue;
        }
        runner[t] = pick;
        rem[pick]--;
        t++;
        if (rem[pick] == 0) {
            completion[pick] = t;
            done++;
        }
    }
    print_results(completion, t, "prio");
}

int main(void)
{
    char line[256];
    char cmd[32];

    printf("Simulateur d'ordonnancement (petit nombre = prioritaire)\n");
    printf("Tapez help pour les commandes.\n");

    for (;;) {
        printf("sched> ");
        fflush(stdout);
        if (!fgets(line, sizeof(line), stdin)) {
            printf("\n");
            break;
        }
        if (sscanf(line, "%31s", cmd) != 1) {
            continue;
        }
        if (strcmp(cmd, "quit") == 0 || strcmp(cmd, "exit") == 0) {
            break;
        } else if (strcmp(cmd, "help") == 0) {
            usage();
        } else if (strcmp(cmd, "reset") == 0) {
            np = 0;
            printf("Reinitialise.\n");
        } else if (strcmp(cmd, "show") == 0) {
            show();
        } else if (strcmp(cmd, "add") == 0) {
            char name[32];
            int arr, burst, prio;
            int nf = sscanf(line, "%31s %31s %d %d %d", cmd, name, &arr, &burst, &prio);
            if (nf == 5) {
                add_proc(name, arr, burst, prio);
            } else if (nf == 4) {
                add_proc(name, arr, burst, 0);
            } else {
                printf("Usage : add <nom> <arrivee> <duree> [priorite]\n");
            }
        } else if (strcmp(cmd, "run") == 0) {
            char algo[32];
            int q;
            int nf = sscanf(line, "%31s %31s %d", cmd, algo, &q);
            if (nf < 2) {
                printf("Usage : run fcfs|sjf|prio | run rr <quantum>\n");
            } else if (np == 0) {
                printf("Aucun processus. Utilise add.\n");
            } else if (strcmp(algo, "fcfs") == 0) {
                run_fcfs();
            } else if (strcmp(algo, "sjf") == 0) {
                run_sjf();
            } else if (strcmp(algo, "prio") == 0) {
                run_prio();
            } else if (strcmp(algo, "rr") == 0) {
                if (nf < 3 || q <= 0) {
                    printf("Usage : run rr <quantum>\n");
                } else {
                    run_rr(q);
                }
            } else {
                printf("Algorithme inconnu : %s\n", algo);
            }
        } else {
            printf("Commande inconnue : %s. Tapez help.\n", cmd);
        }
    }
    return 0;
}
