#!/usr/bin/env bash
# =============================================================================
# lab10_ex8.sh — Objectif 8 : CM08 — Sécurité, utilisateurs et permissions
# Préparation au CF — contexte : passation d'un serveur Linux.
# Focus : conversion symbolique <-> octal et umask.
# 8 QCM + 4 calculs + 4 mises en œuvre + synthèse.
# Travaille DANS ~/oslabs/lab10/obj08.
# =============================================================================
. "$(dirname "${BASH_SOURCE[0]}")/../lab10_lib.sh"

if [ "$(basename "$PWD")" != "obj08" ]; then
  echo "Ce script doit être lancé depuis ~/oslabs/lab10/obj08 :"
  echo "  cd ~/oslabs/lab10/obj08 && ./lab10_ex8.sh"
  exit 1
fi

BANNER="Avant de commencer : révise cm08.pdf. Aide : man chmod / man umask. Lance ce script depuis ~/oslabs/lab10/obj08."

begin "report_lab10_ex8.txt" 16 "Objectif 8 — CM08 : permissions et umask" "TP10" 1 "$BANNER"

title "Objectif 8 — CM08 : permissions et umask"

# ===================================================================== QCM --
title "Partie A — Questions de cours (QCM)"

qstep
q_choice \
  "Quelle est la valeur octale de r, w, x ?" \
  "r=2, w=4, x=1|r=4, w=2, x=1|r=1, w=2, x=4|r=4, w=1, x=2" \
  2 \
  "r = read, w = write, x = execute." \
  "Les valeurs sont 4, 2, 1." \
  "r=4, w=2, x=1."

qstep
q_choice \
  "Sur un répertoire, le droit x permet :" \
  "de lire la liste des fichiers|de créer des fichiers|de supprimer des fichiers|de traverser le répertoire (y entrer / accéder aux entrées)" \
  4 \
  "x = execute/traverse." \
  "Sans x, on ne peut pas entrer dans le dossier." \
  "x sur un répertoire = le traverser."

qstep
q_choice \
  "Où est stocké le hash du mot de passe ?" \
  "Dans /etc/shadow|Dans /etc/passwd|Dans /etc/group|Dans /etc/hosts" \
  1 \
  "Le fichier lisible par tous ne peut pas contenir le hash." \
  "/etc/passwd contient un renvoi (x)." \
  "C'est /etc/shadow."

qstep
q_choice \
  "À quel mode octal correspond chmod u=rw,g=r,o= ?" \
  "750|644|640|600" \
  3 \
  "u=rw (6), g=r (4), o= (0)." \
  "6 4 0." \
  "640."

qstep
q_choice \
  "À quoi sert umask ?" \
  "À masquer les permissions à la création de fichiers/dossiers|À changer le propriétaire|À lister les permissions|À exécuter un programme en root" \
  2 \
  "C'est un masque de création." \
  "Permissions effectives = base - masque." \
  "umask masque les droits à la création."

qstep
q_choice \
  "Avec umask 027, quelles permissions pour un nouveau fichier ?" \
  "777|750|644|640" \
  4 \
  "Un fichier part de 666." \
  "666 - 027 = 640." \
  "640."

qstep
q_choice \
  "Que fait le bit SUID sur un exécutable ?" \
  "Il exécute avec les droits du propriétaire|Il exécute avec les droits de tous|Il interdit l'exécution|Il rend le fichier caché" \
  1 \
  "euid = propriétaire du fichier." \
  "Exemple historique : passwd." \
  "SUID = droits du propriétaire."

qstep
q_choice \
  "Le sticky bit sur un répertoire :" \
  "accélère l'accès|hérite le groupe|empêche de supprimer les fichiers d'autrui|masque les fichiers" \
  3 \
  "Il restreint la suppression." \
  "Chacun ne supprime que ses propres fichiers." \
  "Sticky = suppression restreinte."

# ============================================================== Calculs ----
title "Partie B — Calculs (symbolique vers octal, umask)"

qstep
q_number \
  "Convertis -rw-r----- en octal (3 chiffres)." \
  "640" \
  "Lis par blocs : user, group, other." \
  "rw- = 6, r-- = 4, --- = 0." \
  "Réponds : 640"

qstep
q_number \
  "Convertis -rwxr-x--- en octal (3 chiffres)." \
  "750" \
  "rwx = 7, r-x = 5, --- = 0." \
  "Chaque bloc : somme des droits." \
  "Réponds : 750"

qstep
q_number \
  "Avec umask 027, permissions octales d'un nouveau fichier ?" \
  "640" \
  "Un fichier part de 666." \
  "On retire les bits du masque 027." \
  "666 - 027 = 640."

qstep
q_number \
  "Avec umask 022, permissions octales d'un nouveau répertoire ?" \
  "755" \
  "Un répertoire part de 777." \
  "On retire les bits du masque 022." \
  "777 - 022 = 755."

# ============================================================ Mise en œuvre --
title "Partie C — Mise en œuvre (dans obj08/)"

step "Crée un fichier et applique le mode octal : \`touch fichier.txt && chmod 640 fichier.txt\`."
q_fs "fichier.txt a les permissions -rw-r-----" \
  '[ "$(ls -l fichier.txt | cut -c1-10)" = "-rw-r-----" ]' \
  "chmod 640 = rw- r-- ---." \
  "Vérifie : \`ls -l fichier.txt\`." \
  "La chaîne de droits doit être -rw-r-----." \
  "touch fichier.txt && chmod 640 fichier.txt"

step "Crée un répertoire et applique un mode symbolique : \`mkdir atelier && chmod u=rwx,g=rx,o= atelier\`."
q_fs "atelier a les permissions drwxr-x---" \
  '[ "$(ls -ld atelier | cut -c1-10)" = "drwxr-x---" ]' \
  "u=rwx, g=rx, o= (rien)." \
  "Cela correspond à 750." \
  "La chaîne doit être drwxr-x---." \
  "mkdir atelier && chmod u=rwx,g=rx,o= atelier"

step "Applique un umask puis crée un fichier : \`umask 027 && touch umask_f.txt\`."
q_fs "umask_f.txt a les permissions -rw-r-----" \
  '[ "$(ls -l umask_f.txt | cut -c1-10)" = "-rw-r-----" ]' \
  "umask 027 masque les bits 027." \
  "Un fichier part de 666 : 666 - 027 = 640." \
  "Vérifie : \`ls -l umask_f.txt\`." \
  "umask 027 && touch umask_f.txt"

step "Applique un autre umask puis crée un répertoire : \`umask 022 && mkdir umask_d\`."
q_fs "umask_d a les permissions drwxr-xr-x" \
  '[ "$(ls -ld umask_d | cut -c1-10)" = "drwxr-xr-x" ]' \
  "umask 022 masque les bits 022." \
  "Un dossier part de 777 : 777 - 022 = 755." \
  "Vérifie : \`ls -ld umask_d\`." \
  "umask 022 && mkdir umask_d"

# ================================================================ Synthèse --
synthese \
  "Comment passer d'une notation symbolique (rwx) à l'octal, et inversement ?" \
  "Comment le umask détermine-t-il les permissions d'un nouveau fichier ou dossier (base - masque) ?" \
  "Quelle différence entre les droits d'un fichier et d'un répertoire (rôle de x) ?" \
  "Quel est le rôle de SUID, et pourquoi peut-il être dangereux ?" \
  "Quelle différence entre /etc/passwd et /etc/shadow (où est le hash, pourquoi) ?"

finalize
